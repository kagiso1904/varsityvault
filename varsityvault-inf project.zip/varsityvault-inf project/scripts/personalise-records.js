import { SqlStore } from "../server/storage.js";
import { personaliseRecords } from "../server/personalise-records.js";
if (process.env.NODE_ENV === "production")
  throw Error("Run this only against your local project database.");
if ((process.env.APP_MODE || "sqlserver") !== "sqlserver")
  throw Error("Use your configured SQL Server database.");
let db;
try {
  db = await SqlStore.open();
  const out = await personaliseRecords(db);
  console.log(JSON.stringify(out, null, 2));
  console.log(
    "Existing passwords and application history are unchanged. Use the listed email addresses to sign in.",
  );
} catch (e) {
  console.error("No changes committed:", e.message);
  process.exitCode = 1;
} finally {
  if (db) await db.close();
}
