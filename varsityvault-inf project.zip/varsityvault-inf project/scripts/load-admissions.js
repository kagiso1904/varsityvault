import { LocalStore, SqlStore } from "../server/storage.js";
import { importAdmissionProfiles } from "../server/admissions-import.js";
const mode = process.env.APP_MODE || "sqlserver";
if (!["local", "sqlserver"].includes(mode))
  throw new Error("APP_MODE must be local or sqlserver.");
const store =
  mode === "sqlserver"
    ? await SqlStore.open()
    : new LocalStore(
        process.env.LOCAL_DATABASE || ".data/varsity-vault.sqlite",
      );
try {
  console.log("Admissions database mode:", store.mode);
  console.log(
    "Admissions import completed:",
    await importAdmissionProfiles(store),
  );
} finally {
  await store.close();
}
