import { SqlStore } from "../server/storage.js";
import { SAMPLE_PASSWORD, seedSampleData } from "../server/sample-fixture.js";

const mode = process.env.APP_MODE || "sqlserver";
if (process.env.NODE_ENV === "production") {
  console.error(
    "Refusing to seed sample workflow data when NODE_ENV=production.",
  );
  process.exit(1);
}
if (mode !== "sqlserver") {
  console.error(
    "The sample seeder only supports APP_MODE=sqlserver. Refusing to modify a local/test database.",
  );
  process.exit(1);
}
if (process.env.SAMPLE_DATA_CONFIRM !== "VARSITYVAULT2") {
  console.error(
    "No data was changed. To confirm this is your sample workflow database, set SAMPLE_DATA_CONFIRM=VARSITYVAULT2 and run npm run data:seed again.",
  );
  process.exit(1);
}

let store;
try {
  store = await SqlStore.open();
  const summary = await seedSampleData(store);
  console.log(
    "\nVarsity Vault synthetic sample data is ready. No existing records were deleted.",
  );
  console.log(JSON.stringify(summary, null, 2));
  console.log(
    "\nWORKFLOW ACCOUNT PASSWORD (all sample accounts): " + SAMPLE_PASSWORD,
  );
  console.log(
    "Use only in a private local environment. Change this password before wider use.",
  );
} catch (error) {
  console.error(
    "sample seed failed and its database transaction was rolled back.",
  );
  console.error(error.message);
  process.exitCode = 1;
} finally {
  if (store) await store.close().catch(() => {});
}
