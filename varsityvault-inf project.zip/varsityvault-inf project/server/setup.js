import { LocalStore, SqlStore } from "./storage.js";
import { seedLocal, bootstrapAdmin } from "./seed.js";
import { emailVerificationMessage } from "./account-email.js";
import { emailDeliveryReady, sendAccountEmail } from "./mailer.js";
import { ensureReferenceData } from "./reference-data.js";
const mode = process.env.APP_MODE || "sqlserver";
if (!["local", "sqlserver"].includes(mode))
  throw new Error("APP_MODE must be sqlserver or local.");
const db =
  mode === "sqlserver"
    ? await SqlStore.open()
    : new LocalStore(
        process.env.LOCAL_DATABASE || ".data/varsity-vault.sqlite",
      );
try {
  if (db.mode === "local") await db.tx(seedLocal);
  await ensureReferenceData(db);
  const username = process.env.ADMIN_EMAIL,
    password = process.env.ADMIN_PASSWORD;
  if (!username || !password)
    throw new Error(
      "Set ADMIN_EMAIL and ADMIN_PASSWORD (12–128 characters) in .env before setup.",
    );
  if (!emailDeliveryReady())
    throw new Error(
      "Configure EMAIL_MODE=console for local setup or configure SMTP and PUBLIC_APP_URL before creating the administrator.",
    );
  const existing = (
    await db.list("security.Accounts", { USERNAME: username.toLowerCase() })
  )[0];
  let person,
    resent = false;
  if (existing) {
    const isAdmin =
      (await db.list("ITADMINS", { PERSON_ID: existing.PERSON_ID })).length > 0;
    const verification = (
      await db.list("security.EmailVerifications", {
        PERSON_ID: existing.PERSON_ID,
      })
    )[0];
    if (!isAdmin || verification?.VERIFIED_AT)
      throw new Error(
        "An administrator login already exists; use that account or the password recovery flow.",
      );
    person = { PERSON_ID: existing.PERSON_ID };
    resent = true;
  } else person = await bootstrapAdmin(db, { username, password });
  const message = await db.tx((tx) =>
    emailVerificationMessage(tx, person.PERSON_ID, username.toLowerCase()),
  );
  await sendAccountEmail(message);
  console.log(
    resent
      ? "Administrator verification email resent."
      : "Administrator created. Verify the email address before signing in.",
  );
} catch (e) {
  console.error(e.message);
  process.exitCode = 1;
} finally {
  await db.close();
}
