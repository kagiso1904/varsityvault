import { installCrud } from "./crud.js";
import { universityLocations } from "./university-locations.js";
import { installRecordEntry } from "./record-entry.js";
import {
  records,
  append,
  snapshot,
  reviewVersion,
  requireVersion,
  newPolicyId,
} from "./admission-versions.js";
import {
  httpsUrl,
  validateDirectoryFields,
  directoryLimits,
  safeFilename,
} from "./validation.js";
import {
  validateScoring,
  validateGroups,
  offeringAvailability,
} from "../shared/scoring/programme.js";
import { randomUUID } from "node:crypto";
import {
  sameId,
  normalizeIdentity,
  findPersonIdentityMatches,
  personIdentityWarnings,
  hasRepeatedEmailSuffix,
  isValidSouthAfricanPhone,
  isValidPersonName,
  isEmailLike,
  normalizeSouthAfricanIdNumber,
  isValidSouthAfricanIdNumber,
  findPersonSaIdMatches,
} from "./identity.js";
import express from "express";
import packageInfo from "../package.json" with { type: "json" };
import {
  passwordHash,
  checkPassword,
  token,
  digest,
  userContext,
  audit,
} from "./security.js";
import { accountLink, emailDeliveryReady, sendAccountEmail } from "./mailer.js";
import {
  accountInvitationMessage,
  emailVerificationMessage,
  issueAccountToken,
} from "./account-email.js";
import {
  decryptSecret,
  encryptSecret,
  encryptionKey,
  makeRecoveryCodes,
  newTotpSecret,
  provisioningUri,
  verifyTotp,
} from "./mfa.js";
import { assessSubjects, curriculum } from "../shared/scoring/subjects.js";
import { attachSubjectsToResults } from "../shared/scoring/result-records.js";
import { isRequiredBeforeProvisional } from "../shared/review/documents.js";
const bad = (message, status = 400) =>
  Object.assign(new Error(message), { status });
const id = (x) => {
  const n = Number(x);
  if (
    !["string", "number"].includes(typeof x) ||
    !/^\d+$/.test(String(x)) ||
    !Number.isSafeInteger(n) ||
    n < 1 ||
    n > 2147483647
  )
    throw bad("Invalid record identifier.");
  return n;
};
const text = (x, max = 100) => {
  if (
    typeof x !== "string" ||
    !x.trim() ||
    x.length > max ||
    /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(x)
  )
    throw bad("A required text field is missing or too long.");
  return x.trim();
};
const personName = (value) => {
  const name = text(value);
  if (!isValidPersonName(name))
    throw bad(
      "Names must use letters, spaces, apostrophes, periods or hyphens. Numbers are not allowed.",
    );
  return name;
};
const now = () => new Date().toISOString();
const date = () => now().slice(0, 19);
const today = () =>
  new Intl.DateTimeFormat("en-CA", {
    timeZone: "Africa/Johannesburg",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
const one = async (db, t, w) => {
  const r = (await db.list(t, w))[0];
  if (!r) throw bad("Record not found.", 404);
  return r;
};
async function assertSaIdAvailable(db, saIdNumber, excludePersonId = null) {
  if (!saIdNumber) return;
  const matches = findPersonSaIdMatches(
    await db.list("PERSONS"),
    saIdNumber,
    excludePersonId,
  );
  if (matches.length)
    throw bad(
      "This South African ID number is already associated with another person. Contact the administrator if you believe this is an error.",
      409,
    );
}
const maskSaIdNumber = (value) => {
  const idNumber = normalizeSouthAfricanIdNumber(value);
  return /^\d{13}$/.test(idNumber) ? "•••••••••" + idNumber.slice(-4) : null;
};
const role = (u, ...roles) => {
  if (!roles.includes(u.role))
    throw bad("This account cannot perform that action.", 403);
};
const statusId = async (db, name) =>
  (await one(db, "APPLICATION_STATUSES", { STATUS_NAME: name })).STATUS_ID;
const verificationId = async (db, name) =>
  (await one(db, "VERIFICATION_STATUSES", { VERIFICATION_STATUS_NAME: name }))
    .VERIFICATION_STATUS_ID;
async function results(db, learnerId, examId) {
  const rows = await db.list("LEARNER_RESULTS", {
    LEARNER_ID: learnerId,
    EXAM_TYPE_ID: examId,
  });
  const subjects = await db.list("SUBJECTS");
  return attachSubjectsToResults(rows, subjects);
}
async function scopedLearner(db, u, learnerId) {
  const learner = await one(db, "LEARNERS", { PERSON_ID: learnerId });
  if (
    (u.role === "learner" && !sameId(learner.PERSON_ID, u.recordId)) ||
    (u.role === "teacher" && !sameId(learner.SCHOOL_ID, u.schoolId)) ||
    !["learner", "teacher", "admin"].includes(u.role)
  )
    throw bad("Learner is outside your access scope.", 403);
  return learner;
}
async function scopeApp(db, u, applicationId) {
  const a = await one(db, "APPLICATIONS", { APPLICATION_ID: applicationId }),
    l = await one(db, "LEARNERS", { PERSON_ID: a.LEARNER_ID }),
    o = await one(db, "UNI_QUALIFICATIONS", { UNI_QUAL_ID: a.UNI_QUAL_ID });
  if (
    (u.role === "learner" && !sameId(a.LEARNER_ID, u.recordId)) ||
    (u.role === "teacher" && !sameId(l.SCHOOL_ID, u.schoolId)) ||
    (u.role === "representative" && !sameId(o.UNIVERSITY_ID, u.universityId))
  )
    throw bad("Application is outside your access scope.", 403);
  return a;
}
async function offering(db, offeringId) {
  const o = await one(db, "UNI_QUALIFICATIONS", { UNI_QUAL_ID: offeringId }),
    university = await one(db, "UNIVERSITIES", {
      UNIVERSITY_ID: o.UNIVERSITY_ID,
    }),
    qualification = await one(db, "QUALIFICATIONS", { QUAL_ID: o.QUAL_ID }),
    program = await one(db, "PROGRAMS", {
      PROGRAM_ID: qualification.PROGRAM_ID,
    });
  const row = (
    await db.list("security.Policies", { UNI_QUAL_ID: offeringId })
  )[0];
  const legacy = (
    await db.list("QUALIFICATION_REQUIREMENTS", { UNI_QUAL_ID: offeringId })
  )[0];
  const config = {
    ...(legacy
      ? {
          minScore: legacy.MIN_APS_SCORE,
          minEnglish: legacy.MIN_ENG_SCORE,
          minMath: legacy.MIN_MATH_SCORE,
          notes: legacy.NOTES,
          status: "pending",
        }
      : {}),
    ...(row ? JSON.parse(row.PAYLOAD) : {}),
  };
  return {
    ...o,
    university: university.UNIVERSITY_NAME,
    qualification: qualification.QUAL_NAME,
    program: program.PROGRAM_NAME,
    config,
    availability: offeringAvailability(config, o.APPLICATION_CLOSING_DATE),
  };
}
function dashboardApplication(row) {
  const config = {
    ...(row.LEGACY_MIN_APS_SCORE != null
      ? {
          minScore: row.LEGACY_MIN_APS_SCORE,
          minMath: row.LEGACY_MIN_MATH_SCORE,
          minEnglish: row.LEGACY_MIN_ENG_SCORE,
          notes: row.LEGACY_NOTES,
          status: "pending",
        }
      : {}),
    ...(row.POLICY_PAYLOAD ? JSON.parse(row.POLICY_PAYLOAD) : {}),
  };
  return {
    ...row,
    status: row.APPLICATION_STATUS,
    learnerName: row.LEARNER_FIRST_NAME + " " + row.LEARNER_LAST_NAME,
    learnerId: row.LEARNER_ID,
    offering: {
      UNI_QUAL_ID: row.UNI_QUAL_ID,
      UNIVERSITY_ID: row.OFFERING_UNIVERSITY_ID,
      APPLICATION_CLOSING_DATE: row.OFFERING_CLOSING_DATE,
      qualification: row.OFFERING_QUALIFICATION,
      university: row.OFFERING_UNIVERSITY,
      config,
    },
  };
}
async function assessment(db, u, offerId, examId) {
  const o = await offering(db, offerId),
    exam = await one(db, "EXAM_TYPES", { EXAM_TYPE_ID: examId });
  const config = { ...o.config };
  config.examTypeName = exam.EXAM_TYPE_NAME;
  if (
    exam.EXAM_TYPE_NAME === "Grade 12 Final (NSC)" &&
    config.finalMinScore != null
  )
    config.minScore = config.finalMinScore;
  return {
    ...assessSubjects(await results(db, u.recordId, examId), o.policy, config),
    offering: o,
  };
}
async function history(db, a, target, u) {
  const action =
    (await db.list("ACTIONS", { ACTION_NAME: target }))[0] ||
    (await db.insert("ACTIONS", { ACTION_NAME: target }));
  await db.insert("APPLICATION_PROCESSES", {
    APPLICATION_ID: a.APPLICATION_ID,
    ACTION_ID: action.ACTION_ID,
    ACTION_DATE: date(),
  });
  await audit(db, u.personId, "application." + target, {
    applicationId: a.APPLICATION_ID,
  });
}
const emailPattern = { test: isEmailLike };
const findAccountByUsername = async (db, username) =>
  (await db.list("security.Accounts")).find(
    (account) =>
      normalizeIdentity(account.USERNAME) === normalizeIdentity(username),
  );
const personMatchMessage = (matches) =>
  matches.length > 1
    ? "Multiple existing person records match this email. Ask an administrator to resolve the duplicate records before continuing."
    : "A person record already uses this email or username. Ask an administrator to enable sign-in for the existing person instead of creating a duplicate.";
const genericResetMessage =
  "If the address belongs to an active account, instructions will be sent shortly.";
const representativeTransitions = {
  "Screened by Career Teacher": ["Provisionally Accepted", "Rejected"],
  "Provisionally Accepted": ["Final Matric Verified"],
  "Final Matric Verified": ["Admitted", "Offer Revoked"],
};
const decisionLabels = {
  "Provisionally Accepted": "Provisionally accept",
  Rejected: "Reject application",
  "Final Matric Verified": "Verify final matric results",
  Admitted: "Admit learner",
  "Offer Revoked": "Revoke offer",
};
async function checkApplicationTransition(db, u, a, target) {
  const current = (
    await one(db, "APPLICATION_STATUSES", { STATUS_ID: a.STATUS_ID })
  ).STATUS_NAME;
  if (target === "Screened by Career Teacher") {
    role(u, "teacher");
    if (current !== "Submitted")
      throw bad("Only submitted applications can be screened.", 409);
  } else {
    role(u, "representative");
    if (!representativeTransitions[current]?.includes(target))
      throw bad("This transition is not available from " + current + ".", 409);
  }
  const l = await one(db, "LEARNERS", { PERSON_ID: a.LEARNER_ID });
  const verified = await verificationId(db, "Verified");
  const programme = await offering(db, a.UNI_QUAL_ID);
  const final = ["Final Matric Verified", "Admitted"].includes(target);
  const positive = [
    "Screened by Career Teacher",
    "Provisionally Accepted",
    "Final Matric Verified",
    "Admitted",
  ].includes(target);
  if (positive) {
    const examName = final ? "Grade 12 Final (NSC)" : "Grade 11 Final";
    const exam = await one(db, "EXAM_TYPES", { EXAM_TYPE_NAME: examName });
    const rows = await results(db, a.LEARNER_ID, exam.EXAM_TYPE_ID);
    if (
      !curriculum(rows) ||
      rows.some((r) => !sameId(r.VERIFICATION_STATUS_ID, verified))
    )
      throw bad(
        final
          ? "Verified final NSC results and certificate are required."
          : target === "Screened by Career Teacher"
            ? "Verify the complete Grade 11 results first."
            : "Grade 11 results must still be verified before provisional acceptance.",
        409,
      );
    if (final) {
      const type = await one(db, "DOCUMENT_TYPES", {
        DOCUMENT_TYPE_NAME: "Final NSC Certificate",
      });
      if (
        !(
          await db.list("DOCUMENTS", {
            PERSON_ID: l.PERSON_ID,
            DOCUMENT_TYPE_ID: type.DOCUMENT_TYPE_ID,
          })
        ).some(
          (d) =>
            sameId(d.VERIFICATION_STATUS_ID, verified) &&
            d.DOCUMENT_BLOB?.length,
        )
      )
        throw bad(
          "Verified final NSC results and certificate are required.",
          409,
        );
    } else {
      for (const type of (await db.list("DOCUMENT_TYPES")).filter((t) =>
        isRequiredBeforeProvisional(t, programme.config),
      )) {
        const documents = await db.list("DOCUMENTS", {
          PERSON_ID: l.PERSON_ID,
          DOCUMENT_TYPE_ID: type.DOCUMENT_TYPE_ID,
        });
        if (
          !documents.some(
            (d) =>
              sameId(d.VERIFICATION_STATUS_ID, verified) &&
              d.DOCUMENT_BLOB?.length,
          )
        )
          throw bad(
            target === "Screened by Career Teacher"
              ? "Verify mandatory documents first."
              : "Mandatory documents must still be verified before provisional acceptance.",
            409,
          );
      }
    }
    if (target !== "Screened by Career Teacher") {
      const check = await assessment(
        db,
        { ...u, recordId: a.LEARNER_ID },
        a.UNI_QUAL_ID,
        exam.EXAM_TYPE_ID,
      );
      if (
        ["Provisionally Accepted", "Admitted"].includes(target) &&
        !check.eligible
      )
        throw bad(
          final
            ? "Final results do not meet the configured requirements."
            : "Grade 11 results do not meet the currently configured requirements.",
          409,
        );
    }
  }
  return current;
}
async function applicationEvidenceChecklist(db, a, current) {
  if (["Admitted", "Rejected", "Offer Revoked"].includes(current)) return [];
  const final = ["Provisionally Accepted", "Final Matric Verified"].includes(
    current,
  );
  const examName = final ? "Grade 12 Final (NSC)" : "Grade 11 Final";
  const ex = (await db.list("EXAM_TYPES")).find(
    (row) => row.EXAM_TYPE_NAME === examName,
  );
  const learner = await one(db, "LEARNERS", { PERSON_ID: a.LEARNER_ID });
  const rows = ex ? await results(db, a.LEARNER_ID, ex.EXAM_TYPE_ID) : [];
  const verified = await verificationId(db, "Verified");
  const complete = curriculum(rows);
  const verifiedCount = rows.filter((row) =>
    sameId(row.VERIFICATION_STATUS_ID, verified),
  ).length;
  const checklist = [
    {
      label: examName + " marks saved",
      ready: complete,
      detail: complete
        ? rows.length + " subjects saved."
        : "The learner must save a complete NSC subject set in Academic Results.",
      owner: "Learner",
    },
    {
      label: examName + " marks verified",
      ready: complete && verifiedCount === rows.length,
      detail:
        verifiedCount +
        " of " +
        rows.length +
        " saved subjects verified. The career educator verifies marks in Results Verification.",
      owner: "Career educator",
    },
  ];
  const types = await db.list("DOCUMENT_TYPES");
  const programme = await offering(db, a.UNI_QUAL_ID);
  const required = final
    ? types.filter(
        (type) => type.DOCUMENT_TYPE_NAME === "Final NSC Certificate",
      )
    : types.filter((type) =>
        isRequiredBeforeProvisional(type, programme.config),
      );
  if (final && !required.length)
    checklist.push({
      label: "Final NSC Certificate type configured",
      ready: false,
      detail: "Add the final certificate type in document reference data.",
      owner: "IT administrator",
    });
  const documents = await db.list("DOCUMENTS", {
    PERSON_ID: learner.PERSON_ID,
  });
  for (const type of required) {
    const files = documents.filter((file) =>
      sameId(file.DOCUMENT_TYPE_ID, type.DOCUMENT_TYPE_ID),
    );
    const uploaded = files.some((file) => file.DOCUMENT_BLOB?.length);
    const approved = files.some(
      (file) =>
        file.DOCUMENT_BLOB?.length &&
        sameId(file.VERIFICATION_STATUS_ID, verified),
    );
    checklist.push({
      label: type.DOCUMENT_TYPE_NAME,
      ready: approved,
      detail: approved
        ? "Uploaded and verified."
        : uploaded
          ? "Uploaded; the career educator must verify it in Documents."
          : "The learner must upload this document; the career educator must then verify it.",
      owner: uploaded ? "Career educator" : "Learner",
    });
  }
  return checklist;
}
export function fullApi(
  store,
  { secureCookies = false, sendEmail = sendAccountEmail } = {},
) {
  const router = express.Router();
  const cookie = "vv_session",
    challengeCookie = "vv_mfa_challenge";
  const dummyPasswordHash =
    "vv-timing-salt-2026:b72899f1546691f625d7cde1685862b301ca091f519c8703cbb61e9d95e236ec66129956ec2959d6d7fc2edefb8131de559b7f2f09be1493103a974b4fd83d63";
  const readToken = (req) =>
    String(req.headers.cookie || "")
      .split(";")
      .map((s) => s.trim())
      .find((s) => s.startsWith(cookie + "="))
      ?.slice(cookie.length + 1);
  const setCookie = (res, value, clear = false) =>
    res.setHeader(
      "Set-Cookie",
      `${cookie}=${value}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${clear ? 0 : 28800}${secureCookies ? "; Secure" : ""}`,
    );
  const readChallenge = (req) =>
    String(req.headers.cookie || "")
      .split(";")
      .map((s) => s.trim())
      .find((s) => s.startsWith(challengeCookie + "="))
      ?.slice(challengeCookie.length + 1);
  const setChallengeCookie = (res, value, clear = false) =>
    res.setHeader(
      "Set-Cookie",
      `${challengeCookie}=${value}; Path=/api/auth/mfa; HttpOnly; SameSite=Strict; Max-Age=${clear ? 0 : 600}${secureCookies ? "; Secure" : ""}`,
    );
  const issueSession = async (db, personId, res) => {
    const secret = token(),
      csrf = token();
    await db.insert("security.Sessions", {
      TOKEN_HASH: digest(secret),
      PERSON_ID: personId,
      CSRF: csrf,
      EXPIRES: new Date(Date.now() + 28800000).toISOString(),
    });
    setCookie(res, secret);
    return { csrf };
  };
  const queueEmail = (to, subject, text) => {
    const message = typeof to === "object" && to ? to : { to, subject, text };
    return { __afterCommit: () => sendEmail(message) };
  };
  const issueToken = issueAccountToken;
  const requestAllowed = async (db, req, scope, identifier) => {
    const timestamp = Date.now(),
      windowMs = 900000;
    let allowed = true;
    for (const value of ["ip:" + req.ip, "key:" + digest(identifier)]) {
      const key = digest("account-flow|" + scope + "|" + value),
        prior = (
          await db.list("security.LoginAttempts", { ATTEMPT_KEY: key })
        )[0],
        active =
          prior && Date.now() - Date.parse(prior.WINDOW_START) < windowMs;
      if (prior?.BLOCKED_UNTIL && Date.parse(prior.BLOCKED_UNTIL) > timestamp) {
        allowed = false;
        continue;
      }
      const failures = (active ? Number(prior.FAILURES) : 0) + 1,
        windowStart = active
          ? prior.WINDOW_START
          : new Date(timestamp).toISOString(),
        blockedUntil =
          failures > 5 ? new Date(timestamp + windowMs).toISOString() : "";
      const row = {
        FAILURES: failures,
        WINDOW_START: windowStart,
        BLOCKED_UNTIL: blockedUntil,
      };
      if (prior)
        await db.update("security.LoginAttempts", { ATTEMPT_KEY: key }, row);
      else
        await db.insert("security.LoginAttempts", { ATTEMPT_KEY: key, ...row });
      if (failures > 5) allowed = false;
    }
    return allowed;
  };
  const clearRequestLimit = async (db, req, scope, identifier) => {
    for (const value of ["ip:" + req.ip, "key:" + digest(identifier)])
      await db.remove("security.LoginAttempts", {
        ATTEMPT_KEY: digest("account-flow|" + scope + "|" + value),
      });
  };
  const emailAvailable = sendEmail !== sendAccountEmail || emailDeliveryReady();
  const inviteAccount = async (db, personId, email) => {
    if (!emailAvailable)
      throw bad(
        "Email delivery is not configured. Contact the application administrator.",
        503,
      );
    return queueEmail(await accountInvitationMessage(db, personId, email));
  };
  const verifyAccountEmail = async (db, personId, email) => {
    if (!emailAvailable)
      throw bad(
        "Email delivery is not configured. Contact the application administrator.",
        503,
      );
    return queueEmail(await emailVerificationMessage(db, personId, email));
  };
  const activeInvitation = async (db, personId) =>
    (
      await db.list("security.AccountTokens", {
        PERSON_ID: personId,
        PURPOSE: "account-invitation",
      })
    ).some((item) => item.EXPIRES > now());
  const wrap =
    (fn, { publicRoute = false, minimumDuration = 0 } = {}) =>
    async (req, res, next) => {
      const started = Date.now();
      try {
        if (req.body == null) req.body = {};
        if (
          !["GET", "HEAD"].includes(req.method) &&
          req.is("application/json") &&
          (!req.body || typeof req.body !== "object" || Array.isArray(req.body))
        )
          throw bad("Submit a JSON object with the required fields.");
        let afterCommit = null;
        const output = await store.tx(async (db) => {
          let u = null,
            session = null;
          const secret = readToken(req);
          if (secret) {
            session = (
              await db.list("security.Sessions", { TOKEN_HASH: digest(secret) })
            )[0];
            if (session && session.EXPIRES > now()) {
              const account = (
                await db.list("security.Accounts", {
                  PERSON_ID: session.PERSON_ID,
                })
              )[0];
              if (account && !account.DISABLED)
                u = await userContext(db, session.PERSON_ID);
            }
          }
          if (!publicRoute && !u) throw bad("Please sign in.", 401);
          if (!["GET", "HEAD"].includes(req.method)) {
            const origin = req.get("origin");
            if (origin && origin !== `${req.protocol}://${req.get("host")}`)
              throw bad("Cross-site request refused.", 403);
            if (
              !publicRoute &&
              (!session || req.get("x-csrf-token") !== session.CSRF)
            )
              throw bad("Refresh the page before changing data.", 403);
          }
          const value = await fn(db, u, req, res, session);
          if (value?.__afterCommit) {
            afterCommit = value.__afterCommit;
            const { __afterCommit, ...body } = value;
            return body;
          }
          return value;
        });
        if (afterCommit)
          setImmediate(() =>
            Promise.resolve()
              .then(afterCommit)
              .catch((error) =>
                console.error(
                  "Account email delivery failed:",
                  error.code || error.name,
                ),
              ),
          );
        const remaining = minimumDuration - (Date.now() - started);
        if (remaining > 0)
          await new Promise((resolve) => setTimeout(resolve, remaining));
        if (output !== undefined && !res.headersSent) {
          if (Number.isInteger(output.__httpStatus)) {
            const { __httpStatus, ...body } = output;
            res.status(__httpStatus).json(body);
          } else res.json(output);
        }
      } catch (error) {
        next(error);
      }
    };
  router.get("/health", (req, res) =>
    res.json({
      status: "ok",
      version: packageInfo.version,
      mode: store.mode,
      authentication: "enabled",
      database:
        store.mode === "sqlserver" ? "SQL Server" : "local development SQLite",
      intake: 2028,
      demoMode: false,
      writesEnabled: true,
    }),
  );
  router.get("/public-config", (req, res) => {
    const email = (process.env.SUPPORT_EMAIL || "").trim();
    res.json({
      supportEmail:
        emailPattern.test(email) && email.length <= 254 ? email : null,
      emailEnabled: emailAvailable,
    });
  });
  router.get(
    "/universities",
    wrap(
      async (db) => {
        const universities = await db.list("UNIVERSITIES"),
          provinces = await db.list("PROVINCES"),
          cities = await db.list("CITIES"),
          addresses = await db.list("UNIVERSITY_ADDRESSES");
        return {
          intake: 2028,
          count: universities.length,
          universities: universities.map((u) => {
            const locations = universityLocations(
              u,
              addresses,
              cities,
              provinces,
            );
            const address = locations[0];
            return {
              name: u.UNIVERSITY_NAME,
              cities: [
                ...new Set(locations.map((a) => a.CITY_NAME).filter(Boolean)),
              ],
              city:
                cities.find((c) => sameId(c.CITY_ID, address?.CITY_ID))
                  ?.CITY_NAME ?? null,
              province:
                provinces.find((p) => sameId(p.PROVINCE_ID, u.PROVINCE_ID))
                  ?.PROVINCE_NAME ?? null,
            };
          }),
        };
      },
      { publicRoute: true },
    ),
  );
  // Public registration only needs school names; do not resolve a stale session
  // or load university, subject, address and scoring catalogues before sign-in.
  router.get("/registration-schools", async (req, res, next) => {
    try {
      const schools = await store.tx(async (db) =>
        (await db.list("SCHOOLS"))
          .filter((school) => school.EMIS_NUMBER !== "LOCAL-ONLY")
          .map(({ SCHOOL_ID, SCHOOL_NAME }) => ({ SCHOOL_ID, SCHOOL_NAME })),
      );
      res.json({ schools });
    } catch (error) {
      next(error);
    }
  });
  router.get(
    "/catalog",
    wrap(
      async (db, u) => {
        const allSchools = await db.list("SCHOOLS"),
          schools =
            u?.role === "admin"
              ? allSchools.map((s) => ({
                  ...s,
                  SCHOOL_NAME:
                    s.EMIS_NUMBER === "LOCAL-ONLY"
                      ? s.SCHOOL_NAME + " (local setup only)"
                      : s.SCHOOL_NAME,
                }))
              : allSchools
                  .filter((s) => s.EMIS_NUMBER !== "LOCAL-ONLY")
                  .map(({ SCHOOL_ID, SCHOOL_NAME }) => ({
                    SCHOOL_ID,
                    SCHOOL_NAME,
                  })),
          universities = await db.list("UNIVERSITIES"),
          subjects = await db.list("SUBJECTS"),
          examTypes = await db.list("EXAM_TYPES"),
          documentTypes = await db.list("DOCUMENT_TYPES"),
          verificationStatuses = await db.list("VERIFICATION_STATUSES"),
          studyModes = await db.list("STUDY_MODES"),
          provinces = await db.list("PROVINCES"),
          cities = await db.list("CITIES"),
          addresses = await db.list("UNIVERSITY_ADDRESSES"),
          applicationStatuses = await db.list("APPLICATION_STATUSES"),
          actions = await db.list("ACTIONS"),
          achievementLevels = await db.list("ACHIEVEMENT_LEVELS");
        return {
          applicationStatuses,
          actions,
          achievementLevels,
          schools,
          universities: universities
            .filter(
              (item) =>
                u?.role !== "representative" ||
                String(item.UNIVERSITY_ID) === String(u.universityId),
            )
            .map((u) => {
              const locations = universityLocations(
                u,
                addresses,
                cities,
                provinces,
              );
              const address = locations[0];
              return {
                ...u,
                CITY_ID: address?.CITY_ID ?? null,
                STREET_NAME: address?.STREET_NAME ?? null,
                LOCATIONS: locations,
              };
            }),
          subjects,
          examTypes,
          documentTypes,
          verificationStatuses,
          studyModes,
          provinces,
          cities,
        };
      },
      { publicRoute: true },
    ),
  );
  router.post(
    "/auth/login",
    wrap(
      async (db, u, req, res) => {
        const username = text(req.body.username, 100).toLowerCase(),
          key = digest(req.ip + "|" + username),
          timestamp = Date.now(),
          windowMs = 900000;
        const prior = (
          await db.list("security.LoginAttempts", { ATTEMPT_KEY: key })
        )[0];
        if (prior?.BLOCKED_UNTIL && Date.parse(prior.BLOCKED_UNTIL) > timestamp)
          return {
            __httpStatus: 429,
            error: "Too many sign-in attempts. Try again in 15 minutes.",
          };
        const account = await findAccountByUsername(db, username);
        const valid = await checkPassword(
          req.body.password,
          account?.PASSWORD_HASH || dummyPasswordHash,
        );
        if (!valid || !account || account.DISABLED) {
          const active =
              prior &&
              Number.isFinite(Date.parse(prior.WINDOW_START)) &&
              timestamp - Date.parse(prior.WINDOW_START) < windowMs,
            failures = (active ? Number(prior.FAILURES) : 0) + 1,
            windowStart = active
              ? prior.WINDOW_START
              : new Date(timestamp).toISOString(),
            blockedUntil =
              failures >= 10
                ? new Date(timestamp + windowMs).toISOString()
                : "";
          if (prior)
            await db.update(
              "security.LoginAttempts",
              { ATTEMPT_KEY: key },
              {
                FAILURES: failures,
                WINDOW_START: windowStart,
                BLOCKED_UNTIL: blockedUntil,
              },
            );
          else
            await db.insert("security.LoginAttempts", {
              ATTEMPT_KEY: key,
              FAILURES: failures,
              WINDOW_START: windowStart,
              BLOCKED_UNTIL: blockedUntil,
            });
          return {
            __httpStatus: failures >= 10 ? 429 : 401,
            error:
              failures >= 10
                ? "Too many sign-in attempts. Try again in 15 minutes."
                : "Incorrect username or password.",
          };
        }
        const context = await userContext(db, account.PERSON_ID);
        if (!context)
          throw bad("The account needs a single assigned role.", 403);
        if (prior)
          await db.remove("security.LoginAttempts", { ATTEMPT_KEY: key });
        const verification = (
          await db.list("security.EmailVerifications", {
            PERSON_ID: account.PERSON_ID,
          })
        )[0];
        if (!verification || !verification.VERIFIED_AT) {
          if (!verification && emailAvailable)
            return {
              ...(await verifyAccountEmail(
                db,
                account.PERSON_ID,
                account.USERNAME,
              )),
              __httpStatus: 403,
              error:
                "Verify your email address before signing in. A verification link has been sent.",
            };
          if (!verification)
            throw bad(
              "Email delivery is not configured. Contact the application administrator to verify your account.",
              503,
            );
          return {
            __httpStatus: 403,
            error:
              "Verify your email address before signing in. You can request a new verification link.",
          };
        }
        const old = readToken(req);
        if (old)
          await db.remove("security.Sessions", { TOKEN_HASH: digest(old) });
        if (context.role === "admin") {
          const factor = (
            await db.list("security.Mfa", { PERSON_ID: account.PERSON_ID })
          )[0];
          if (factor?.ENABLED) {
            for (const previous of await db.list("security.MfaChallenges", {
              PERSON_ID: account.PERSON_ID,
            }))
              await db.remove("security.MfaChallenges", {
                TOKEN_HASH: previous.TOKEN_HASH,
              });
            const challenge = token();
            await db.insert("security.MfaChallenges", {
              TOKEN_HASH: digest(challenge),
              PERSON_ID: account.PERSON_ID,
              EXPIRES: new Date(Date.now() + 600000).toISOString(),
              FAILURES: 0,
            });
            setChallengeCookie(res, challenge);
            return { mfaRequired: true };
          }
          if (factor)
            await db.remove("security.Mfa", { PERSON_ID: account.PERSON_ID });
          const { csrf } = await issueSession(db, account.PERSON_ID, res);
          await audit(db, account.PERSON_ID, "login.password", {
            role: "admin",
          });
          return { user: context, csrf };
        }
        const { csrf } = await issueSession(db, account.PERSON_ID, res);
        await audit(db, account.PERSON_ID, "login", {});
        return { user: context, csrf };
      },
      { publicRoute: true },
    ),
  );
  router.post(
    "/auth/register",
    wrap(
      async (db, u, req) => {
        const b = req.body,
          username = text(b.email, 100).toLowerCase();
        if (!emailPattern.test(username) || hasRepeatedEmailSuffix(username))
          throw bad(
            "Enter a valid email address and check for a repeated domain suffix.",
          );
        const saIdNumber = normalizeSouthAfricanIdNumber(b.saIdNumber);
        if (!isValidSouthAfricanIdNumber(b.saIdNumber))
          throw bad(
            "Enter a valid 13-digit South African ID number with a valid, non-future date, or leave it blank.",
          );
        if (!emailAvailable)
          throw bad(
            "Email delivery is not configured. Contact the application administrator.",
            503,
          );
        if (await findAccountByUsername(db, username))
          throw bad("An account already uses that email.", 409);
        const personMatches = findPersonIdentityMatches(
          await db.list("PERSONS"),
          username,
        );
        if (personMatches.length)
          throw bad(personMatchMessage(personMatches), 409);
        await assertSaIdAvailable(db, saIdNumber);
        const school = await one(db, "SCHOOLS", { SCHOOL_ID: id(b.schoolId) }),
          hash = await passwordHash(b.password);
        const p = await db.createPerson(
          {
            FIRST_NAME: personName(b.firstName),
            LAST_NAME: personName(b.lastName),
            EMAIL: username,
            USERNAME: username,
            PHONE_NUMBER: null,
            SA_ID_NUMBER: saIdNumber || null,
          },
          { type: "L", schoolId: school.SCHOOL_ID },
        );
        await db.insert("security.Accounts", {
          ACCOUNT_ID: randomUUID(),
          PERSON_ID: p.PERSON_ID,
          USERNAME: username,
          PASSWORD_HASH: hash,
          DISABLED: 0,
        });
        await audit(db, p.PERSON_ID, "register", {});
        return {
          ...(await verifyAccountEmail(db, p.PERSON_ID, username)),
          message:
            "Account created. Check your email to verify the address before signing in.",
        };
      },
      { publicRoute: true },
    ),
  );
  router.post(
    "/auth/email/resend",
    wrap(
      async (db, u, req) => {
        const username = String(req.body.email || "")
          .trim()
          .toLowerCase();
        if (
          emailPattern.test(username) &&
          !hasRepeatedEmailSuffix(username) &&
          (await requestAllowed(db, req, "verify", username))
        ) {
          const account = await findAccountByUsername(db, username),
            verification =
              account &&
              (
                await db.list("security.EmailVerifications", {
                  PERSON_ID: account.PERSON_ID,
                })
              )[0];
          if (
            account &&
            !account.DISABLED &&
            (!verification || !verification.VERIFIED_AT)
          ) {
            const message = await ((await activeInvitation(
              db,
              account.PERSON_ID,
            ))
              ? accountInvitationMessage(db, account.PERSON_ID, username)
              : emailVerificationMessage(db, account.PERSON_ID, username));
            return {
              ...queueEmail(message),
              message:
                "If the address needs verification, a link will be sent shortly.",
            };
          }
        }
        return {
          message:
            "If the address needs verification, a link will be sent shortly.",
        };
      },
      { publicRoute: true, minimumDuration: 250 },
    ),
  );
  router.post(
    "/auth/email/verify",
    wrap(
      async (db, u, req) => {
        const raw = text(req.body.token, 200),
          stored = (
            await db.list("security.AccountTokens", {
              TOKEN_HASH: digest(raw),
              PURPOSE: "email-verification",
            })
          )[0];
        if (!stored || stored.EXPIRES <= now())
          throw bad(
            "This verification link is invalid or expired. Request another link.",
            400,
          );
        const verification = (
          await db.list("security.EmailVerifications", {
            PERSON_ID: stored.PERSON_ID,
          })
        )[0];
        if (verification)
          await db.update(
            "security.EmailVerifications",
            { PERSON_ID: stored.PERSON_ID },
            { VERIFIED_AT: now() },
          );
        else
          await db.insert("security.EmailVerifications", {
            PERSON_ID: stored.PERSON_ID,
            VERIFIED_AT: now(),
          });
        await db.remove("security.AccountTokens", {
          TOKEN_HASH: stored.TOKEN_HASH,
        });
        await audit(db, stored.PERSON_ID, "email.verify", {});
        return { message: "Email verified. You can now sign in." };
      },
      { publicRoute: true },
    ),
  );
  router.post(
    "/auth/password-reset",
    wrap(
      async (db, u, req) => {
        const email = String(req.body.email || "")
          .trim()
          .toLowerCase();
        if (
          emailPattern.test(email) &&
          !hasRepeatedEmailSuffix(email) &&
          (await requestAllowed(db, req, "password-reset", email))
        ) {
          const account = await findAccountByUsername(db, email);
          if (account && !account.DISABLED) {
            const verified = (
              await db.list("security.EmailVerifications", {
                PERSON_ID: account.PERSON_ID,
              })
            )[0];
            if (!verified || !verified.VERIFIED_AT) {
              if (emailAvailable) {
                const message = await ((await activeInvitation(
                  db,
                  account.PERSON_ID,
                ))
                  ? accountInvitationMessage(db, account.PERSON_ID, email)
                  : emailVerificationMessage(db, account.PERSON_ID, email));
                return {
                  ...queueEmail(message),
                  __httpStatus: 202,
                  message: genericResetMessage,
                };
              }
            } else {
              const raw = await issueToken(
                db,
                account.PERSON_ID,
                "password-reset",
                20,
              );
              return {
                ...queueEmail(
                  email,
                  "Reset your Varsity Vault password",
                  `A password reset was requested for your account. This link expires in 20 minutes and can be used once:\n\n${accountLink("/reset-password.html", raw)}\n\nIf you did not request this, ignore this message. Your password has not changed.`,
                ),
                __httpStatus: 202,
                message: genericResetMessage,
              };
            }
          }
        }
        return { __httpStatus: 202, message: genericResetMessage };
      },
      { publicRoute: true, minimumDuration: 250 },
    ),
  );
  router.post(
    "/auth/password-reset/complete",
    wrap(
      async (db, u, req) => {
        const raw = text(req.body.token, 200),
          password = req.body.password;
        if (password !== req.body.confirmPassword)
          throw bad("The passwords do not match.");
        const tokenHash = digest(raw),
          stored = (
            await db.list("security.AccountTokens", { TOKEN_HASH: tokenHash })
          )[0];
        if (
          !stored ||
          !["password-reset", "account-invitation"].includes(stored.PURPOSE) ||
          stored.EXPIRES <= now()
        )
          throw bad(
            "This reset or invitation link is invalid or expired. Request a new one.",
            400,
          );
        const account = (
          await db.list("security.Accounts", { PERSON_ID: stored.PERSON_ID })
        )[0];
        if (!account || account.DISABLED)
          throw bad(
            "This reset or invitation link is invalid or expired. Request a new one.",
            400,
          );
        const hash = await passwordHash(password);
        await db.update(
          "security.Accounts",
          { PERSON_ID: stored.PERSON_ID },
          { PASSWORD_HASH: hash },
        );
        if (stored.PURPOSE === "account-invitation") {
          const verified = (
            await db.list("security.EmailVerifications", {
              PERSON_ID: stored.PERSON_ID,
            })
          )[0];
          if (verified)
            await db.update(
              "security.EmailVerifications",
              { PERSON_ID: stored.PERSON_ID },
              { VERIFIED_AT: now() },
            );
          else
            await db.insert("security.EmailVerifications", {
              PERSON_ID: stored.PERSON_ID,
              VERIFIED_AT: now(),
            });
        }
        for (const item of await db.list("security.AccountTokens", {
          PERSON_ID: stored.PERSON_ID,
        }))
          await db.remove("security.AccountTokens", {
            TOKEN_HASH: item.TOKEN_HASH,
          });
        for (const session of await db.list("security.Sessions", {
          PERSON_ID: stored.PERSON_ID,
        }))
          await db.remove("security.Sessions", {
            TOKEN_HASH: session.TOKEN_HASH,
          });
        await audit(
          db,
          stored.PERSON_ID,
          stored.PURPOSE === "account-invitation"
            ? "account.invitation.accepted"
            : "password.reset",
          {},
        );
        return {
          message:
            stored.PURPOSE === "account-invitation"
              ? "Password set and email verified. Sign in to continue."
              : "Password reset. Sign in with your new password.",
        };
      },
      { publicRoute: true },
    ),
  );
  router.post(
    "/auth/mfa/verify",
    wrap(
      async (db, u, req, res) => {
        const challenge = readChallenge(req),
          record =
            challenge &&
            (
              await db.list("security.MfaChallenges", {
                TOKEN_HASH: digest(challenge),
              })
            )[0],
          factor =
            record &&
            (await db.list("security.Mfa", { PERSON_ID: record.PERSON_ID }))[0];
        if (!record || record.EXPIRES <= now() || !factor?.ENABLED) {
          setChallengeCookie(res, "", true);
          throw bad("The sign-in challenge expired. Sign in again.", 401);
        }
        if (!(await requestAllowed(db, req, "mfa", String(record.PERSON_ID))))
          return {
            __httpStatus: 429,
            error: "Too many verification attempts. Sign in again later.",
          };
        const supplied = String(req.body.code || "")
          .replace(/[ -]/g, "")
          .toLowerCase();
        let validStep = null,
          recoveryHashes = JSON.parse(factor.RECOVERY_HASHES || "[]"),
          recoveryIndex = -1;
        if (/^\d{6}$/.test(supplied)) {
          const secret = decryptSecret(factor.SECRET_CIPHERTEXT);
          validStep = verifyTotp(secret, supplied, factor.LAST_STEP);
        } else recoveryIndex = recoveryHashes.indexOf(digest(supplied));
        if (validStep === null && recoveryIndex < 0) {
          const failures = Number(record.FAILURES) + 1;
          if (failures >= 5) {
            await db.remove("security.MfaChallenges", {
              TOKEN_HASH: record.TOKEN_HASH,
            });
            setChallengeCookie(res, "", true);
          } else
            await db.update(
              "security.MfaChallenges",
              { TOKEN_HASH: record.TOKEN_HASH },
              { FAILURES: failures },
            );
          return {
            __httpStatus: 401,
            error: "That verification code is not valid.",
          };
        }
        if (validStep !== null)
          await db.update(
            "security.Mfa",
            { PERSON_ID: record.PERSON_ID },
            { LAST_STEP: validStep },
          );
        else {
          recoveryHashes.splice(recoveryIndex, 1);
          await db.update(
            "security.Mfa",
            { PERSON_ID: record.PERSON_ID },
            { RECOVERY_HASHES: JSON.stringify(recoveryHashes) },
          );
        }
        await db.remove("security.MfaChallenges", {
          TOKEN_HASH: record.TOKEN_HASH,
        });
        await clearRequestLimit(db, req, "mfa", String(record.PERSON_ID));
        setChallengeCookie(res, "", true);
        const context = await userContext(db, record.PERSON_ID),
          { csrf } = await issueSession(db, record.PERSON_ID, res);
        await audit(db, record.PERSON_ID, "login.mfa", {
          method: validStep === null ? "recovery-code" : "totp",
        });
        return { user: context, csrf };
      },
      { publicRoute: true },
    ),
  );
  router.post(
    "/me/mfa/setup",
    wrap(async (db, u, req) => {
      role(u, "admin");
      try {
        encryptionKey();
      } catch {
        throw bad(
          "Configure SECURITY_ENCRYPTION_KEY and restart before setting up administrator MFA.",
          503,
        );
      }
      const account = await one(db, "security.Accounts", {
        PERSON_ID: u.personId,
      });
      if (
        !(await checkPassword(req.body.currentPassword, account.PASSWORD_HASH))
      )
        throw bad("Current password is incorrect.", 400);
      const current = (
        await db.list("security.Mfa", { PERSON_ID: u.personId })
      )[0];
      if (current?.ENABLED)
        throw bad("Administrator MFA is already enabled.", 409);
      const secret = newTotpSecret(),
        payload = {
          PERSON_ID: u.personId,
          SECRET_CIPHERTEXT: encryptSecret(secret),
          RECOVERY_HASHES: "[]",
          ENABLED: 0,
          LAST_STEP: null,
          SETUP_FAILURES: 0,
        };
      if (current)
        await db.update("security.Mfa", { PERSON_ID: u.personId }, payload);
      else await db.insert("security.Mfa", payload);
      await audit(db, u.personId, "admin.mfa.setup.started", {});
      return {
        secret,
        provisioningUri: provisioningUri(secret, account.USERNAME),
      };
    }),
  );
  router.post(
    "/me/mfa/confirm",
    wrap(async (db, u, req, res) => {
      role(u, "admin");
      if (!(await requestAllowed(db, req, "mfa-setup", String(u.personId))))
        throw bad(
          "Too many verification attempts. Start setup again later.",
          429,
        );
      const factor = (
        await db.list("security.Mfa", { PERSON_ID: u.personId })
      )[0];
      if (!factor || factor.ENABLED)
        throw bad("Start administrator MFA setup first.", 409);
      const secret = decryptSecret(factor.SECRET_CIPHERTEXT),
        step = verifyTotp(secret, req.body.code);
      if (step === null) {
        const failures = Number(factor.SETUP_FAILURES || 0) + 1;
        if (failures >= 5) {
          await db.remove("security.Mfa", { PERSON_ID: u.personId });
          await audit(db, u.personId, "admin.mfa.setup.locked", {});
        } else
          await db.update(
            "security.Mfa",
            { PERSON_ID: u.personId },
            { SETUP_FAILURES: failures },
          );
        throw bad(
          failures >= 5
            ? "Too many incorrect codes. Start MFA setup again."
            : "Enter the current six-digit code from your authenticator app.",
          400,
        );
      }
      const recovery = makeRecoveryCodes();
      await db.update(
        "security.Mfa",
        { PERSON_ID: u.personId },
        {
          ENABLED: 1,
          LAST_STEP: step,
          RECOVERY_HASHES: JSON.stringify(recovery.hashes),
          SETUP_FAILURES: 0,
        },
      );
      await clearRequestLimit(db, req, "mfa-setup", String(u.personId));
      for (const session of await db.list("security.Sessions", {
        PERSON_ID: u.personId,
      }))
        await db.remove("security.Sessions", {
          TOKEN_HASH: session.TOKEN_HASH,
        });
      const { csrf } = await issueSession(db, u.personId, res);
      await audit(db, u.personId, "admin.mfa.enabled", {
        recoveryCodes: recovery.codes.length,
      });
      return {
        message:
          "Administrator MFA enabled. Save these recovery codes now; they will not be shown again.",
        recoveryCodes: recovery.codes,
        csrf,
      };
    }),
  );
  router.get(
    "/me",
    wrap(async (db, u, req, res, session) => {
      if (u.role === "admin") {
        const factor = (
          await db.list("security.Mfa", { PERSON_ID: u.personId })
        )[0];
        if (factor && !factor.ENABLED)
          await db.remove("security.Mfa", { PERSON_ID: u.personId });
      }
      return { user: u, csrf: session.CSRF, mode: store.mode };
    }),
  );
  router.post(
    "/auth/logout",
    wrap(async (db, u, req, res) => {
      await db.remove("security.Sessions", {
        TOKEN_HASH: digest(readToken(req)),
      });
      setCookie(res, "", true);
      return { message: "Signed out." };
    }),
  );
  router.post(
    "/me/password",
    wrap(async (db, u, req, res) => {
      const a = await one(db, "security.Accounts", { PERSON_ID: u.personId });
      if (!(await checkPassword(req.body.currentPassword, a.PASSWORD_HASH)))
        throw bad("Current password is incorrect.", 400);
      await db.update(
        "security.Accounts",
        { PERSON_ID: u.personId },
        { PASSWORD_HASH: await passwordHash(req.body.newPassword) },
      );
      for (const session of await db.list("security.Sessions", {
        PERSON_ID: u.personId,
      }))
        await db.remove("security.Sessions", {
          TOKEN_HASH: session.TOKEN_HASH,
        });
      await audit(db, u.personId, "password.change", {});
      setCookie(res, "", true);
      return { message: "Password changed. Sign in again." };
    }),
  );
  router.put(
    "/me/profile",
    wrap(async (db, u, req) => {
      const b = req.body;
      if (b.phone !== undefined && typeof b.phone !== "string")
        throw bad(
          "Phone number must be text containing 10 local digits, or blank.",
        );
      const phone = typeof b.phone === "string" ? b.phone.trim() : "";
      if (!isValidSouthAfricanPhone(phone))
        throw bad(
          "Enter a 10-digit South African phone number beginning with 0, or leave it blank.",
        );
      const patch = {
        FIRST_NAME: personName(b.firstName),
        LAST_NAME: personName(b.lastName),
        PHONE_NUMBER: phone || null,
      };
      if (Object.hasOwn(b, "saIdNumber")) {
        if (u.role !== "learner")
          throw bad(
            "Only learners can add or update their own South African ID number.",
            403,
          );
        const saIdNumber = normalizeSouthAfricanIdNumber(b.saIdNumber);
        const existingPerson = await one(db, "PERSONS", {
          PERSON_ID: u.personId,
        });
        const unchangedId =
          Boolean(existingPerson.SA_ID_NUMBER) &&
          normalizeSouthAfricanIdNumber(existingPerson.SA_ID_NUMBER) ===
            saIdNumber;
        if (!unchangedId && !isValidSouthAfricanIdNumber(b.saIdNumber))
          throw bad(
            "Enter a valid South African ID number with a valid, non-future date. Leave blank to keep the current value.",
          );
        if (saIdNumber && !unchangedId) {
          if (
            existingPerson.SA_ID_NUMBER &&
            normalizeSouthAfricanIdNumber(existingPerson.SA_ID_NUMBER) !==
              saIdNumber
          )
            throw bad(
              "Your saved ID number is read-only. Ask an administrator to correct it.",
              409,
            );
          await assertSaIdAvailable(db, saIdNumber, u.personId);
          patch.SA_ID_NUMBER = saIdNumber;
        }
      }
      await db.update("PERSONS", { PERSON_ID: u.personId }, patch);
      await audit(db, u.personId, "profile.update", {
        saIdNumberChanged: Boolean(patch.SA_ID_NUMBER),
      });
      return { message: "Profile saved." };
    }),
  );
  router.get(
    "/me/profile",
    wrap(async (db, u) => {
      const person = await one(db, "PERSONS", { PERSON_ID: u.personId });
      const account = await one(db, "security.Accounts", {
        PERSON_ID: u.personId,
      });
      const { SA_ID_NUMBER: saIdNumber, ...safePerson } = person;
      const learnerOwnsId =
        u.role === "learner" &&
        Boolean(normalizeSouthAfricanIdNumber(saIdNumber));
      return {
        user: u,
        person: safePerson,
        saIdNumber: learnerOwnsId
          ? normalizeSouthAfricanIdNumber(saIdNumber)
          : "",
        hasSaIdNumber: learnerOwnsId,
        saIdNumberMasked: learnerOwnsId ? maskSaIdNumber(saIdNumber) : null,
        identityWarnings: personIdentityWarnings(
          person,
          account.USERNAME,
          true,
        ),
      };
    }),
  );
  router.get(
    "/results",
    wrap(async (db, u, req) => {
      role(u, "learner", "teacher", "admin");
      const learnerId =
        u.role === "learner" ? u.recordId : id(req.query.learnerId);
      await scopedLearner(db, u, learnerId);
      await one(db, "EXAM_TYPES", { EXAM_TYPE_ID: id(req.query.examTypeId) });
      const currentVersion = await snapshot(
        db,
        u.personId,
        learnerId,
        id(req.query.examTypeId),
      );
      return {
        resultVersion: currentVersion.version,
        rows: await results(db, learnerId, id(req.query.examTypeId)),
        enrolled: await db.list("LEARNER_SUBJECTS", { LEARNER_ID: learnerId }),
        versions: await records(
          db,
          "admissions.results",
          `${learnerId}:${id(req.query.examTypeId)}`,
        ),
        verificationRequests: await records(
          db,
          "admissions.verification",
          `${learnerId}:${id(req.query.examTypeId)}`,
        ),
      };
    }),
  );
  router.get(
    "/results/summary",
    wrap(async (db, u) => {
      role(u, "learner");
      return { examTypeIds: await db.resultMilestones(u.recordId) };
    }),
  );
  router.put(
    "/results",
    wrap(async (db, u, req) => {
      role(u, "learner");
      const exam = await one(db, "EXAM_TYPES", {
        EXAM_TYPE_ID: id(req.body.examTypeId),
      });
      const rows = req.body.rows;
      if (
        !Array.isArray(rows) ||
        rows.length < 1 ||
        rows.length > 30 ||
        new Set(rows.map((r) => id(r?.subjectId))).size !== rows.length
      )
        throw bad(
          "Add at least one subject and use unique subject rows, maximum 30.",
        );
      const existing = await db.list("LEARNER_RESULTS", {
          LEARNER_ID: u.recordId,
          EXAM_TYPE_ID: exam.EXAM_TYPE_ID,
        }),
        verified = await verificationId(db, "Verified");
      if (existing.some((r) => sameId(r.VERIFICATION_STATUS_ID, verified)))
        throw bad(
          "Verified marks are locked. Ask your teacher to reject/unlock the affected result first.",
          409,
        );
      const subjects = await db.list("SUBJECTS");
      const pending = await verificationId(db, "Pending");
      const submittedCodes = new Set();
      for (const row of rows) {
        const subjectId = id(row?.subjectId),
          subject = subjects.find((s) => Number(s.SUBJECT_ID) === subjectId);
        if (!subject)
          throw bad(
            `Subject ID ${subjectId} is not in the current subject catalogue. Refresh the Results page and re-add that subject from the current list.`,
          );
        const subjectCode = String(subject.SUBJECT_CODE || "ID:" + subjectId)
          .trim()
          .toUpperCase();
        if (submittedCodes.has(subjectCode))
          throw bad("Use each subject only once for an examination milestone.");
        submittedCodes.add(subjectCode);
        if (
          subject.SCHOOL_ID != null &&
          Number(subject.SCHOOL_ID) !== Number(u.schoolId)
        )
          throw bad(
            `“${subject.SUBJECT_NAME}” is not available to your school.`,
          );
        if (
          typeof row.percentage !== "number" ||
          !Number.isFinite(row.percentage) ||
          row.percentage < 0 ||
          row.percentage > 100 ||
          Math.abs(row.percentage * 100 - Math.round(row.percentage * 100)) >
            1e-8
        )
          throw bad(
            `Enter a percentage from 0 to 100 for “${subject.SUBJECT_NAME}”.`,
          );
      }
      const priorVersion = await snapshot(
        db,
        u.personId,
        u.recordId,
        exam.EXAM_TYPE_ID,
      );
      if (req.body.expectedVersion !== priorVersion.version)
        throw bad(
          "Results changed since you opened them. Reload before saving.",
          409,
        );
      const submittedIds = new Set(rows.map((row) => id(row.subjectId)));
      for (const saved of existing) {
        if (
          ![...submittedIds].some((submittedId) =>
            sameId(submittedId, saved.SUBJECT_ID),
          )
        ) {
          await db.remove("LEARNER_RESULTS", {
            LEARNER_ID: u.recordId,
            SUBJECT_ID: saved.SUBJECT_ID,
            EXAM_TYPE_ID: exam.EXAM_TYPE_ID,
          });
        }
      }
      for (const row of rows) {
        const subjectId = id(row.subjectId);
        const key = {
          LEARNER_ID: u.recordId,
          SUBJECT_ID: subjectId,
          EXAM_TYPE_ID: exam.EXAM_TYPE_ID,
        };
        const values = {
          PERCENTAGE: row.percentage,
          VERIFICATION_STATUS_ID: pending,
          VERIFIED_BY_TEACHER_ID: null,
          VERIFIED_DATE: null,
        };
        if (existing.some((saved) => sameId(saved.SUBJECT_ID, subjectId))) {
          await db.update("LEARNER_RESULTS", key, values);
        } else {
          await db.insert("LEARNER_RESULTS", { ...key, ...values });
        }
        const enrolled = await db.list("LEARNER_SUBJECTS", {
          LEARNER_ID: u.recordId,
          SUBJECT_ID: subjectId,
        });
        if (!enrolled.length)
          await db.insert("LEARNER_SUBJECTS", {
            LEARNER_ID: u.recordId,
            SUBJECT_ID: subjectId,
            ENROLLMENT_DATE: date().slice(0, 10),
          });
      }
      const savedVersion = await snapshot(
        db,
        u.personId,
        u.recordId,
        exam.EXAM_TYPE_ID,
      );
      await audit(db, u.personId, "results.save", {
        examTypeId: exam.EXAM_TYPE_ID,
        count: rows.length,
      });
      return {
        message: "Results saved. Request teacher verification when ready.",
        resultVersion: savedVersion.version,
      };
    }),
  );
  router.get(
    "/results/versions",
    wrap(async (db, u, req) => {
      role(u, "learner", "teacher", "admin");
      const learnerId =
        u.role === "learner" ? u.recordId : id(req.query.learnerId);
      await scopedLearner(db, u, learnerId);
      const examId = id(req.query.examTypeId);
      return {
        versions: await records(
          db,
          "admissions.results",
          `${learnerId}:${examId}`,
        ),
        requests: await records(
          db,
          "admissions.verification",
          `${learnerId}:${examId}`,
        ),
      };
    }),
  );
  router.post(
    "/results/request-verification",
    wrap(async (db, u, req) => {
      role(u, "learner");
      const examId = id(req.body.examTypeId);
      await one(db, "EXAM_TYPES", { EXAM_TYPE_ID: examId });
      const current = await snapshot(db, u.personId, u.recordId, examId);
      if (!curriculum(await results(db, u.recordId, examId)))
        throw bad("Save a complete curriculum before requesting verification.");
      if (req.body.resultVersion !== current.version)
        throw bad(
          "Results changed. Reload before requesting verification.",
          409,
        );
      const requests = await records(
        db,
        "admissions.verification",
        `${u.recordId}:${examId}`,
      );
      if (requests.at(-1)?.resultVersion === current.version)
        throw bad(
          "Verification has already been requested for this version.",
          409,
        );
      await append(
        db,
        u.personId,
        "admissions.verification",
        `${u.recordId}:${examId}`,
        {
          resultVersion: current.version,
        },
      );
      return {
        message:
          "Teacher verification requested for result version " +
          current.version +
          ".",
      };
    }),
  );
  router.post(
    "/applications/:id/supply-results",
    wrap(async (db, u, req) => {
      role(u, "learner");
      const app = await scopeApp(db, u, id(req.params.id));
      requireVersion(await reviewVersion(db, app), req.body.reviewToken);
      const state = (
        await one(db, "APPLICATION_STATUSES", { STATUS_ID: app.STATUS_ID })
      ).STATUS_NAME;
      if (["Rejected", "Admitted", "Offer Revoked"].includes(state))
        throw bad("This application is closed to updated evidence.", 409);
      const examId = id(req.body.examTypeId);
      const current = await snapshot(db, u.personId, u.recordId, examId);
      if (
        current.version !== req.body.resultVersion ||
        !curriculum(await results(db, u.recordId, examId))
      )
        throw bad("Select the current complete saved result version.", 409);
      const verified = await verificationId(db, "Verified");
      if (current.rows.some((r) => !sameId(r.VERIFICATION_STATUS_ID, verified)))
        throw bad("Ask your teacher to verify this result version first.", 409);
      const ex = await one(db, "EXAM_TYPES", { EXAM_TYPE_ID: examId });
      const required = ["Submitted", "Screened by Career Teacher"].includes(
        state,
      )
        ? "Grade 11 Final"
        : "Grade 12 Final (NSC)";
      if (ex.EXAM_TYPE_NAME !== required)
        throw bad("Supply " + required + " for this stage.", 409);
      await append(
        db,
        u.personId,
        "admissions.binding",
        String(app.APPLICATION_ID),
        {
          examId,
          resultVersion: current.version,
          rows: current.rows,
        },
      );
      await history(db, app, "Updated results supplied", u);
      return {
        message: "Verified result version attached to this application.",
      };
    }),
  );
  router.get(
    "/scoring-policies",
    wrap(async (db, u) => {
      role(u, "admin", "representative");
      const all = (
        await db.list("security.Audit", { EVENT: "admissions.policy" })
      ).map((r) => JSON.parse(r.DETAIL));
      const latest = new Map();
      for (const p of all)
        if (!latest.has(p.key) || latest.get(p.key).version < p.version)
          latest.set(p.key, p);
      return {
        policies: [...latest.values()].filter(
          (p) => u.role === "admin" || sameId(p.universityId, u.universityId),
        ),
      };
    }),
  );
  router.post(
    "/scoring-policies",
    wrap(async (db, u, req) => {
      role(u, "admin", "representative");
      const universityId = id(req.body.universityId);
      await one(db, "UNIVERSITIES", { UNIVERSITY_ID: universityId });
      if (u.role === "representative" && !sameId(universityId, u.universityId))
        throw bad("University outside your scope.", 403);
      const key = req.body.policyId || newPolicyId();
      const old = (await records(db, "admissions.policy", key)).at(-1);
      if (req.body.policyId && !old) throw bad("Policy not found.", 404);
      if (
        old &&
        (!sameId(old.universityId, universityId) ||
          old.version !== req.body.expectedVersion)
      )
        throw bad("Policy changed or belongs to another university.", 409);
      const known = new Set(
        (await db.list("SUBJECTS")).map((r) => r.SUBJECT_CODE),
      );
      let scoring;
      try {
        scoring = validateScoring(req.body.scoring, known);
      } catch (e) {
        throw bad(e.message);
      }
      httpsUrl(req.body.source, "Policy source");
      const policy = await append(db, u.personId, "admissions.policy", key, {
        name: text(req.body.name),
        universityId,
        source: req.body.source,
        scoring,
      });
      return { policy, message: "Reusable scoring policy saved." };
    }),
  );
  router.get(
    "/offerings",
    wrap(async (db, u) => {
      const all = [];
      for (const row of await db.list(
        "UNI_QUALIFICATIONS",
        u.role === "representative" ? { UNIVERSITY_ID: u.universityId } : {},
      ))
        all.push(await offering(db, row.UNI_QUAL_ID));
      return { offerings: all };
    }),
  );
  router.get(
    "/offerings/:id/requirements",
    wrap(async (db, u, req) => {
      role(u, "learner");
      return assessment(db, u, id(req.params.id), id(req.query.examTypeId));
    }),
  );
  router.get(
    "/documents",
    wrap(async (db, u, req) => {
      let personId = u.personId;
      if (req.query.learnerId) {
        const l = await scopedLearner(db, u, id(req.query.learnerId));
        personId = l.PERSON_ID;
      }
      const docs = await db.list("DOCUMENTS", { PERSON_ID: personId });
      return { documents: docs.map(({ DOCUMENT_BLOB, ...d }) => d) };
    }),
  );
  router.post(
    "/documents",
    express.raw({
      type: ["application/pdf", "image/png", "image/jpeg"],
      limit: "6mb",
    }),
    wrap(async (db, u, req) => {
      role(u, "learner");
      const type = await one(db, "DOCUMENT_TYPES", {
        DOCUMENT_TYPE_ID: id(req.get("x-document-type")),
      });
      if (!Buffer.isBuffer(req.body) || !req.body.length)
        throw bad("Upload a PDF, PNG or JPEG, up to 6 MB.");
      const data = req.body,
        mime = req.get("content-type").split(";")[0];
      if (!(
        (mime === "application/pdf" &&
          data.subarray(0, 5).toString() === "%PDF-") ||
        (mime === "image/png" &&
          data
            .subarray(0, 8)
            .equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) ||
        (mime === "image/jpeg" &&
          data[0] === 255 &&
          data[1] === 216 &&
          data[2] === 255)
      ))
        throw bad("The file signature does not match its type.");
      const apps = await db.list("APPLICATIONS", { LEARNER_ID: u.recordId }),
        statuses = await db.list("APPLICATION_STATUSES");
      if (
        type.IS_LOCKED_UNTIL_FINAL &&
        !apps.some((a) =>
          [
            "Provisionally Accepted",
            "Final Matric Verified",
            "Admitted",
            "Offer Revoked",
          ].includes(
            statuses.find((s) => sameId(s.STATUS_ID, a.STATUS_ID))?.STATUS_NAME,
          ),
        )
      )
        throw bad(
          "Final NSC uploads unlock after provisional acceptance.",
          409,
        );
      const name = safeFilename(req.get("x-file-name"));
      const pending = await verificationId(db, "Pending");
      await db.insert("DOCUMENTS", {
        DOCUMENT_NAME: type.DOCUMENT_TYPE_NAME,
        DOCUMENT_TYPE_ID: type.DOCUMENT_TYPE_ID,
        UPLOAD_DATE: date(),
        PERSON_ID: u.personId,
        FILE_NAME: name,
        MIME_TYPE: mime,
        DOCUMENT_BLOB: data,
        VERIFICATION_STATUS_ID: pending,
        VERIFIED_BY_TEACHER_ID: null,
        VERIFIED_DATE: null,
      });
      await audit(db, u.personId, "document.upload", {
        typeId: type.DOCUMENT_TYPE_ID,
        bytes: data.length,
      });
      return { message: "Document uploaded." };
    }),
  );
  router.get(
    "/documents/:id/download",
    wrap(async (db, u, req, res) => {
      const d = await one(db, "DOCUMENTS", { DOCUMENT_ID: id(req.params.id) });
      let allowed = sameId(d.PERSON_ID, u.personId) || u.role === "admin";
      const l = (await db.list("LEARNERS", { PERSON_ID: d.PERSON_ID }))[0];
      if (l && u.role === "teacher") allowed = sameId(l.SCHOOL_ID, u.schoolId);
      if (l && u.role === "representative") {
        const apps = await db.list("APPLICATIONS", { LEARNER_ID: l.PERSON_ID });
        for (const a of apps) {
          const o = await offering(db, a.UNI_QUAL_ID);
          if (
            sameId(o.UNIVERSITY_ID, u.universityId) &&
            !sameId(a.STATUS_ID, await statusId(db, "Submitted"))
          )
            allowed = true;
        }
      }
      if (!allowed) throw bad("Document is outside your scope.", 403);
      if (!d.DOCUMENT_BLOB?.length)
        throw bad(
          "No uploaded file is available for this document. Ask the learner to upload it again.",
          404,
        );
      res
        .type(d.MIME_TYPE || "application/octet-stream")
        .set(
          "Content-Disposition",
          'attachment; filename="' +
            safeFilename(d.FILE_NAME || d.DOCUMENT_NAME || "document.pdf") +
            '"',
        )
        .send(Buffer.from(d.DOCUMENT_BLOB));
    }),
  );
  router.get(
    "/applications",
    wrap(async (db, u) => {
      const applications = [];
      for (const row of await db.allApplications(u)) {
        const application = await one(db, "APPLICATIONS", {
          APPLICATION_ID: row.APPLICATION_ID,
        });
        const reviewToken = await reviewVersion(db, application);
        applications.push({ ...dashboardApplication(row), reviewToken });
      }
      return { applications };
    }),
  );
  router.get(
    "/dashboard/summary",
    wrap(async (db, u) => {
      const summary = {
        applications: [],
        applicationCount: 0,
        actionQueue: [],
        closingSoon: [],
        counts: {},
      };
      const appAction = (application, href, label) => ({
        id: application.APPLICATION_ID,
        title: application.learnerName,
        detail: application.offering.qualification,
        context: application.offering.university,
        status: application.status,
        date: application.APPLICATION_DATE,
        href,
        label,
      });
      if (u.role === "learner") {
        const applications = await db.dashboardApplications(u, {
          limit: 8,
          order: "DESC",
        });
        summary.applications = applications.map(dashboardApplication);
        summary.applicationCount = Number(applications[0]?.TOTAL_COUNT || 0);
        summary.counts.results = await db.count("LEARNER_RESULTS", {
          LEARNER_ID: u.recordId,
        });
        summary.counts.documents = await db.count("DOCUMENTS", {
          PERSON_ID: u.personId,
        });
        const dateLimit = new Date(Date.now() + 30 * 86400000),
          closingFrom = today(),
          closingTo = new Intl.DateTimeFormat("en-CA", {
            timeZone: "Africa/Johannesburg",
            year: "numeric",
            month: "2-digit",
            day: "2-digit",
          }).format(dateLimit);
        summary.closingSoon = (
          await db.dashboardOfferings({ closingFrom, closingTo, limit: 4 })
        ).map((row) => ({
          id: row.UNI_QUAL_ID,
          title: row.QUAL_NAME,
          university: row.UNIVERSITY_NAME,
          date: row.APPLICATION_CLOSING_DATE,
        }));
      } else if (u.role === "teacher") {
        const queue = await db.dashboardApplications(u, {
          status: "Submitted",
          limit: 8,
          order: "ASC",
        });
        summary.actionQueue = queue.map((a) =>
          appAction(
            dashboardApplication(a),
            "/teacher/applications.html",
            "Screen application",
          ),
        );
        summary.counts.awaitingScreening = Number(queue[0]?.TOTAL_COUNT || 0);
        summary.counts.learners = await db.count("LEARNERS", {
          SCHOOL_ID: u.schoolId,
        });
      } else if (u.role === "representative") {
        const queue = await db.dashboardApplications(u, {
          status: "Screened by Career Teacher",
          limit: 8,
          order: "ASC",
        });
        summary.actionQueue = queue.map((a) =>
          appAction(
            dashboardApplication(a),
            "/representative/decisions.html",
            "Review decision",
          ),
        );
        summary.counts.awaitingReview = Number(queue[0]?.TOTAL_COUNT || 0);
        summary.applicationCount = await db.dashboardApplicationCount(u);
      } else if (u.role === "admin") {
        summary.counts.accounts = await db.count("security.Accounts");
        summary.counts.universities = await db.count("UNIVERSITIES");
        summary.counts.offerings = await db.count("UNI_QUALIFICATIONS");
        const queue = await db.dashboardOfferings({
          unverified: true,
          limit: 8,
        });
        summary.actionQueue = queue.map((item) => ({
          id: item.UNI_QUAL_ID,
          title: item.QUAL_NAME,
          detail: item.UNIVERSITY_NAME,
          context:
            item.POLICY_STATUS === "pending"
              ? "Needs source verification"
              : "Review 2028 source and deadline",
          status: item.POLICY_STATUS,
          date: item.APPLICATION_CLOSING_DATE,
          href: "/admin/offerings.html",
          label: "Review requirements",
        }));
      }
      return summary;
    }),
  );
  router.post(
    "/applications",
    wrap(async (db, u, req) => {
      role(u, "learner");
      const offerId = id(req.body.offeringId),
        studyMode = await one(db, "STUDY_MODES", {
          STUDY_MODE_ID: id(req.body.studyModeId),
        }),
        exam = await one(db, "EXAM_TYPES", {
          EXAM_TYPE_NAME: "Grade 11 Final",
        }),
        check = await assessment(db, u, offerId, exam.EXAM_TYPE_ID);
      if (!check.eligible)
        throw bad(check.status + ": " + check.issues.join(" "), 409);
      const closes = check.offering.APPLICATION_CLOSING_DATE;
      if (offeringAvailability(check.offering.config, closes) !== "Open")
        throw bad(
          "This offering is closed or its deadline is unverified.",
          409,
        );
      if (
        (
          await db.list("APPLICATIONS", {
            LEARNER_ID: u.recordId,
            UNI_QUAL_ID: offerId,
            ACADEMIC_YEAR: 2028,
          })
        ).length
      )
        throw bad("You already applied for this qualification in 2028.", 409);
      for (const type of (await db.list("DOCUMENT_TYPES")).filter((t) =>
        isRequiredBeforeProvisional(t, check.offering.config),
      )) {
        const docs = await db.list("DOCUMENTS", {
          PERSON_ID: u.personId,
          DOCUMENT_TYPE_ID: type.DOCUMENT_TYPE_ID,
        });
        if (!docs.some((d) => d.DOCUMENT_BLOB?.length))
          throw bad(
            "Upload " + type.DOCUMENT_TYPE_NAME + " before submitting.",
            409,
          );
      }
      const a = await db.insert("APPLICATIONS", {
        APPLICATION_DATE: date(),
        ACADEMIC_YEAR: 2028,
        STUDY_MODE_ID: studyMode.STUDY_MODE_ID,
        UNI_QUAL_ID: offerId,
        LEARNER_ID: u.recordId,
        TEACHER_ID: null,
        STATUS_ID: await statusId(db, "Submitted"),
        REVIEWED_BY_REP_ID: null,
        REVIEW_DATE: null,
        REVIEW_NOTES: null,
      });
      const initial = await snapshot(
        db,
        u.personId,
        u.recordId,
        exam.EXAM_TYPE_ID,
      );
      await append(
        db,
        u.personId,
        "admissions.binding",
        String(a.APPLICATION_ID),
        {
          examId: exam.EXAM_TYPE_ID,
          resultVersion: initial.version,
          rows: initial.rows,
        },
      );
      await history(db, a, "Submitted", u);
      return {
        application: a,
        message: "Application submitted for teacher screening.",
      };
    }),
  );
  router.get(
    "/applications/:id/timeline",
    wrap(async (db, u, req) => {
      const a = await scopeApp(db, u, id(req.params.id)),
        actions = await db.list("ACTIONS");
      return {
        resultBindings: await records(
          db,
          "admissions.binding",
          String(a.APPLICATION_ID),
        ),
        timeline: (
          await db.list("APPLICATION_PROCESSES", {
            APPLICATION_ID: a.APPLICATION_ID,
          })
        )
          .sort((x, y) => x.APP_PROC_ID - y.APP_PROC_ID)
          .map((r) => ({
            ...r,
            status: actions.find((v) => sameId(v.ACTION_ID, r.ACTION_ID))
              ?.ACTION_NAME,
          })),
      };
    }),
  );
  router.get(
    "/applications/:id/evidence",
    wrap(async (db, u, req) => {
      role(u, "representative", "teacher", "admin");
      const a = await scopeApp(db, u, id(req.params.id));
      if (
        u.role === "representative" &&
        sameId(a.STATUS_ID, await statusId(db, "Submitted"))
      )
        throw bad("Teacher screening is required before evidence review.", 403);
      const learner = await one(db, "LEARNERS", { PERSON_ID: a.LEARNER_ID }),
        exams = [];
      for (const ex of await db.list("EXAM_TYPES"))
        exams.push({
          name: ex.EXAM_TYPE_NAME,
          rows: await results(db, learner.PERSON_ID, ex.EXAM_TYPE_ID),
        });
      return {
        exams,
        resultBindings: await records(
          db,
          "admissions.binding",
          String(a.APPLICATION_ID),
        ),
        documents: (
          await db.list("DOCUMENTS", { PERSON_ID: learner.PERSON_ID })
        ).map(({ DOCUMENT_BLOB, ...d }) => d),
      };
    }),
  );
  router.get(
    "/teacher/learners",
    wrap(async (db, u) => {
      role(u, "teacher");
      const out = [];
      for (const l of await db.list("LEARNERS", { SCHOOL_ID: u.schoolId })) {
        const p = await one(db, "PERSONS", { PERSON_ID: l.PERSON_ID });
        out.push({
          ...l,
          name: p.FIRST_NAME + " " + p.LAST_NAME,
          email: p.EMAIL,
        });
      }
      return { learners: out };
    }),
  );
  router.post(
    "/teacher/verify",
    wrap(async (db, u, req) => {
      role(u, "teacher");
      if (!["Verified", "Rejected"].includes(req.body.decision))
        throw bad("Choose Verified or Rejected.");
      const l = await scopedLearner(db, u, id(req.body.learnerId)),
        verified = await verificationId(
          db,
          req.body.decision === "Rejected" ? "Rejected" : "Verified",
        );
      if (req.body.documentId) {
        const d = await one(db, "DOCUMENTS", {
          DOCUMENT_ID: id(req.body.documentId),
        });
        if (!sameId(d.PERSON_ID, l.PERSON_ID))
          throw bad("Document does not belong to this learner.", 403);
        if (req.body.decision === "Verified" && !d.DOCUMENT_BLOB?.length)
          throw bad(
            "The learner must upload the document file before it can be verified.",
            409,
          );
        await db.update(
          "DOCUMENTS",
          { DOCUMENT_ID: d.DOCUMENT_ID },
          {
            VERIFICATION_STATUS_ID: verified,
            VERIFIED_BY_TEACHER_ID: u.recordId,
            VERIFIED_DATE: date(),
          },
        );
      } else {
        const examId = id(req.body.examTypeId),
          rows = await results(db, l.PERSON_ID, examId);
        if (!curriculum(rows))
          throw bad("The learner curriculum is incomplete.");
        const version = await snapshot(db, u.personId, l.PERSON_ID, examId);
        if (req.body.resultVersion !== version.version)
          throw bad("Learner results changed. Reload before verifying.", 409);
        await db.update(
          "LEARNER_RESULTS",
          { LEARNER_ID: l.PERSON_ID, EXAM_TYPE_ID: examId },
          {
            VERIFICATION_STATUS_ID: verified,
            VERIFIED_BY_TEACHER_ID: u.recordId,
            VERIFIED_DATE: date(),
          },
        );
      }
      if (!req.body.documentId)
        await snapshot(db, u.personId, l.PERSON_ID, id(req.body.examTypeId));
      await audit(db, u.personId, "teacher.verify", req.body);
      return { message: "Verification recorded." };
    }),
  );
  router.get(
    "/applications/:id/review",
    wrap(async (db, u, req) => {
      role(u, "representative");
      const a = await scopeApp(db, u, id(req.params.id));
      const current = (
        await one(db, "APPLICATION_STATUSES", { STATUS_ID: a.STATUS_ID })
      ).STATUS_NAME;
      const statusRows = await db.list("APPLICATION_STATUSES");
      const actionRows = await db.list("ACTIONS");
      const actions = [];
      for (const target of representativeTransitions[current] || []) {
        let reason = null;
        try {
          await checkApplicationTransition(db, u, a, target);
        } catch (error) {
          if (error.status >= 400 && error.status < 500) reason = error.message;
          else throw error;
        }
        const statusRow = statusRows.find((row) => row.STATUS_NAME === target);
        const actionRow = actionRows.find((row) => row.ACTION_NAME === target);
        if (!statusRow || !actionRow)
          reason =
            "The administrator must configure the status and matching history action.";
        actions.push({
          statusId: statusRow?.STATUS_ID ?? null,
          actionId: actionRow?.ACTION_ID ?? null,
          status: statusRow?.STATUS_NAME || target,
          label: decisionLabels[target],
          enabled: reason === null,
          reason,
        });
      }
      const explanation =
        current === "Submitted"
          ? "Waiting for the career educator to verify the learner’s Grade 11 results and required documents, then screen this application. A university decision is available after screening."
          : current === "Provisionally Accepted"
            ? "Verified Grade 12 final NSC results and a verified final certificate are required. Saved verified evidence is available automatically; no separate results attachment is needed."
            : ["Admitted", "Rejected", "Offer Revoked"].includes(current)
              ? "This is a completed decision. There are no further status changes in the current admissions workflow."
              : current === "Final Matric Verified"
                ? "Review the verified final evidence, then admit the learner if the programme requirements are met or revoke the offer."
                : "Review the teacher-screened application and its evidence, then record a provisional acceptance or rejection.";
      return {
        currentStatus: current,
        explanation,
        actions,
        canReviewEvidence: current !== "Submitted",
        reviewToken: await reviewVersion(db, a),
        previousNotes: a.REVIEW_NOTES || "",
        checklist: await applicationEvidenceChecklist(db, a, current),
      };
    }),
  );
  router.post(
    "/applications/:id/transition",
    wrap(async (db, u, req) => {
      const a = await scopeApp(db, u, id(req.params.id));
      const chosen =
        req.body.statusId != null
          ? await one(db, "APPLICATION_STATUSES", {
              STATUS_ID: id(req.body.statusId),
            })
          : await one(db, "APPLICATION_STATUSES", {
              STATUS_NAME: text(req.body.status),
            });
      const target = chosen.STATUS_NAME;
      if (req.body.status != null && req.body.status !== target)
        throw bad("Selected status does not match its database identifier.");
      await one(db, "ACTIONS", { ACTION_NAME: target });
      requireVersion(await reviewVersion(db, a), req.body.reviewToken);
      await checkApplicationTransition(db, u, a, target);
      const notes = req.body.notes ? text(req.body.notes, 400) : null;
      if (
        [
          "Screened by Career Teacher",
          "Provisionally Accepted",
          "Final Matric Verified",
          "Admitted",
        ].includes(target)
      ) {
        const examName = ["Final Matric Verified", "Admitted"].includes(target)
          ? "Grade 12 Final (NSC)"
          : "Grade 11 Final";
        const exam = await one(db, "EXAM_TYPES", { EXAM_TYPE_NAME: examName });
        const bindings = await records(
          db,
          "admissions.binding",
          String(a.APPLICATION_ID),
        );
        const bound = bindings
          .filter((b) => sameId(b.examId, exam.EXAM_TYPE_ID))
          .at(-1);
        const latest = await snapshot(
          db,
          u.personId,
          a.LEARNER_ID,
          exam.EXAM_TYPE_ID,
        );
        if (!bound || bound.resultVersion !== latest.version)
          await append(
            db,
            u.personId,
            "admissions.binding",
            String(a.APPLICATION_ID),
            {
              examId: exam.EXAM_TYPE_ID,
              resultVersion: latest.version,
              rows: latest.rows,
            },
          );
      }
      if (target === "Screened by Career Teacher")
        await db.update(
          "APPLICATIONS",
          { APPLICATION_ID: a.APPLICATION_ID },
          { TEACHER_ID: u.recordId },
        );
      else
        await db.update(
          "APPLICATIONS",
          { APPLICATION_ID: a.APPLICATION_ID },
          {
            REVIEWED_BY_REP_ID: u.recordId,
            REVIEW_DATE: date(),
            REVIEW_NOTES: notes,
          },
        );
      await db.update(
        "APPLICATIONS",
        { APPLICATION_ID: a.APPLICATION_ID },
        { STATUS_ID: await statusId(db, target) },
      );
      await audit(db, u.personId, "admissions.decision", {
        applicationId: a.APPLICATION_ID,
        reviewToken: req.body.reviewToken,
        target,
        notes,
      });
      await history(db, a, target, u);
      return { message: "Application moved to " + target + "." };
    }),
  );
  router.post(
    "/admin/accounts",
    wrap(async (db, u, req) => {
      role(u, "admin");
      if (!emailAvailable)
        throw bad(
          "Email delivery is not configured. Contact the application administrator.",
          503,
        );
      const b = req.body,
        username = text(b.email, 100).toLowerCase();
      if (!emailPattern.test(username) || hasRepeatedEmailSuffix(username))
        throw bad(
          "Enter a valid email address and check for a repeated domain suffix.",
        );
      if (!["learner", "teacher", "representative", "admin"].includes(b.role))
        throw bad("Choose a valid role.");
      const saIdNumber =
        b.role === "learner" ? normalizeSouthAfricanIdNumber(b.saIdNumber) : "";
      if (b.role === "learner" && !isValidSouthAfricanIdNumber(b.saIdNumber))
        throw bad(
          "Enter a valid 13-digit South African ID number with a valid, non-future date, or leave it blank.",
        );
      if (b.role !== "learner" && normalizeSouthAfricanIdNumber(b.saIdNumber))
        throw bad(
          "A South African ID number can only be supplied when creating a learner account.",
        );
      await assertSaIdAvailable(db, saIdNumber);
      let school = null,
        university = null;
      if (["learner", "teacher", "admin"].includes(b.role))
        school = await one(db, "SCHOOLS", { SCHOOL_ID: id(b.schoolId) });
      if (b.role === "representative")
        university = await one(db, "UNIVERSITIES", {
          UNIVERSITY_ID: id(b.universityId),
        });
      if (await findAccountByUsername(db, username))
        throw bad("An account already uses that email.", 409);
      const personMatches = findPersonIdentityMatches(
        await db.list("PERSONS"),
        username,
      );
      if (personMatches.length)
        throw bad(personMatchMessage(personMatches), 409);
      const p = await db.createPerson(
        {
          FIRST_NAME: personName(b.firstName),
          LAST_NAME: personName(b.lastName),
          EMAIL: username,
          USERNAME: username,
          PHONE_NUMBER: null,
          SA_ID_NUMBER: saIdNumber || null,
        },
        {
          type: { learner: "L", teacher: "T", representative: "R", admin: "A" }[
            b.role
          ],
          schoolId: school?.SCHOOL_ID,
          universityId: university?.UNIVERSITY_ID,
        },
      );
      const invited = typeof b.password !== "string" || !b.password,
        initialPassword = invited ? token() : b.password;
      await db.insert("security.Accounts", {
        ACCOUNT_ID: randomUUID(),
        PERSON_ID: p.PERSON_ID,
        USERNAME: username,
        PASSWORD_HASH: await passwordHash(initialPassword),
        DISABLED: 0,
      });
      await audit(db, u.personId, "account.create", {
        personId: p.PERSON_ID,
        role: b.role,
        invitation: invited,
      });
      return {
        ...(await (invited
          ? inviteAccount(db, p.PERSON_ID, username)
          : verifyAccountEmail(db, p.PERSON_ID, username))),
        message: invited
          ? "Account created. A secure setup link was emailed to the user."
          : "Account created. A verification link was emailed to the user.",
      };
    }),
  );
  router.get(
    "/admin/unlinked",
    wrap(async (db, u) => {
      role(u, "admin");
      const linked = await db.list("security.Accounts"),
        people = [];
      for (const p of await db.list("PERSONS"))
        if (!linked.some((account) => sameId(account.PERSON_ID, p.PERSON_ID))) {
          const context = await userContext(db, p.PERSON_ID);
          if (context)
            people.push({
              ...context,
              identityWarnings: personIdentityWarnings(p, p.EMAIL, true),
            });
        }
      return { people };
    }),
  );
  router.post(
    "/admin/accounts/link",
    wrap(async (db, u, req) => {
      role(u, "admin");
      if (!emailAvailable)
        throw bad(
          "Email delivery is not configured. Contact the application administrator.",
          503,
        );
      const personId = id(req.body.personId),
        context = await userContext(db, personId);
      if (!context)
        throw bad("The existing person must have exactly one assigned role.");
      const existingAccounts = await db.list("security.Accounts");
      if (
        existingAccounts.some((account) => sameId(account.PERSON_ID, personId))
      )
        throw bad("This person already has an account.", 409);
      const username = text(req.body.email, 100).toLowerCase();
      if (!emailPattern.test(username) || hasRepeatedEmailSuffix(username))
        throw bad(
          "Enter a valid email and check for a repeated domain suffix.",
        );
      if (await findAccountByUsername(db, username))
        throw bad("That login already exists.", 409);
      const identityMatches = findPersonIdentityMatches(
        await db.list("PERSONS"),
        username,
        personId,
      );
      if (identityMatches.length)
        throw bad(personMatchMessage(identityMatches), 409);
      const invited =
        typeof req.body.password !== "string" || !req.body.password;
      await db.update(
        "PERSONS",
        { PERSON_ID: personId },
        { EMAIL: username, USERNAME: username },
      );
      await db.insert("security.Accounts", {
        ACCOUNT_ID: randomUUID(),
        PERSON_ID: personId,
        USERNAME: username,
        PASSWORD_HASH: await passwordHash(
          invited ? token() : req.body.password,
        ),
        DISABLED: 0,
      });
      await audit(db, u.personId, "account.link", {
        personId,
        invitation: invited,
      });
      return {
        ...(await (invited
          ? inviteAccount(db, personId, username)
          : verifyAccountEmail(db, personId, username))),
        message: invited
          ? "Existing person linked. A secure setup link was emailed to the user."
          : "Existing person linked. A verification link was emailed to the user.",
      };
    }),
  );
  router.patch(
    "/admin/people/:id",
    wrap(async (db, u, req) => {
      role(u, "admin");
      const personId = id(req.params.id),
        person = await one(db, "PERSONS", { PERSON_ID: personId });
      if (!person) throw bad("Person record was not found.", 404);
      const firstName = personName(req.body.firstName, "First name");
      const lastName = personName(req.body.lastName, "Last name");
      if (req.body.phone !== undefined && typeof req.body.phone !== "string")
        throw bad("Phone must be text containing 10 local digits, or blank.");
      const phone =
        typeof req.body.phone === "string" ? req.body.phone.trim() : "";
      if (!isValidSouthAfricanPhone(phone))
        throw bad(
          "Phone must be a 10-digit South African number beginning with 0, or left blank.",
        );
      const patch = {
        FIRST_NAME: firstName,
        LAST_NAME: lastName,
        PHONE_NUMBER: phone || null,
      };
      let idChanged = false;
      if (Object.hasOwn(req.body, "saIdNumber")) {
        const saIdNumber = normalizeSouthAfricanIdNumber(req.body.saIdNumber);
        if (!isValidSouthAfricanIdNumber(req.body.saIdNumber))
          throw bad(
            "Enter a valid 13-digit South African ID number with a valid, non-future date, or leave it blank.",
          );
        if (saIdNumber) {
          const learnerRole = await db.list("LEARNERS", {
            PERSON_ID: personId,
          });
          if (!learnerRole.length)
            throw bad(
              "South African ID numbers may only be recorded for a learner.",
            );
          await assertSaIdAvailable(db, saIdNumber, personId);
          patch.SA_ID_NUMBER = saIdNumber;
          idChanged =
            saIdNumber !== normalizeSouthAfricanIdNumber(person.SA_ID_NUMBER);
        }
      }
      await db.update("PERSONS", { PERSON_ID: personId }, patch);
      await audit(db, u.personId, "admin.person.update", {
        personId,
        firstNameChanged: firstName !== person.FIRST_NAME,
        lastNameChanged: lastName !== person.LAST_NAME,
        phoneChanged: phone !== String(person.PHONE_NUMBER || ""),
        saIdNumberChanged: idChanged,
      });
      return {
        message: "Person details updated and timestamped in audit history.",
      };
    }),
  );
  router.get(
    "/admin/accounts",
    wrap(async (db, u) => {
      role(u, "admin");
      const out = [],
        people = await db.list("PERSONS"),
        auditRows = await db.list("security.Audit");
      const detailFor = (event) => {
        try {
          return JSON.parse(event.DETAIL || "{}");
        } catch {
          return {};
        }
      };
      const auditForPerson = (personId) =>
        auditRows
          .filter((event) =>
            detailFor(event).personId != null
              ? sameId(detailFor(event).personId, personId)
              : sameId(event.PERSON_ID, personId),
          )
          .sort((a, b) =>
            String(a.CREATED_AT || "").localeCompare(
              String(b.CREATED_AT || ""),
            ),
          );
      for (const a of await db.list("security.Accounts")) {
        const verification = (
            await db.list("security.EmailVerifications", {
              PERSON_ID: a.PERSON_ID,
            })
          )[0],
          person = people.find((row) => sameId(row.PERSON_ID, a.PERSON_ID)),
          context = await userContext(db, a.PERSON_ID),
          warnings = personIdentityWarnings(
            person,
            a.USERNAME,
            Boolean(context),
          ),
          identityConflicts = person
            ? findPersonIdentityMatches(people, a.USERNAME, person.PERSON_ID)
            : [],
          personAudit = auditForPerson(a.PERSON_ID),
          createdEvents = personAudit.filter((event) =>
            [
              "register",
              "account.create",
              "account.link",
              "sample.seed",
              "demo.seed",
            ].includes(event.EVENT),
          ),
          updatedEvents = personAudit.filter((event) =>
            [
              "profile.update",
              "admin.person.update",
              "account.identity.sync",
            ].includes(event.EVENT),
          ),
          accessEvents = personAudit.filter((event) =>
            ["account.disable", "account.enable"].includes(event.EVENT),
          ),
          latestAccessEvent = accessEvents.at(-1),
          personId = person?.PERSON_ID ?? a.PERSON_ID;
        out.push({
          accountId: a.ACCOUNT_ID,
          personId,
          firstName: person?.FIRST_NAME ?? context?.firstName ?? "",
          lastName: person?.LAST_NAME ?? context?.lastName ?? "",
          phoneNumber: person?.PHONE_NUMBER ?? null,
          hasSaIdNumber: /^\d{13}$/.test(
            normalizeSouthAfricanIdNumber(person?.SA_ID_NUMBER),
          ),
          saIdNumberMasked: /^\d{13}$/.test(
            normalizeSouthAfricanIdNumber(person?.SA_ID_NUMBER),
          )
            ? maskSaIdNumber(person.SA_ID_NUMBER)
            : null,
          createdAt: createdEvents[0]?.CREATED_AT ?? null,
          updatedAt: updatedEvents.at(-1)?.CREATED_AT ?? null,
          removedAt:
            a.DISABLED && latestAccessEvent?.EVENT === "account.disable"
              ? latestAccessEvent.CREATED_AT
              : null,
          username: a.USERNAME,
          disabled: Boolean(a.DISABLED),
          emailVerified: Boolean(verification?.VERIFIED_AT),
          accountSetupPending: await activeInvitation(db, a.PERSON_ID),
          user: context,
          identityWarnings: warnings,
          identitySyncAvailable:
            Boolean(person) &&
            emailPattern.test(String(a.USERNAME || "")) &&
            !hasRepeatedEmailSuffix(a.USERNAME) &&
            identityConflicts.length === 0 &&
            (normalizeIdentity(person.EMAIL) !==
              normalizeIdentity(a.USERNAME) ||
              normalizeIdentity(person.USERNAME) !==
                normalizeIdentity(a.USERNAME)),
        });
      }
      return { accounts: out };
    }),
  );
  router.post(
    "/admin/accounts/:id/password-reset",
    wrap(async (db, u, req) => {
      role(u, "admin");
      if (!emailAvailable)
        throw bad(
          "Email delivery is not configured. Contact the application administrator.",
          503,
        );
      const account = await one(db, "security.Accounts", {
        ACCOUNT_ID: req.params.id,
      });
      if (sameId(account.PERSON_ID, u.personId))
        throw bad(
          "Use the self-service password recovery page for your own account.",
          400,
        );
      if (account.DISABLED)
        throw bad("Restore the account before requesting recovery.", 409);
      const verification = (
          await db.list("security.EmailVerifications", {
            PERSON_ID: account.PERSON_ID,
          })
        )[0],
        invitation = await activeInvitation(db, account.PERSON_ID),
        email = normalizeIdentity(account.USERNAME);
      if (!emailPattern.test(email) || hasRepeatedEmailSuffix(email))
        throw bad(
          "The login email appears malformed. Verify and correct the account address before sending recovery instructions.",
          409,
        );
      if (!verification || !verification.VERIFIED_AT) {
        const message = await (invitation
          ? accountInvitationMessage(db, account.PERSON_ID, email)
          : emailVerificationMessage(db, account.PERSON_ID, email));
        await audit(
          db,
          u.personId,
          invitation
            ? "account.invitation.resent"
            : "email.verification.resent",
          { personId: account.PERSON_ID },
        );
        return {
          ...queueEmail(message),
          message: invitation
            ? "Account setup link sent to the account email."
            : "Email verification link sent to the account email.",
        };
      }
      const raw = await issueToken(db, account.PERSON_ID, "password-reset", 20);
      await audit(db, u.personId, "password.reset.requested", {
        personId: account.PERSON_ID,
      });
      return {
        ...queueEmail(
          email,
          "Password reset requested by your Varsity Vault administrator",
          `An administrator requested account access instructions. This link expires in 20 minutes and can only be used once:\n\n${accountLink("/reset-password.html", raw)}\n\nIf you did not expect this, contact your institution administrator.`,
        ),
        message:
          "Password reset instructions sent to the verified account email.",
      };
    }),
  );
  router.post(
    "/admin/accounts/:id/sync-profile-email",
    wrap(async (db, u, req) => {
      role(u, "admin");
      const account = await one(db, "security.Accounts", {
        ACCOUNT_ID: req.params.id,
      });
      const person = await one(db, "PERSONS", { PERSON_ID: account.PERSON_ID });
      const username = normalizeIdentity(account.USERNAME);
      if (!emailPattern.test(username) || hasRepeatedEmailSuffix(username))
        throw bad(
          "The login email itself appears invalid. Correct the account login address before syncing the profile.",
        );
      const matches = findPersonIdentityMatches(
        await db.list("PERSONS"),
        username,
        person.PERSON_ID,
      );
      if (matches.length) throw bad(personMatchMessage(matches), 409);
      await db.update(
        "PERSONS",
        { PERSON_ID: person.PERSON_ID },
        { EMAIL: username, USERNAME: username },
      );
      await audit(db, u.personId, "account.identity.sync", {
        personId: person.PERSON_ID,
      });
      return {
        message: "Profile email and username now match this account login.",
      };
    }),
  );
  router.post(
    "/admin/accounts/:id/disable",
    wrap(async (db, u, req) => {
      role(u, "admin");
      const a = await one(db, "security.Accounts", {
        ACCOUNT_ID: req.params.id,
      });
      if (sameId(a.PERSON_ID, u.personId))
        throw bad("You cannot disable your own account.");
      await db.update(
        "security.Accounts",
        { ACCOUNT_ID: a.ACCOUNT_ID },
        { DISABLED: 1 },
      );
      for (const s of await db.list("security.Sessions", {
        PERSON_ID: a.PERSON_ID,
      }))
        await db.remove("security.Sessions", { TOKEN_HASH: s.TOKEN_HASH });
      await audit(db, u.personId, "account.disable", { personId: a.PERSON_ID });
      return { message: "Account disabled." };
    }),
  );
  router.post(
    "/admin/accounts/:id/enable",
    wrap(async (db, u, req) => {
      role(u, "admin");
      const a = await one(db, "security.Accounts", {
        ACCOUNT_ID: req.params.id,
      });
      if (!(await userContext(db, a.PERSON_ID)))
        throw bad(
          "Assign exactly one valid role before restoring this account.",
          409,
        );
      await db.update(
        "security.Accounts",
        { ACCOUNT_ID: a.ACCOUNT_ID },
        { DISABLED: 0 },
      );
      for (const session of await db.list("security.Sessions", {
        PERSON_ID: a.PERSON_ID,
      }))
        await db.remove("security.Sessions", {
          TOKEN_HASH: session.TOKEN_HASH,
        });
      await audit(db, u.personId, "account.enable", { personId: a.PERSON_ID });
      return { message: "Account restored. The user must sign in again." };
    }),
  );
  router.get(
    "/admin/audit",
    wrap(async (db, u) => {
      role(u, "admin");
      const people = new Map(
        (await db.list("PERSONS")).map((person) => [
          String(person.PERSON_ID),
          [person.FIRST_NAME, person.LAST_NAME].filter(Boolean).join(" "),
        ]),
      );
      const events = (await db.list("security.Audit"))
        .sort((a, b) => b.CREATED_AT.localeCompare(a.CREATED_AT))
        .slice(0, 200)
        .map(({ PERSON_ID, ...event }) => ({
          ...event,
          actor: people.get(String(PERSON_ID)) || "System",
        }));
      return { events };
    }),
  );
  const saveOffering = wrap(async (db, u, req) => {
    role(u, "admin", "representative");
    if (
      u.role === "representative" &&
      String(req.body.universityId) !== String(u.universityId)
    )
      throw bad(
        "You can manage offerings only for your assigned university.",
        403,
      );
    if (req.params.id && u.role === "representative") {
      const existing = await one(db, "UNI_QUALIFICATIONS", {
        UNI_QUAL_ID: id(req.params.id),
      });
      if (String(existing.UNIVERSITY_ID) !== String(u.universityId))
        throw bad("This offering belongs to another university.", 403);
    }
    if (
      req.body.notes != null &&
      (typeof req.body.notes !== "string" || req.body.notes.length > 400)
    )
      throw bad("Programme notes must be text up to 400 characters.");
    const b = req.body,
      university = await one(db, "UNIVERSITIES", {
        UNIVERSITY_ID: id(b.universityId),
      });
    if (
      !/^\d{4}-\d{2}-\d{2}$/.test(b.closingDate) ||
      Number.isNaN(Date.parse(b.closingDate)) ||
      new Date(b.closingDate).toISOString().slice(0, 10) !== b.closingDate ||
      b.intake !== 2028
    )
      throw bad("Use a valid closing date and the 2028 intake.");
    if (
      !Number.isInteger(b.minScore) ||
      b.minScore < 0 ||
      b.minScore > (b.scoring ? 32767 : 42) ||
      (!b.scoring && !Number.isInteger(b.minScore))
    )
      throw bad(
        "Use a whole-number minimum: 0–42 for standard APS, or 0–32767 for a custom score.",
      );
    httpsUrl(b.source, "Programme source");
    for (const key of ["verified", "active"])
      if (b[key] !== undefined && typeof b[key] !== "boolean")
        throw bad(key + " must be true or false.");
    if (
      b.finalMinScore != null &&
      (!Number.isFinite(b.finalMinScore) ||
        b.finalMinScore < 0 ||
        b.finalMinScore > (b.scoring ? 32767 : 42) ||
        (!b.scoring && !Number.isInteger(b.finalMinScore)))
    )
      throw bad("Final APS must be a whole number between 0 and 42.");
    for (const k of ["minEnglish", "minMath"])
      if (
        b[k] != null &&
        (typeof b[k] !== "number" ||
          !Number.isFinite(b[k]) ||
          b[k] < 0 ||
          b[k] > 100)
      )
        throw bad("Subject minimums must be 0–100.");
    const known = new Set(
      (await db.list("SUBJECTS")).map((s) => s.SUBJECT_CODE),
    );
    if (
      b.requiredCodes !== undefined &&
      (!Array.isArray(b.requiredCodes) ||
        b.requiredCodes.length > 6 ||
        new Set(b.requiredCodes).size !== b.requiredCodes.length ||
        b.requiredCodes.some((c) => !known.has(c)))
    )
      throw bad("Use at most six known required subject codes.");
    if (
      b.subjectMinimums !== undefined &&
      (!b.subjectMinimums ||
        typeof b.subjectMinimums !== "object" ||
        Array.isArray(b.subjectMinimums) ||
        Object.entries(b.subjectMinimums).some(
          ([c, v]) =>
            !known.has(c) ||
            typeof v !== "number" ||
            !Number.isFinite(v) ||
            v < 0 ||
            v > 100,
        ))
    )
      throw bad(
        "Use known subject codes with numeric percentage minimums from 0–100.",
      );
    let reusablePolicy = null;
    if (b.reusablePolicyId) {
      reusablePolicy = (
        await records(db, "admissions.policy", text(b.reusablePolicyId))
      ).at(-1);
      if (
        !reusablePolicy ||
        !sameId(reusablePolicy.universityId, university.UNIVERSITY_ID)
      )
        throw bad("Choose a scoring policy for this university.");
      if (reusablePolicy.version !== b.reusablePolicyVersion)
        throw bad("Policy changed. Reload its latest version.", 409);
      b.scoring = reusablePolicy.scoring;
    }
    const previousPolicy = req.params.id
      ? (
          await db.list("security.Policies", { UNI_QUAL_ID: id(req.params.id) })
        )[0]
      : null;
    const previousConfig = previousPolicy
      ? JSON.parse(previousPolicy.PAYLOAD)
      : {};
    let scoring, subjectGroups;
    try {
      scoring = previousConfig.requirementsImport
        ? previousConfig.scoring
        : validateScoring(b.scoring, known);
      subjectGroups = validateGroups(b.subjectGroups, known);
    } catch (error) {
      throw bad(error.message);
    }
    const requiredDocumentIds = b.requiredDocumentIds ?? [];
    const types = await db.list("DOCUMENT_TYPES");
    if (
      !Array.isArray(requiredDocumentIds) ||
      requiredDocumentIds.some(
        (value) =>
          !types.some(
            (t) =>
              Number(t.DOCUMENT_TYPE_ID) === value && !t.IS_LOCKED_UNTIL_FINAL,
          ),
      )
    )
      throw bad(
        "Choose existing submission document types; final certificates cannot be required before a provisional offer.",
      );
    if (
      b.openingDate &&
      (!/^\d{4}-\d{2}-\d{2}$/.test(b.openingDate) ||
        Number.isNaN(Date.parse(b.openingDate)) ||
        new Date(b.openingDate).toISOString().slice(0, 10) !== b.openingDate ||
        b.openingDate > b.closingDate)
    )
      throw bad(
        "Opening date must be valid and on or before the closing date.",
      );
    if (b.closingTime && !/^([01]\d|2[0-3]):[0-5]\d$/.test(b.closingTime))
      throw bad("Closing time must use HH:MM.");
    let o;
    if (req.params.id) {
      o = await one(db, "UNI_QUALIFICATIONS", {
        UNI_QUAL_ID: id(req.params.id),
      });
      if (!sameId(o.UNIVERSITY_ID, university.UNIVERSITY_ID))
        throw bad(
          "An offering cannot be transferred to a different university.",
        );
      await db.update(
        "UNI_QUALIFICATIONS",
        { UNI_QUAL_ID: o.UNI_QUAL_ID },
        { APPLICATION_CLOSING_DATE: b.closingDate },
      );
    } else {
      const program = await db.insert("PROGRAMS", {
          PROGRAM_NAME: text(b.program || "Undergraduate"),
        }),
        qualification = await db.insert("QUALIFICATIONS", {
          QUAL_NAME: text(b.name, 150),
          PROGRAM_ID: program.PROGRAM_ID,
        });
      o = await db.insert("UNI_QUALIFICATIONS", {
        UNIVERSITY_ID: university.UNIVERSITY_ID,
        QUAL_ID: qualification.QUAL_ID,
        APPLICATION_CLOSING_DATE: b.closingDate,
      });
    }
    const config = {
      ...previousConfig,
      intake: 2028,
      status: b.verified === true ? "verified" : "pending",
      source: b.source,
      minScore: b.minScore,
      finalMinScore: b.finalMinScore ?? null,
      minEnglish: b.minEnglish ?? null,
      minMath: b.minMath ?? null,
      requiredCodes: Array.isArray(b.requiredCodes) ? b.requiredCodes : [],
      subjectMinimums: b.subjectMinimums || {},
      scoring,
      subjectGroups,
      requiredDocumentIds: [...new Set(requiredDocumentIds)],
      openingDate: b.openingDate || null,
      closingTime: b.closingTime || "23:59",
      active: b.active !== false,
      reusablePolicyId: reusablePolicy?.key || null,
      reusablePolicyVersion: reusablePolicy?.version || null,
      scoringMethod: scoring ? "configured" : "standard-aps-6",
      notes: text(
        b.notes || "Check the university source for full selection conditions.",
        400,
      ),
    };
    if (
      (await db.list("security.Policies", { UNI_QUAL_ID: o.UNI_QUAL_ID }))
        .length
    )
      await db.update(
        "security.Policies",
        { UNI_QUAL_ID: o.UNI_QUAL_ID },
        { PAYLOAD: JSON.stringify(config) },
      );
    else
      await db.insert("security.Policies", {
        UNI_QUAL_ID: o.UNI_QUAL_ID,
        PAYLOAD: JSON.stringify(config),
      });
    const data = {
      MIN_APS_SCORE: config.minScore,
      MIN_ENG_SCORE: config.minEnglish,
      MIN_MATH_SCORE: config.minMath,
      NOTES: config.notes,
    };
    if (
      (
        await db.list("QUALIFICATION_REQUIREMENTS", {
          UNI_QUAL_ID: o.UNI_QUAL_ID,
        })
      ).length
    )
      await db.update(
        "QUALIFICATION_REQUIREMENTS",
        { UNI_QUAL_ID: o.UNI_QUAL_ID },
        data,
      );
    else
      await db.insert("QUALIFICATION_REQUIREMENTS", {
        UNI_QUAL_ID: o.UNI_QUAL_ID,
        ...data,
      });
    await audit(
      db,
      u.personId,
      req.params.id ? "offering.update" : "offering.create",
      {
        offeringId: o.UNI_QUAL_ID,
        config,
      },
    );
    return { message: "Offering saved.", offeringId: o.UNI_QUAL_ID };
  });
  router.post("/admin/offerings", saveOffering);
  router.patch("/admin/offerings/:id", saveOffering);
  router.post("/representative/offerings", saveOffering);
  router.patch("/representative/offerings/:id", saveOffering);
  const directoryTables = {
    schools: "SCHOOLS",
    universities: "UNIVERSITIES",
    cities: "CITIES",
    provinces: "PROVINCES",
    subjects: "SUBJECTS",
    exams: "EXAM_TYPES",
    studyModes: "STUDY_MODES",
  };
  router.get(
    "/admin/directories/:type",
    wrap(async (db, u, req) => {
      role(u, "admin");
      const t = directoryTables[req.params.type];
      if (!t) throw bad("Unknown directory.");
      const rows = await db.list(t);
      if (t === "UNIVERSITIES") {
        const addresses = await db.list("UNIVERSITY_ADDRESSES");
        return {
          rows: rows.map((row) => {
            const address = addresses.find((a) =>
              sameId(a.UNIVERSITY_ID, row.UNIVERSITY_ID),
            );
            return {
              ...row,
              CITY_ID: address?.CITY_ID ?? null,
              STREET_NAME: address?.STREET_NAME ?? null,
            };
          }),
        };
      }
      return { rows };
    }),
  );
  const saveDirectory = wrap(async (db, u, req) => {
    role(u, "admin");
    const t = directoryTables[req.params.type];
    if (!t) throw bad("Unknown directory.");
    const allowed = {
      schools: ["SCHOOL_NAME", "EMIS_NUMBER", "CITY_ID", "PROVINCE_ID"],
      universities: [
        "UNIVERSITY_NAME",
        "WEBSITE",
        "PROVINCE_ID",
        "CITY_ID",
        "STREET_NAME",
      ],
      cities: ["CITY_NAME", "PROVINCE_ID"],
      provinces: ["PROVINCE_NAME"],
      subjects: [
        "SUBJECT_NAME",
        "SUBJECT_CODE",
        "SCHOOL_ID",
        "SUBJECT_CATEGORY",
      ],
      exams: ["EXAM_TYPE_NAME"],
      studyModes: ["STUDY_MODE_NAME"],
    }[req.params.type];
    const data = {};
    for (const k of allowed) {
      const v = req.body[k];
      if (v !== undefined)
        data[k] = k.endsWith("_ID")
          ? v === null
            ? null
            : id(v)
          : text(v, directoryLimits[k] || 150);
    }
    if (!Object.keys(data).length) throw bad("Enter directory fields.");
    validateDirectoryFields(data);
    const primaryKey = {
      SCHOOLS: "SCHOOL_ID",
      UNIVERSITIES: "UNIVERSITY_ID",
      CITIES: "CITY_ID",
      PROVINCES: "PROVINCE_ID",
      SUBJECTS: "SUBJECT_ID",
      EXAM_TYPES: "EXAM_TYPE_ID",
      STUDY_MODES: "STUDY_MODE_ID",
    }[t];
    const uniqueKey = {
      SCHOOLS: "EMIS_NUMBER",
      UNIVERSITIES: "UNIVERSITY_NAME",
      CITIES: "CITY_NAME",
      PROVINCES: "PROVINCE_NAME",
      SUBJECTS: "SUBJECT_CODE",
      EXAM_TYPES: "EXAM_TYPE_NAME",
      STUDY_MODES: "STUDY_MODE_NAME",
    }[t];
    if (
      data[uniqueKey] &&
      (await db.list(t)).some(
        (row) =>
          (!req.params.id || !sameId(row[primaryKey], req.params.id)) &&
          String(row[uniqueKey] || "")
            .trim()
            .toLowerCase() === data[uniqueKey].trim().toLowerCase() &&
          (t !== "CITIES" || sameId(row.PROVINCE_ID, data.PROVINCE_ID)) &&
          (t !== "SUBJECTS" ||
            sameId(row.SCHOOL_ID, data.SCHOOL_ID) ||
            (row.SCHOOL_ID == null && data.SCHOOL_ID == null)),
      )
    )
      throw bad(
        "A record with this " +
          uniqueKey.replaceAll("_", " ").toLowerCase() +
          " already exists.",
        409,
      );
    for (const [column, target] of [
      ["CITY_ID", "CITIES"],
      ["PROVINCE_ID", "PROVINCES"],
      ["SCHOOL_ID", "SCHOOLS"],
    ])
      if (data[column] != null)
        await one(db, target, { [column]: data[column] });
    if (
      t === "SUBJECTS" &&
      ![
        "HOME_LANGUAGE",
        "FIRST_ADDITIONAL_LANGUAGE",
        "MATHEMATICS",
        "MATHEMATICAL_LITERACY",
        "LIFE_ORIENTATION",
        "ELECTIVE",
      ].includes(data.SUBJECT_CATEGORY)
    )
      throw bad("Choose a valid NSC category.");
    for (const column of allowed.filter((c) => !c.endsWith("_ID")))
      if (data[column] === undefined) throw bad("Enter " + column + ".");
    if (t === "CITIES" && !data.PROVINCE_ID)
      throw bad("Assign the city to a province.");
    if (t === "SCHOOLS" && data.CITY_ID && data.PROVINCE_ID) {
      const city = await one(db, "CITIES", { CITY_ID: data.CITY_ID });
      if (!sameId(city.PROVINCE_ID, data.PROVINCE_ID))
        throw bad(
          "The selected city belongs to a different province. Choose its recorded province.",
        );
    }
    if (t === "SCHOOLS" && (!data.CITY_ID || !data.PROVINCE_ID))
      throw bad("Assign the school to a city and province.");
    if (
      t === "UNIVERSITIES" &&
      (!data.CITY_ID || !data.PROVINCE_ID || !data.STREET_NAME)
    )
      throw bad("Add the university’s campus location, city and province.");
    let row;
    if (req.params.id) {
      const primary = {
          SCHOOLS: "SCHOOL_ID",
          UNIVERSITIES: "UNIVERSITY_ID",
          CITIES: "CITY_ID",
          PROVINCES: "PROVINCE_ID",
          SUBJECTS: "SUBJECT_ID",
          EXAM_TYPES: "EXAM_TYPE_ID",
          STUDY_MODES: "STUDY_MODE_ID",
        }[t],
        where = { [primary]: id(req.params.id) };
      await one(db, t, where);
      const values = { ...data };
      if (t === "UNIVERSITIES") {
        delete values.CITY_ID;
        delete values.STREET_NAME;
      }
      await db.update(t, where, values);
      row = { ...where, ...values };
    } else {
      const values = { ...data };
      if (t === "UNIVERSITIES") {
        delete values.CITY_ID;
        delete values.STREET_NAME;
      }
      row = await db.insert(t, values);
    }
    if (t === "UNIVERSITIES") {
      let addressType =
        (await db.list("ADDRESS_TYPES")).find((a) =>
          /campus|main/i.test(a.ADDRESS_TYPE_NAME),
        ) || (await db.list("ADDRESS_TYPES"))[0];
      if (!addressType)
        addressType = await db.insert("ADDRESS_TYPES", {
          ADDRESS_TYPE_NAME: "Campus",
        });
      const uniId = row.UNIVERSITY_ID,
        existing = (
          await db.list("UNIVERSITY_ADDRESSES", { UNIVERSITY_ID: uniId })
        )[0],
        address = {
          UNIVERSITY_ID: uniId,
          ADDRESS_TYPE_ID: addressType.ADDRESS_TYPE_ID,
          STREET_NAME: data.STREET_NAME,
          CITY_ID: data.CITY_ID,
        };
      if (existing)
        await db.update(
          "UNIVERSITY_ADDRESSES",
          { ADDRESS_ID: existing.ADDRESS_ID },
          address,
        );
      else await db.insert("UNIVERSITY_ADDRESSES", address);
      row = { ...row, CITY_ID: data.CITY_ID, STREET_NAME: data.STREET_NAME };
    }
    await audit(
      db,
      u.personId,
      req.params.id ? "directory.update" : "directory.create",
      {
        table: t,
      },
    );
    return { row };
  });
  router.post("/admin/directories/:type", saveDirectory);
  router.patch("/admin/directories/:type/:id", saveDirectory);
  router.get(
    "/prospectuses",
    wrap(async (db, u) => ({
      prospectuses: (await db.list("PROSPECTUSES")).map(
        ({ PROSPECTUS_FILE, ...p }) => p,
      ),
    })),
  );
  router.post(
    "/prospectuses",
    express.raw({ type: "application/pdf", limit: "6mb" }),
    wrap(async (db, u, req) => {
      role(u, "representative");
      if (
        !Buffer.isBuffer(req.body) ||
        req.body.subarray(0, 5).toString() !== "%PDF-"
      )
        throw bad("Upload a PDF prospectus.");
      await db.insert("PROSPECTUSES", {
        UNIVERSITY_ID: u.universityId,
        PROSPECTUS_FILE: req.body,
        PROSPECTUS_FILENAME: safeFilename(
          req.get("x-file-name") || "prospectus.pdf",
        ),
        PROSPECTUS_MIMETYPE: "application/pdf",
        PROSPECTUS_DATE: date(),
      });
      await audit(db, u.personId, "prospectus.upload", {});
      return { message: "Prospectus uploaded." };
    }),
  );
  router.get(
    "/prospectuses/:id/download",
    wrap(async (db, u, req, res) => {
      const p = await one(db, "PROSPECTUSES", {
        PROSPECTUS_ID: id(req.params.id),
      });
      if (!p.PROSPECTUS_FILE?.length)
        throw bad(
          "No prospectus file has been uploaded for this record yet.",
          404,
        );
      res
        .type("application/pdf")
        .set(
          "Content-Disposition",
          'attachment; filename="' +
            safeFilename(p.PROSPECTUS_FILENAME || "prospectus.pdf") +
            '"',
        )
        .send(Buffer.from(p.PROSPECTUS_FILE));
    }),
  );
  installCrud(router, { wrap, role, id });
  installRecordEntry(router, { wrap, role, id });
  router.use((req, res) =>
    res.status(404).json({ error: "API route not found." }),
  );
  return router;
}
