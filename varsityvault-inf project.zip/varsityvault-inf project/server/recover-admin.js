import { randomBytes } from "node:crypto";
import { pathToFileURL } from "node:url";
import { LocalStore, SqlStore } from "./storage.js";
import { passwordHash, audit, userContext } from "./security.js";

export async function recoverAdministrator(db, username, operator) {
  const normalized = String(username || "")
    .trim()
    .toLowerCase();
  const operatorLabel = String(operator || "")
    .trim()
    .slice(0, 100);
  if (!normalized || !operatorLabel)
    throw new Error("Administrator email and operator identity are required.");
  const account = (
    await db.list("security.Accounts", { USERNAME: normalized })
  )[0];
  if (!account) throw new Error("The account is not an administrator.");
  const context = await userContext(db, account.PERSON_ID);
  if (!context || context.role !== "admin")
    throw new Error("The account is not an administrator.");
  if (account.DISABLED)
    throw new Error(
      "The administrator account is disabled. Restore it through an authorized account administrator before recovery.",
    );
  const temporaryPassword = randomBytes(24).toString("base64url");
  await db.update(
    "security.Accounts",
    { PERSON_ID: account.PERSON_ID },
    { PASSWORD_HASH: await passwordHash(temporaryPassword) },
  );
  for (const row of await db.list("security.Mfa", {
    PERSON_ID: account.PERSON_ID,
  }))
    await db.remove("security.Mfa", { PERSON_ID: row.PERSON_ID });
  for (const row of await db.list("security.MfaChallenges", {
    PERSON_ID: account.PERSON_ID,
  }))
    await db.remove("security.MfaChallenges", { TOKEN_HASH: row.TOKEN_HASH });
  for (const row of await db.list("security.Sessions", {
    PERSON_ID: account.PERSON_ID,
  }))
    await db.remove("security.Sessions", { TOKEN_HASH: row.TOKEN_HASH });
  for (const row of await db.list("security.AccountTokens", {
    PERSON_ID: account.PERSON_ID,
  }))
    await db.remove("security.AccountTokens", { TOKEN_HASH: row.TOKEN_HASH });
  await audit(db, account.PERSON_ID, "account.operator_recovery", {
    operator: operatorLabel,
    mfaReset: true,
    sessionsRevoked: true,
  });
  return { username: normalized, temporaryPassword };
}

async function main() {
  const username = process.argv[2];
  if (!username)
    throw new Error(
      "Usage: npm run admin:recover -- administrator@example.com",
    );
  const mode = process.env.APP_MODE || "sqlserver";
  const db =
    mode === "sqlserver"
      ? await SqlStore.open()
      : new LocalStore(
          process.env.LOCAL_DATABASE || ".data/varsity-vault.sqlite",
        );
  try {
    const { createInterface } = await import("node:readline/promises");
    const terminal = createInterface({
      input: process.stdin,
      output: process.stdout,
    });
    try {
      const operator = await terminal.question("Your name or staff email: ");
      const confirmation = await terminal.question(
        `Type RESET ${username.trim().toLowerCase()} to confirm: `,
      );
      if (confirmation !== `RESET ${username.trim().toLowerCase()}`)
        throw new Error(
          "Recovery was not confirmed. No account changes were made.",
        );
      const result = await db.tx((store) =>
        recoverAdministrator(store, username, operator),
      );
      console.log(
        `Recovery complete for ${result.username}. MFA was reset; setup is optional.`,
      );
      console.log(
        `Temporary password (shown once): ${result.temporaryPassword}`,
      );
      console.log(
        "Share it with the administrator through a verified private channel, then ask them to change it after signing in.",
      );
    } finally {
      terminal.close();
    }
  } finally {
    await db.close();
  }
}

if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(process.argv[1]).href
) {
  main().catch((error) => {
    console.error(error.message);
    process.exitCode = 1;
  });
}
