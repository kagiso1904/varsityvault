import { DatabaseSync } from "node:sqlite";
import { mkdirSync, readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { loadSqlDriver } from "./db/driver.js";
import { databaseConfig } from "./db/config.js";
export const metadata = JSON.parse(
  readFileSync(new URL("../config/table-map.json", import.meta.url)),
);
const extras = {
  Accounts: {
    primary: ["ACCOUNT_ID"],
    columns: {
      ACCOUNT_ID: { type: "VARCHAR", size: "50" },
      PERSON_ID: { type: "INT" },
      USERNAME: { type: "VARCHAR", size: "255" },
      PASSWORD_HASH: { type: "VARCHAR", size: "255" },
      DISABLED: { type: "BIT" },
    },
  },
  Sessions: {
    primary: ["TOKEN_HASH"],
    columns: {
      TOKEN_HASH: { type: "VARCHAR", size: "64" },
      PERSON_ID: { type: "INT" },
      CSRF: { type: "VARCHAR", size: "64" },
      EXPIRES: { type: "VARCHAR", size: "30" },
    },
  },
  Audit: {
    primary: ["AUDIT_ID"],
    columns: {
      AUDIT_ID: { type: "VARCHAR", size: "50" },
      PERSON_ID: { type: "INT" },
      EVENT: { type: "VARCHAR", size: "100" },
      DETAIL: { type: "VARCHAR", size: "MAX" },
      CREATED_AT: { type: "VARCHAR", size: "30" },
    },
  },
  Policies: {
    primary: ["UNI_QUAL_ID"],
    columns: {
      UNI_QUAL_ID: { type: "INT" },
      PAYLOAD: { type: "VARCHAR", size: "MAX" },
    },
  },
  LoginAttempts: {
    primary: ["ATTEMPT_KEY"],
    columns: {
      ATTEMPT_KEY: { type: "VARCHAR", size: "64" },
      FAILURES: { type: "INT" },
      WINDOW_START: { type: "VARCHAR", size: "30" },
      BLOCKED_UNTIL: { type: "VARCHAR", size: "30" },
    },
  },
  AccountTokens: {
    primary: ["TOKEN_HASH"],
    columns: {
      TOKEN_HASH: { type: "VARCHAR", size: "64" },
      PERSON_ID: { type: "INT" },
      PURPOSE: { type: "VARCHAR", size: "30" },
      EXPIRES: { type: "VARCHAR", size: "30" },
      CREATED_AT: { type: "VARCHAR", size: "30" },
    },
  },
  EmailVerifications: {
    primary: ["PERSON_ID"],
    columns: {
      PERSON_ID: { type: "INT" },
      VERIFIED_AT: { type: "VARCHAR", size: "30" },
    },
  },
  Mfa: {
    primary: ["PERSON_ID"],
    columns: {
      PERSON_ID: { type: "INT" },
      SECRET_CIPHERTEXT: { type: "VARCHAR", size: "500" },
      RECOVERY_HASHES: { type: "VARCHAR", size: "MAX" },
      ENABLED: { type: "BIT" },
      LAST_STEP: { type: "INT" },
      SETUP_FAILURES: { type: "INT" },
    },
  },
  MfaChallenges: {
    primary: ["TOKEN_HASH"],
    columns: {
      TOKEN_HASH: { type: "VARCHAR", size: "64" },
      PERSON_ID: { type: "INT" },
      EXPIRES: { type: "VARCHAR", size: "30" },
      FAILURES: { type: "INT" },
    },
  },
};
for (const [key, value] of Object.entries(extras))
  metadata["security." + key] = value;
const info = (table) => {
  if (!metadata[table]) throw new Error("Unknown repository table.");
  return metadata[table];
};
const values = (table, data) => {
  for (const key of Object.keys(data))
    if (!info(table).columns[key])
      throw new Error("Unknown repository column.");
};
const cloneRow = (row) =>
  Object.fromEntries(
    Object.entries(row).map(([k, v]) => [
      k,
      v instanceof Uint8Array ? Buffer.from(v) : v,
    ]),
  );
const dashboardJoins = (db) =>
  `FROM ${db.name("APPLICATIONS")} A JOIN ${db.name("LEARNERS")} L ON L.PERSON_ID=A.LEARNER_ID JOIN ${db.name("PERSONS")} P ON P.PERSON_ID=L.PERSON_ID JOIN ${db.name("UNI_QUALIFICATIONS")} O ON O.UNI_QUAL_ID=A.UNI_QUAL_ID JOIN ${db.name("UNIVERSITIES")} U ON U.UNIVERSITY_ID=O.UNIVERSITY_ID JOIN ${db.name("QUALIFICATIONS")} Q ON Q.QUAL_ID=O.QUAL_ID JOIN ${db.name("APPLICATION_STATUSES")} S ON S.STATUS_ID=A.STATUS_ID LEFT JOIN ${db.name("security.Policies")} C ON C.UNI_QUAL_ID=O.UNI_QUAL_ID LEFT JOIN ${db.name("QUALIFICATION_REQUIREMENTS")} R ON R.UNI_QUAL_ID=O.UNI_QUAL_ID`;
const dashboardProjection = `A.*,S.STATUS_NAME AS APPLICATION_STATUS,P.FIRST_NAME AS LEARNER_FIRST_NAME,P.LAST_NAME AS LEARNER_LAST_NAME,Q.QUAL_NAME AS OFFERING_QUALIFICATION,U.UNIVERSITY_NAME AS OFFERING_UNIVERSITY,U.UNIVERSITY_ID AS OFFERING_UNIVERSITY_ID,O.APPLICATION_CLOSING_DATE AS OFFERING_CLOSING_DATE,C.PAYLOAD AS POLICY_PAYLOAD,R.MIN_APS_SCORE AS LEGACY_MIN_APS_SCORE,R.MIN_MATH_SCORE AS LEGACY_MIN_MATH_SCORE,R.MIN_ENG_SCORE AS LEGACY_MIN_ENG_SCORE,R.NOTES AS LEGACY_NOTES`;
function dashboardConditions(user, status) {
  const conditions = [],
    params = [],
    types = [];
  if (user.role === "learner") {
    conditions.push("L.PERSON_ID=?");
    params.push(user.recordId);
    types.push("int");
  } else if (user.role === "teacher") {
    conditions.push("L.SCHOOL_ID=?");
    params.push(user.schoolId);
    types.push("int");
  } else if (user.role === "representative") {
    conditions.push("O.UNIVERSITY_ID=?");
    params.push(user.universityId);
    types.push("int");
  } else if (user.role !== "admin") throw new Error("Unknown dashboard role.");
  if (status) {
    conditions.push("S.STATUS_NAME=?");
    params.push(status);
    types.push("text");
  }
  return { conditions, params, types };
}
const safeLimit = (value) =>
  Math.max(1, Math.min(20, Math.trunc(Number(value) || 8)));
export class LocalStore {
  constructor(path) {
    this.mode = "local";
    if (path !== ":memory:")
      mkdirSync(dirname(resolve(path)), { recursive: true });
    this.db = new DatabaseSync(path);
    this.db.exec("PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;");
    this.queue = Promise.resolve();
    for (const [table, m] of Object.entries(metadata)) {
      const name = table.replace("security.", "VV_");
      const sharedRole = [
        "LEARNERS",
        "TEACHERS",
        "ITADMINS",
        "UNIVERSITY_REPS",
      ].includes(table);
      const cols = Object.entries(m.columns).map(
        ([k, c]) =>
          `"${k}" ${m.identity === k && !sharedRole ? "INTEGER PRIMARY KEY AUTOINCREMENT" : c.type === "VARBINARY" ? "BLOB" : ["INT", "BIT", "TINYINT", "SMALLINT"].includes(c.type) ? "INTEGER" : c.type === "DECIMAL" ? "REAL" : "TEXT"}`,
      );
      if ((!m.identity || sharedRole) && m.primary?.length)
        cols.push(
          "PRIMARY KEY (" + m.primary.map((k) => '"' + k + '"').join(",") + ")",
        );
      this.db.exec(`CREATE TABLE IF NOT EXISTS "${name}" (${cols.join(",")})`);
    }
    for (const table of ["LEARNERS", "TEACHERS", "ITADMINS", "UNIVERSITY_REPS"])
      this.db.exec(
        `CREATE UNIQUE INDEX IF NOT EXISTS shared_${table} ON ${table}(PERSON_ID)`,
      );
    this.db.exec(
      "CREATE UNIQUE INDEX IF NOT EXISTS vv_accounts_username ON VV_Accounts(USERNAME); CREATE UNIQUE INDEX IF NOT EXISTS vv_accounts_person ON VV_Accounts(PERSON_ID); CREATE UNIQUE INDEX IF NOT EXISTS vv_apps_unique ON APPLICATIONS(LEARNER_ID,UNI_QUAL_ID,ACADEMIC_YEAR); CREATE UNIQUE INDEX IF NOT EXISTS vv_enrol_unique ON LEARNER_SUBJECTS(LEARNER_ID,SUBJECT_ID);",
    );
  }
  name(t) {
    info(t);
    return '"' + t.replace("security.", "VV_") + '"';
  }
  async list(t, where = {}) {
    values(t, where);
    const keys = Object.keys(where);
    const rows = this.db
      .prepare(
        `SELECT * FROM ${this.name(t)}${keys.length ? " WHERE " + keys.map((k) => '"' + k + '" IS ?').join(" AND ") : ""}`,
      )
      .all(...keys.map((k) => where[k]));
    return rows.map(cloneRow);
  }
  async count(t, where = {}) {
    values(t, where);
    const keys = Object.keys(where);
    return Number(
      this.db
        .prepare(
          `SELECT COUNT(*) AS n FROM ${this.name(t)}${keys.length ? " WHERE " + keys.map((k) => '"' + k + '" IS ?').join(" AND ") : ""}`,
        )
        .get(...keys.map((k) => where[k])).n,
    );
  }
  async resultMilestones(learnerId) {
    return this.db
      .prepare(
        "SELECT DISTINCT EXAM_TYPE_ID FROM LEARNER_RESULTS WHERE LEARNER_ID IS ?",
      )
      .all(learnerId)
      .map((row) => String(row.EXAM_TYPE_ID));
  }
  async dashboardApplications(
    user,
    { status, limit = 8, order = "DESC" } = {},
  ) {
    const { conditions, params } = dashboardConditions(user, status),
      direction = order === "ASC" ? "ASC" : "DESC",
      where = conditions.length ? " WHERE " + conditions.join(" AND ") : "";
    return this.db
      .prepare(
        `SELECT ${dashboardProjection},COUNT(*) OVER() AS TOTAL_COUNT ${dashboardJoins(this)}${where} ORDER BY A.APPLICATION_DATE ${direction},A.APPLICATION_ID ${direction} LIMIT ?`,
      )
      .all(...params, safeLimit(limit))
      .map(cloneRow);
  }
  async allApplications(user) {
    const { conditions, params } = dashboardConditions(user),
      where = conditions.length ? " WHERE " + conditions.join(" AND ") : "";
    return this.db
      .prepare(
        `SELECT ${dashboardProjection} ${dashboardJoins(this)}${where} ORDER BY A.APPLICATION_DATE DESC,A.APPLICATION_ID DESC`,
      )
      .all(...params)
      .map(cloneRow);
  }
  async dashboardApplicationCount(user, status) {
    const { conditions, params } = dashboardConditions(user, status),
      where = conditions.length ? " WHERE " + conditions.join(" AND ") : "";
    return Number(
      this.db
        .prepare(`SELECT COUNT(*) AS n ${dashboardJoins(this)}${where}`)
        .get(...params).n,
    );
  }
  async dashboardOfferings({
    unverified = false,
    closingFrom,
    closingTo,
    limit = 8,
  } = {}) {
    const c = this.name("security.Policies"),
      u = this.name("UNI_QUALIFICATIONS"),
      uni = this.name("UNIVERSITIES"),
      q = this.name("QUALIFICATIONS"),
      filter = unverified
        ? `(COALESCE(json_extract(C.PAYLOAD,'$.status'),'pending')<>'verified' OR COALESCE(json_extract(C.PAYLOAD,'$.intake'),0)<>2028)`
        : closingFrom && closingTo
          ? `json_extract(C.PAYLOAD,'$.status')='verified' AND json_extract(C.PAYLOAD,'$.intake')=2028 AND O.APPLICATION_CLOSING_DATE>=? AND O.APPLICATION_CLOSING_DATE<=?`
          : "0=1",
      params =
        closingFrom && closingTo && !unverified ? [closingFrom, closingTo] : [];
    return this.db
      .prepare(
        `SELECT O.UNI_QUAL_ID,O.UNIVERSITY_ID,O.APPLICATION_CLOSING_DATE,U.UNIVERSITY_NAME,Q.QUAL_NAME,C.PAYLOAD,COALESCE(json_extract(C.PAYLOAD,'$.status'),'pending') AS POLICY_STATUS,COUNT(*) OVER() AS TOTAL_COUNT FROM ${u} O JOIN ${uni} U ON U.UNIVERSITY_ID=O.UNIVERSITY_ID JOIN ${q} Q ON Q.QUAL_ID=O.QUAL_ID LEFT JOIN ${c} C ON C.UNI_QUAL_ID=O.UNI_QUAL_ID WHERE ${filter} ORDER BY CASE WHEN O.APPLICATION_CLOSING_DATE IS NULL THEN 1 ELSE 0 END,O.APPLICATION_CLOSING_DATE ASC,O.UNI_QUAL_ID ASC LIMIT ?`,
      )
      .all(...params, safeLimit(limit))
      .map(cloneRow);
  }
  async createPerson(data, { type, schoolId = null, universityId = null }) {
    const roles = {
      L: "LEARNERS",
      T: "TEACHERS",
      A: "ITADMINS",
      R: "UNIVERSITY_REPS",
    };
    if (!roles[type]) throw new Error("Choose a valid person type.");
    if (type === "R" ? !universityId : !schoolId)
      throw new Error("Assign the person to their school or university.");
    const person = await this.insert("PERSONS", { ...data, PERSON_TYPE: type });
    await this.insert(roles[type], {
      PERSON_ID: person.PERSON_ID,
      ...(type === "R"
        ? { UNIVERSITY_ID: universityId }
        : { SCHOOL_ID: schoolId }),
      ...(type === "T"
        ? {
            DEPARTMENT: "Career Guidance",
            DESIGNATION: "Career Guidance Teacher",
          }
        : {}),
    });
    return person;
  }
  async insert(t, data) {
    const sharedRole = [
      "LEARNERS",
      "TEACHERS",
      "ITADMINS",
      "UNIVERSITY_REPS",
    ].includes(t);
    values(t, data);
    const keys = Object.keys(data);
    const r = this.db
      .prepare(
        `INSERT INTO ${this.name(t)} (${keys.map((k) => '"' + k + '"')}) VALUES (${keys.map(() => "?")})`,
      )
      .run(...keys.map((k) => data[k] ?? null));
    return {
      ...data,
      ...(info(t).identity && !sharedRole
        ? { [info(t).identity]: Number(r.lastInsertRowid) }
        : {}),
    };
  }
  async update(t, where, data) {
    values(t, where);
    values(t, data);
    if (!Object.keys(where).length) throw new Error("Unscoped update.");
    const k = Object.keys(data),
      w = Object.keys(where);
    return this.db
      .prepare(
        `UPDATE ${this.name(t)} SET ${k.map((c) => '"' + c + '"=?')} WHERE ${w.map((c) => '"' + c + '" IS ?').join(" AND ")}`,
      )
      .run(...k.map((c) => data[c] ?? null), ...w.map((c) => where[c])).changes;
  }
  async remove(t, where) {
    values(t, where);
    const k = Object.keys(where);
    if (!k.length) throw new Error("Unscoped delete.");
    return this.db
      .prepare(
        `DELETE FROM ${this.name(t)} WHERE ${k.map((c) => '"' + c + '" IS ?').join(" AND ")}`,
      )
      .run(...k.map((c) => where[c])).changes;
  }
  tx(fn) {
    const operation = this.queue.then(async () => {
      this.db.exec("BEGIN IMMEDIATE");
      try {
        const result = await fn(this);
        this.db.exec("COMMIT");
        return result;
      } catch (error) {
        this.db.exec("ROLLBACK");
        throw error;
      }
    });
    this.queue = operation.catch(() => {});
    return operation;
  }
  close() {
    this.db.close();
  }
}
export class SqlStore {
  constructor(pool, transaction = null, driver) {
    this.sql = driver;
    this.pool = pool;
    this.transaction = transaction;
    this.mode = "sqlserver";
  }
  static async open() {
    const config = databaseConfig(),
      sql = await loadSqlDriver();
    const pool = new sql.ConnectionPool(config);
    pool.on("error", () => console.error("SQL Server pool error."));
    await pool.connect();
    const store = new SqlStore(pool, null, sql);
    let checking = "database";
    try {
      for (const table of Object.keys(metadata)) {
        checking = table;
        const query = await pool
          .request()
          .query("SELECT TOP (0) * FROM " + store.name(table));
        const actual = new Set(Object.keys(query.recordset.columns));
        if (Object.keys(metadata[table].columns).some((c) => !actual.has(c)))
          throw new Error(
            "Required columns do not match. Run npm run db:check.",
          );
      }
      checking = "ERD alignment";
      await pool.request().query(`
        IF COL_LENGTH(N'dbo.LEARNERS',N'LEARNER_ID') IS NOT NULL
        OR COL_LENGTH(N'dbo.TEACHERS',N'TEACHER_ID') IS NOT NULL
        OR COL_LENGTH(N'dbo.ITADMINS',N'ITADMIN_IID') IS NOT NULL
        OR COL_LENGTH(N'dbo.UNIVERSITY_REPS',N'REP_ID') IS NOT NULL
          THROW 51020,'Run database/04_use_person_id_for_subtypes.sql before starting version 2.7.0.',1;
        IF OBJECT_ID(N'dbo.usp_CreatePersonWithRole',N'P') IS NULL
          THROW 51020,'Run database/02_align_existing_database.sql before starting version 2.7.0.',1;
        IF EXISTS(SELECT 1 FROM sys.tables t WHERE t.name IN ('LEARNERS','TEACHERS','ITADMINS','UNIVERSITY_REPS')
          AND NOT EXISTS(SELECT 1 FROM sys.key_constraints k JOIN sys.index_columns ic ON ic.object_id=k.parent_object_id AND ic.index_id=k.unique_index_id
          JOIN sys.columns c ON c.object_id=ic.object_id AND c.column_id=ic.column_id
          WHERE k.parent_object_id=t.object_id AND k.type='PK' AND c.name='PERSON_ID'))
          THROW 51020,'ERD subtype PERSON_ID primary keys are missing.',1;
        IF (SELECT COUNT(*) FROM sys.triggers WHERE name IN ('TRG_PERSONS_ROLE','TRG_LEARNERS_ROLE','TRG_TEACHERS_ROLE','TRG_ITADMINS_ROLE','TRG_UNIVERSITY_REPS_ROLE','TRG_SCHOOLS_GEOGRAPHY','TRG_CITIES_GEOGRAPHY') AND is_disabled=0)<>7
          THROW 51020,'ERD role or geography enforcement is missing or disabled.',1;
      `);
      return store;
    } catch (error) {
      await pool.close();
      const location = checking.startsWith("security.")
        ? store.name(checking)
        : "[dbo].[" + checking + "]";
      const guidance = checking.startsWith("security.")
        ? "Run database/security.sql in SSMS on this same instance to install or update the separate security database."
        : "Run npm run db:check and confirm the configured database and account permissions.";
      throw new Error(
        `Database contract check failed at ${location}. ${error.message} ${guidance} SQL Server code: ${error.code || "unknown"}.`,
        { cause: error },
      );
    }
  }
  name(t) {
    info(t);
    return t.startsWith("security.")
      ? "[VarsityVaultSecurity].[dbo].[" + t.slice(9) + "]"
      : "[dbo].[" + t + "]";
  }
  request() {
    return this.transaction
      ? new this.sql.Request(this.transaction)
      : this.pool.request();
  }
  bind(request, t, data, prefix) {
    const sql = this.sql;
    values(t, data);
    let n = 0;
    return Object.entries(data).map(([key, value]) => {
      const c = info(t).columns[key],
        type =
          c.type === "VARCHAR"
            ? sql.NVarChar(c.size === "MAX" ? sql.MAX : Number(c.size))
            : c.type === "VARBINARY"
              ? sql.VarBinary(sql.MAX)
              : c.type === "DECIMAL"
                ? sql.Decimal(5, 2)
                : c.type === "DATE"
                  ? sql.Date
                  : c.type === "BIT"
                    ? sql.Bit
                    : sql.Int;
      const param = prefix + n++;
      request.input(param, type, value ?? null);
      return { key, param };
    });
  }
  async list(t, where = {}) {
    const req = this.request(),
      params = this.bind(req, t, where, "w");
    const r = await req.query(
      `SELECT * FROM ${this.name(t)}${params.length ? " WHERE " + params.map((p) => `[${p.key}]${where[p.key] === null ? " IS NULL" : "=@" + p.param}`).join(" AND ") : ""}`,
    );
    return r.recordset;
  }
  async count(t, where = {}) {
    const req = this.request(),
      params = this.bind(req, t, where, "w");
    const r = await req.query(
      `SELECT COUNT(*) AS n FROM ${this.name(t)}${params.length ? " WHERE " + params.map((p) => `[${p.key}]${where[p.key] === null ? " IS NULL" : "=@" + p.param}`).join(" AND ") : ""}`,
    );
    return Number(r.recordset[0].n);
  }
  async resultMilestones(learnerId) {
    const req = this.request();
    req.input("learnerId", this.sql.Int, learnerId);
    const r = await req.query(
      `SELECT DISTINCT EXAM_TYPE_ID FROM ${this.name("LEARNER_RESULTS")} WHERE LEARNER_ID=@learnerId`,
    );
    return r.recordset.map((row) => String(row.EXAM_TYPE_ID));
  }
  async dashboardApplications(
    user,
    { status, limit = 8, order = "DESC" } = {},
  ) {
    const req = this.request(),
      { conditions, params, types } = dashboardConditions(user, status),
      where = conditions.length
        ? " WHERE " +
          conditions
            .map((_, i) => `${conditions[i].split("=")[0]}=@d${i}`)
            .join(" AND ")
        : "",
      direction = order === "ASC" ? "ASC" : "DESC";
    params.forEach((value, i) =>
      req.input(
        "d" + i,
        types[i] === "text" ? this.sql.NVarChar(100) : this.sql.Int,
        value,
      ),
    );
    const r = await req.query(
      `SELECT TOP (${safeLimit(limit)}) ${dashboardProjection},COUNT(*) OVER() AS TOTAL_COUNT ${dashboardJoins(this)}${where} ORDER BY A.APPLICATION_DATE ${direction},A.APPLICATION_ID ${direction}`,
    );
    return r.recordset;
  }
  async allApplications(user) {
    const req = this.request(),
      { conditions, params, types } = dashboardConditions(user),
      where = conditions.length
        ? " WHERE " +
          conditions
            .map((_, i) => `${conditions[i].split("=")[0]}=@d${i}`)
            .join(" AND ")
        : "";
    params.forEach((value, i) =>
      req.input(
        "d" + i,
        types[i] === "text" ? this.sql.NVarChar(100) : this.sql.Int,
        value,
      ),
    );
    const r = await req.query(
      `SELECT ${dashboardProjection} ${dashboardJoins(this)}${where} ORDER BY A.APPLICATION_DATE DESC,A.APPLICATION_ID DESC`,
    );
    return r.recordset;
  }
  async dashboardApplicationCount(user, status) {
    const req = this.request(),
      { conditions, params, types } = dashboardConditions(user, status),
      where = conditions.length
        ? " WHERE " +
          conditions
            .map((_, i) => `${conditions[i].split("=")[0]}=@d${i}`)
            .join(" AND ")
        : "";
    params.forEach((value, i) =>
      req.input(
        "d" + i,
        types[i] === "text" ? this.sql.NVarChar(100) : this.sql.Int,
        value,
      ),
    );
    const r = await req.query(
      `SELECT COUNT(*) AS n ${dashboardJoins(this)}${where}`,
    );
    return Number(r.recordset[0].n);
  }
  async dashboardOfferings({
    unverified = false,
    closingFrom,
    closingTo,
    limit = 8,
  } = {}) {
    const req = this.request(),
      filter = unverified
        ? `(COALESCE(JSON_VALUE(C.PAYLOAD,'$.status'),'pending')<>'verified' OR COALESCE(JSON_VALUE(C.PAYLOAD,'$.intake'),'0')<>'2028')`
        : closingFrom && closingTo
          ? `JSON_VALUE(C.PAYLOAD,'$.status')='verified' AND JSON_VALUE(C.PAYLOAD,'$.intake')='2028' AND O.APPLICATION_CLOSING_DATE>=@from AND O.APPLICATION_CLOSING_DATE<=@to`
          : "1=0";
    if (!unverified && closingFrom && closingTo) {
      req.input("from", this.sql.Date, closingFrom);
      req.input("to", this.sql.Date, closingTo);
    }
    const r = await req.query(
      `SELECT TOP (${safeLimit(limit)}) O.UNI_QUAL_ID,O.UNIVERSITY_ID,O.APPLICATION_CLOSING_DATE,U.UNIVERSITY_NAME,Q.QUAL_NAME,C.PAYLOAD,COALESCE(JSON_VALUE(C.PAYLOAD,'$.status'),'pending') AS POLICY_STATUS,COUNT(*) OVER() AS TOTAL_COUNT FROM ${this.name("UNI_QUALIFICATIONS")} O JOIN ${this.name("UNIVERSITIES")} U ON U.UNIVERSITY_ID=O.UNIVERSITY_ID JOIN ${this.name("QUALIFICATIONS")} Q ON Q.QUAL_ID=O.QUAL_ID LEFT JOIN ${this.name("security.Policies")} C ON C.UNI_QUAL_ID=O.UNI_QUAL_ID WHERE ${filter} ORDER BY CASE WHEN O.APPLICATION_CLOSING_DATE IS NULL THEN 1 ELSE 0 END,O.APPLICATION_CLOSING_DATE ASC,O.UNI_QUAL_ID ASC`,
    );
    return r.recordset;
  }
  async createPerson(data, { type, schoolId = null, universityId = null }) {
    const req = this.request();
    for (const [name, value] of Object.entries(data)) {
      const c = info("PERSONS").columns[name];
      if (!c) throw new Error("Unknown person column.");
      req.input(name, this.sql.VarChar(Number(c.size)), value ?? null);
    }
    req.input("PERSON_TYPE", this.sql.VarChar(1), type);
    req.input("SCHOOL_ID", this.sql.Int, schoolId);
    req.input("UNIVERSITY_ID", this.sql.Int, universityId);
    const r = await req.execute("dbo.usp_CreatePersonWithRole");
    return r.recordset[0];
  }
  async insert(t, data) {
    const req = this.request(),
      p = this.bind(req, t, data, "v"),
      identity = info(t).identity;
    const r = await req.query(
      `INSERT INTO ${this.name(t)} (${p.map((v) => "[" + v.key + "]")}) ${identity ? "" : "OUTPUT INSERTED.* "}VALUES (${p.map((v) => "@" + v.param)});${identity ? " SELECT * FROM " + this.name(t) + " WHERE [" + identity + "]=CAST(SCOPE_IDENTITY() AS INT);" : ""}`,
    );
    return r.recordset[0];
  }
  async update(t, where, data) {
    if (!Object.keys(where).length) throw new Error("Unscoped update.");
    const req = this.request(),
      p = this.bind(req, t, data, "v"),
      w = this.bind(req, t, where, "w");
    const r = await req.query(
      `UPDATE ${this.name(t)} SET ${p.map((v) => "[" + v.key + "]=@" + v.param)} WHERE ${w.map((v) => "[" + v.key + "]=@" + v.param).join(" AND ")}`,
    );
    return r.rowsAffected[0];
  }
  async remove(t, where) {
    if (!Object.keys(where).length) throw new Error("Unscoped delete.");
    const req = this.request(),
      w = this.bind(req, t, where, "w");
    const r = await req.query(
      `DELETE FROM ${this.name(t)} WHERE ${w.map((v) => "[" + v.key + "]=@" + v.param).join(" AND ")}`,
    );
    return r.rowsAffected[0];
  }
  async tx(fn) {
    const sql = this.sql;
    const transaction = new sql.Transaction(this.pool);
    await transaction.begin(sql.ISOLATION_LEVEL.SERIALIZABLE);
    try {
      const result = await fn(new SqlStore(this.pool, transaction, sql));
      await transaction.commit();
      return result;
    } catch (e) {
      try {
        await transaction.rollback();
      } catch {}
      throw e;
    }
  }
  async close() {
    await this.pool.close();
  }
}
