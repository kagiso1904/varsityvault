import express from "express";
import { fileURLToPath } from "node:url";
import { fullApi } from "./full-api.js";
const publicPath = fileURLToPath(new URL("../public/", import.meta.url));
const sharedPath = fileURLToPath(new URL("../shared/", import.meta.url));
export function createFullApplication(store, options = {}) {
  const app = express();
  app.disable("x-powered-by");
  const proxy = String(process.env.TRUST_PROXY || "").trim();
  if (proxy) {
    if (["true", "false"].includes(proxy.toLowerCase()))
      throw new Error(
        "TRUST_PROXY must identify trusted proxy addresses or hop count, not true/false.",
      );
    app.set("trust proxy", /^\d+$/.test(proxy) ? Number(proxy) : proxy);
  }
  app.use((req, res, next) => {
    res.set({
      "X-Content-Type-Options": "nosniff",
      "Referrer-Policy": "no-referrer",
      "Cache-Control": "no-store",
      "Content-Security-Policy":
        "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'",
    });
    next();
  });
  app.use(express.json({ limit: "64kb" }));
  app.use(
    "/api",
    fullApi(store, {
      secureCookies: process.env.COOKIE_SECURE === "true",
      ...options,
    }),
  );
  app.get("/favicon.ico", (req, res) => res.sendStatus(204));
  app.use("/shared", express.static(sharedPath));
  app.use(express.static(publicPath));
  app.use((req, res) => res.status(404).send("Page not found."));
  app.use((error, req, res, next) => {
    if (res.headersSent) return next(error);
    const status =
      error.status >= 400 && error.status < 500 ? error.status : 500;
    if (status === 500) {
      if (process.env.NODE_ENV === "production")
        console.error("Request failed:", error.code || error.name);
      else
        console.error("Request failed:", {
          method: req.method,
          path: req.path,
          code: error.code || error.name,
          message: error.message,
        });
    }
    res.status(status).json({
      error:
        status === 500
          ? "The operation could not be completed. No changes were committed."
          : error.message,
    });
  });
  return app;
}
