/** Identity helpers shared by the SQL Server and local-development adapters. */
export function sameId(left, right) {
  if (
    left === null ||
    left === undefined ||
    right === null ||
    right === undefined
  )
    return false;
  const a = String(left).trim();
  const b = String(right).trim();
  if (!a || !b) return false;
  if (/^\d+$/.test(a) && /^\d+$/.test(b)) return Number(a) === Number(b);
  return a === b;
}

const personNamePattern =
  /^\p{L}[\p{L}\p{M}]*(?:[ '\u2019-]\p{L}[\p{L}\p{M}]*)*(?:\.\s*\p{L}[\p{L}\p{M}]*)*\.?$/u;
export function isValidPersonName(value) {
  if (typeof value !== "string") return false;
  const name = value.trim();
  return name.length > 0 && name.length <= 100 && personNamePattern.test(name);
}

export const normalizeIdentity = (value) =>
  String(value ?? "")
    .trim()
    .toLowerCase();

export function isEmailLike(value) {
  if (typeof value !== "string") return false;
  const email = value.trim();
  if (email.length > 254 || email.includes("..")) return false;
  const parts = email.split("@");
  if (
    parts.length !== 2 ||
    !parts[0] ||
    parts[0].length > 64 ||
    parts[0].startsWith(".") ||
    parts[0].endsWith(".")
  )
    return false;
  return (
    /^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+$/.test(parts[0]) &&
    /^(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,63}$/.test(
      parts[1],
    )
  );
}

export function hasRepeatedEmailSuffix(value) {
  const email = normalizeIdentity(value);
  const domain = email.includes("@")
    ? email.slice(email.lastIndexOf("@") + 1)
    : "";
  return /\.(com|net|org|edu|gov|co\.za|ac\.za|gov\.za)\.\1$/i.test(domain);
}

export function findPersonIdentityMatches(
  people,
  loginEmail,
  excludePersonId = null,
) {
  const key = normalizeIdentity(loginEmail);
  if (!key) return [];
  return people.filter((person) => {
    if (excludePersonId !== null && sameId(person.PERSON_ID, excludePersonId))
      return false;
    return [person.EMAIL, person.USERNAME].some(
      (value) => normalizeIdentity(value) === key,
    );
  });
}

export function personIdentityWarnings(
  person,
  loginEmail,
  roleIsUnambiguous = true,
) {
  const warnings = [];
  if (!person) return ["The login account has no matching PERSONS record."];
  const email = normalizeIdentity(person.EMAIL);
  const username = normalizeIdentity(person.USERNAME);
  const login = normalizeIdentity(loginEmail);
  if (!isEmailLike(person.EMAIL))
    warnings.push("The profile email is empty or malformed.");
  if (hasRepeatedEmailSuffix(person.EMAIL))
    warnings.push(
      "The profile email appears to repeat a domain suffix; verify it before correcting it.",
    );
  if (hasRepeatedEmailSuffix(person.USERNAME))
    warnings.push(
      "The profile username appears to repeat a domain suffix; verify it before correcting it.",
    );
  if (email !== login)
    warnings.push("The profile email differs from the login email.");
  if (username !== login)
    warnings.push("The PERSONS username differs from the login email.");
  if (!roleIsUnambiguous)
    warnings.push("The person has missing or ambiguous role records.");
  return warnings;
}

export function isValidSouthAfricanPhone(value) {
  const phone = String(value ?? "").trim();
  return phone === "" || /^0\d{9}$/.test(phone);
}

export function normalizeSouthAfricanIdNumber(value) {
  return value == null ? "" : String(value).trim();
}

export function isValidSouthAfricanIdNumber(value) {
  if (value == null) return true;
  if (typeof value !== "string") return false;
  const idNumber = value.trim();
  if (idNumber === "") return true;
  if (!/^\d{13}$/.test(idNumber)) return false;

  const yy = Number(idNumber.slice(0, 2));
  const month = Number(idNumber.slice(2, 4));
  const day = Number(idNumber.slice(4, 6));
  const currentYear = new Date().getFullYear();
  const currentShortYear = currentYear % 100;
  const year = yy <= currentShortYear ? 2000 + yy : 1900 + yy;
  const birthDate = new Date(Date.UTC(year, month - 1, day));
  if (
    month < 1 ||
    month > 12 ||
    day < 1 ||
    day > 31 ||
    birthDate.getUTCFullYear() !== year ||
    birthDate.getUTCMonth() !== month - 1 ||
    birthDate.getUTCDate() !== day ||
    birthDate.getTime() > Date.now()
  )
    return false;

  return true;
}

export function findPersonSaIdMatches(
  people,
  saIdNumber,
  excludePersonId = null,
) {
  const key = normalizeSouthAfricanIdNumber(saIdNumber);
  if (!/^\d{13}$/.test(key)) return [];
  return people.filter((person) => {
    if (excludePersonId !== null && sameId(person.PERSON_ID, excludePersonId))
      return false;
    return normalizeSouthAfricanIdNumber(person.SA_ID_NUMBER) === key;
  });
}
