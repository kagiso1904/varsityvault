import { audit, digest } from "./security.js";
import { randomUUID } from "node:crypto";
const conflict = (message) => {
  throw Object.assign(new Error(message), { status: 409 });
};
export async function records(db, event, key) {
  const mapRows = await db.list("security.Audit", {
    EVENT: "schema.person-keys",
  });
  const migration = mapRows.length ? JSON.parse(mapRows.at(-1).DETAIL) : null;
  const legacy = new Set(
    (migration?.legacyAuditIds || []).map((r) => r.auditId),
  );
  const learnerIds = new Map(
    (migration?.learners || []).map((r) => [String(r.oldId), r.personId]),
  );
  const teacherIds = new Map(
    (migration?.teachers || []).map((r) => [String(r.oldId), r.personId]),
  );
  return (await db.list("security.Audit", { EVENT: event }))
    .map((r) => {
      const value = { ...JSON.parse(r.DETAIL), recordedAt: r.CREATED_AT };
      if (legacy.has(r.AUDIT_ID)) {
        if (["admissions.results", "admissions.verification"].includes(event)) {
          const [oldId, ...tail] = String(value.key).split(":");
          if (!learnerIds.has(oldId)) return null;
          value.key = [learnerIds.get(oldId), ...tail].join(":");
        }
        if (value.learnerId != null && learnerIds.has(String(value.learnerId)))
          value.learnerId = learnerIds.get(String(value.learnerId));
        if (Array.isArray(value.rows))
          value.rows = value.rows.map((row) => ({
            ...row,
            ...(learnerIds.has(String(row.LEARNER_ID))
              ? { LEARNER_ID: learnerIds.get(String(row.LEARNER_ID)) }
              : {}),
            ...(teacherIds.has(String(row.VERIFIED_BY_TEACHER_ID))
              ? {
                  VERIFIED_BY_TEACHER_ID: teacherIds.get(
                    String(row.VERIFIED_BY_TEACHER_ID),
                  ),
                }
              : {}),
          }));
      }
      return value;
    })
    .filter((r) => r && r.key === key)
    .sort((a, b) => a.version - b.version);
}
export async function append(db, personId, event, key, data) {
  const old = await records(db, event, key);
  const value = { ...data, key, version: (old.at(-1)?.version || 0) + 1 };
  await audit(db, personId, event, value);
  return value;
}
export async function snapshot(db, personId, learnerId, examId) {
  const rows = (
    await db.list("LEARNER_RESULTS", {
      LEARNER_ID: learnerId,
      EXAM_TYPE_ID: examId,
    })
  ).sort((a, b) => Number(a.SUBJECT_ID) - Number(b.SUBJECT_ID));
  const key = `${learnerId}:${examId}`;
  const old = (await records(db, "admissions.results", key)).at(-1);
  if (old && digest(JSON.stringify(old.rows)) === digest(JSON.stringify(rows)))
    return old;
  return append(db, personId, "admissions.results", key, {
    learnerId,
    examId,
    rows,
  });
}
export async function reviewVersion(db, app) {
  const learner = (await db.list("LEARNERS", { PERSON_ID: app.LEARNER_ID }))[0];
  const rows = (
    await db.list("LEARNER_RESULTS", { LEARNER_ID: app.LEARNER_ID })
  ).sort(
    (a, b) =>
      Number(a.EXAM_TYPE_ID) - Number(b.EXAM_TYPE_ID) ||
      Number(a.SUBJECT_ID) - Number(b.SUBJECT_ID),
  );
  const docs = (await db.list("DOCUMENTS", { PERSON_ID: learner.PERSON_ID }))
    .map(({ DOCUMENT_BLOB, ...r }) => ({
      ...r,
      contentHash: DOCUMENT_BLOB ? digest(Buffer.from(DOCUMENT_BLOB)) : null,
    }))
    .sort((a, b) => Number(a.DOCUMENT_ID) - Number(b.DOCUMENT_ID));
  const policies = await db.list("security.Policies", {
    UNI_QUAL_ID: app.UNI_QUAL_ID,
  });
  return digest(JSON.stringify({ app, rows, docs, policies }));
}
export function requireVersion(actual, expected) {
  if (typeof expected !== "string" || actual !== expected)
    conflict(
      "This record or its evidence has changed. Reload and review the current version before saving.",
    );
}
export const newPolicyId = () => randomUUID();
