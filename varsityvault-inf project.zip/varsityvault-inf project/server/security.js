import {
  randomBytes,
  scrypt as derive,
  timingSafeEqual,
  createHash,
  randomUUID,
} from "node:crypto";
import { promisify } from "node:util";
import { sameId } from "./identity.js";
const scrypt = promisify(derive);
export const token = () => randomBytes(32).toString("hex");
export const digest = (value) =>
  createHash("sha256").update(value).digest("hex");
export async function passwordHash(password) {
  if (
    typeof password !== "string" ||
    password.length < 12 ||
    password.length > 128 ||
    !password.trim() ||
    /[\u0000-\u001f\u007f]/.test(password)
  )
    throw Object.assign(new Error("Use a password of 12–128 characters."), {
      status: 400,
    });
  const salt = randomBytes(16).toString("hex");
  return salt + ":" + (await scrypt(password, salt, 64)).toString("hex");
}
export async function checkPassword(password, hash) {
  const [salt, key] = String(hash || "").split(":");
  if (typeof password !== "string" || password.length > 128 || !salt || !key)
    return false;
  const calculated = await scrypt(password, salt, 64),
    expected = Buffer.from(key, "hex");
  return (
    expected.length === calculated.length &&
    timingSafeEqual(calculated, expected)
  );
}
export async function audit(db, personId, event, detail) {
  await db.insert("security.Audit", {
    AUDIT_ID: randomUUID(),
    PERSON_ID: personId,
    EVENT: event,
    DETAIL: JSON.stringify(detail),
    CREATED_AT: new Date().toISOString(),
  });
}
export async function userContext(db, id) {
  const p = (await db.list("PERSONS", { PERSON_ID: id }))[0];
  if (!p) return null;
  const roles = [];
  for (const [table, key, role] of [
    ["LEARNERS", "PERSON_ID", "learner"],
    ["TEACHERS", "PERSON_ID", "teacher"],
    ["UNIVERSITY_REPS", "PERSON_ID", "representative"],
    ["ITADMINS", "PERSON_ID", "admin"],
  ]) {
    const rows = (await db.list(table, { PERSON_ID: id })).filter((row) =>
      sameId(row.PERSON_ID, id),
    );
    if (rows.length > 1) return null;
    const row = rows[0];
    if (row)
      roles.push({
        role,
        recordId: row[key],
        schoolId: row.SCHOOL_ID,
        universityId: row.UNIVERSITY_ID,
      });
  }
  if (roles.length !== 1) return null;
  const expectedType = {
    learner: "L",
    teacher: "T",
    admin: "A",
    representative: "R",
  }[roles[0].role];
  if (p.PERSON_TYPE != null && p.PERSON_TYPE !== expectedType) return null;
  return {
    personId: id,
    firstName: p.FIRST_NAME,
    lastName: p.LAST_NAME,
    email: p.EMAIL,
    username: p.USERNAME,
    ...roles[0],
  };
}
