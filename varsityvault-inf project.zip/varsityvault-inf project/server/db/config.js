export function databaseConfig(env = process.env) {
  const auth = env.DB_AUTH || "sql";
  if (!["sql", "windows"].includes(auth))
    throw new Error("DB_AUTH must be sql or windows.");
  for (const key of auth === "windows"
    ? ["DB_SERVER"]
    : ["DB_SERVER", "DB_USER", "DB_PASSWORD"])
    if (!env[key])
      throw new Error(`Set ${key} in .env before running db:check.`);
  if (env.DB_DATABASE && env.DB_DATABASE !== "VARSITYVAULT2")
    throw new Error(
      "This project expects the submitted VARSITYVAULT2 database.",
    );
  const options = {
    encrypt: env.DB_ENCRYPT !== "false",
    trustServerCertificate: env.DB_TRUST_SERVER_CERTIFICATE === "true",
  };
  const config = {
    server: env.DB_SERVER,
    database: "VARSITYVAULT2",
    user: env.DB_USER,
    password: env.DB_PASSWORD,
    options,
    connectionTimeout: 10000,
    requestTimeout: 10000,
    pool: { min: 0, max: 2, idleTimeoutMillis: 10000 },
  };
  if (env.DB_INSTANCE && env.DB_PORT)
    throw new Error("Set either DB_INSTANCE or DB_PORT, not both.");
  if (env.DB_INSTANCE) options.instanceName = env.DB_INSTANCE;
  else {
    config.port = Number(env.DB_PORT || 1433);
    if (
      !Number.isInteger(config.port) ||
      config.port < 1 ||
      config.port > 65535
    )
      throw new Error("DB_PORT must be 1–65535.");
  }
  if (auth === "windows") {
    delete config.user;
    delete config.password;
    options.trustedConnection = true;
    const driver = env.DB_ODBC_DRIVER || "ODBC Driver 18 for SQL Server";
    if (
      ![
        "ODBC Driver 17 for SQL Server",
        "ODBC Driver 18 for SQL Server",
      ].includes(driver)
    )
      throw new Error(
        "DB_ODBC_DRIVER must be ODBC Driver 17 for SQL Server or ODBC Driver 18 for SQL Server.",
      );
    if (/[;{}\r\n]/.test(env.DB_SERVER + (env.DB_INSTANCE || "")))
      throw new Error(
        "DB_SERVER and DB_INSTANCE contain invalid connection characters.",
      );
    if (env.DB_SERVER.includes("\\") && env.DB_INSTANCE)
      throw new Error(
        "Set the instance in DB_INSTANCE only, not also in DB_SERVER.",
      );
    const server = env.DB_INSTANCE
      ? `${env.DB_SERVER}\\${env.DB_INSTANCE}`
      : env.DB_SERVER.includes("\\") && !env.DB_PORT
        ? env.DB_SERVER
        : `${env.DB_SERVER},${config.port}`;
    config.connectionString = `Driver={${driver}};Server=${server};Database=VARSITYVAULT2;Trusted_Connection=yes;Encrypt=${options.encrypt ? "yes" : "no"};TrustServerCertificate=${options.trustServerCertificate ? "yes" : "no"};`;
  }
  return config;
}
