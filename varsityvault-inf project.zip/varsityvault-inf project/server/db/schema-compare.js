const quote = (value) => "N'" + String(value).replaceAll("'", "''") + "'";
const validName = (value) => {
  if (typeof value !== "string" || !/^[_A-Za-z][_A-Za-z0-9]*$/.test(value))
    throw new Error("Invalid SQL schema contract identifier.");
  return value;
};
export const securityReadinessQuery =
  "SELECT OBJECT_ID(N'VarsityVaultSecurity.dbo.LoginAttempts', N'U') AS LoginAttemptsObjectId";
export function schemaCheckQueries(expected) {
  const objectChecks = expected.objects
    .map(({ name, type }) => {
      name = validName(name);
      type = validName(type);
      return `SELECT ${quote(name)} AS object_name WHERE OBJECT_ID(N'dbo.${name}', ${quote(type)}) IS NULL`;
    })
    .join("\nUNION ALL\n");
  const columnChecks = expected.columns
    .map(({ table, name }) => {
      table = validName(table);
      name = validName(name);
      return `SELECT ${quote(table)} AS table_name, ${quote(name)} AS column_name WHERE COL_LENGTH(N'dbo.${table}', ${quote(name)}) IS NULL`;
    })
    .join("\nUNION ALL\n");
  return { objectChecks, columnChecks };
}
