import { loadSqlDriver } from "./driver.js";
import { databaseConfig } from "./config.js";
import { readFile } from "node:fs/promises";
import {
  schemaCheckQueries,
  securityReadinessQuery,
} from "./schema-compare.js";
const expected = JSON.parse(
  await readFile(
    new URL("../../config/schema-contract.json", import.meta.url),
    "utf8",
  ),
);
let pool;
let securityReady = false;
try {
  const config = databaseConfig(),
    sql = await loadSqlDriver();
  pool = new sql.ConnectionPool(config);
  pool.on("error", () => console.error("SQL Server connection pool error."));
  await pool.connect();
  const identity = await pool
    .request()
    .query(
      "SELECT SUSER_SNAME() AS LoginName, DB_NAME() AS DatabaseName, SERVERPROPERTY('IsIntegratedSecurityOnly') AS WindowsAuthOnly",
    );
  console.log("Connected:", identity.recordset[0]);
  const security = await pool
    .request()
    .query("SELECT name FROM sys.databases WHERE name='VarsityVaultSecurity'");
  if (!security.recordset.length)
    console.error(
      "VarsityVaultSecurity is not visible. Before setup/start, run database/security.sql in SSMS on this instance.",
    );
  else {
    const readiness = await pool.request().query(securityReadinessQuery);
    securityReady = Boolean(readiness.recordset[0]?.LoginAttemptsObjectId);
    if (!securityReady)
      console.error(
        "VarsityVaultSecurity.dbo.LoginAttempts is missing or not visible. Re-run database/security.sql in SSMS on this instance, then run db:check again.",
      );
  }
  const { objectChecks, columnChecks } = schemaCheckQueries(expected);
  const [objects, columns] = await Promise.all([
    pool.request().query(objectChecks),
    pool.request().query(columnChecks),
  ]);
  const invariants = await pool.request().query(`
    SELECT t.name FROM sys.tables t WHERE t.name IN ('LEARNERS','TEACHERS','ITADMINS','UNIVERSITY_REPS')
    AND NOT EXISTS(SELECT 1 FROM sys.key_constraints k JOIN sys.index_columns i ON i.object_id=k.parent_object_id AND i.index_id=k.unique_index_id
    JOIN sys.columns c ON c.object_id=i.object_id AND c.column_id=i.column_id
    WHERE k.type='PK' AND k.parent_object_id=t.object_id AND c.name='PERSON_ID')
    UNION ALL SELECT name FROM sys.triggers WHERE is_disabled=1 AND (name LIKE '%ROLE' OR name LIKE '%GEOGRAPHY');
  `);
  const legacy = await pool.request().query(`
    SELECT t.name FROM sys.tables t JOIN sys.columns c ON c.object_id=t.object_id
    WHERE t.schema_id=SCHEMA_ID(N'dbo') AND ((t.name='LEARNERS' AND c.name='LEARNER_ID')
    OR (t.name='TEACHERS' AND c.name='TEACHER_ID') OR (t.name='ITADMINS' AND c.name='ITADMIN_IID')
    OR (t.name='UNIVERSITY_REPS' AND c.name='REP_ID'));
  `);
  if (legacy.recordset.length) {
    console.error(
      "Remove obsolete role IDs using database/04_use_person_id_for_subtypes.sql:",
      legacy.recordset,
    );
    process.exitCode = 1;
  }
  if (invariants.recordset.length) {
    console.error("ERD primary key or trigger mismatch:", invariants.recordset);
    process.exitCode = 1;
  }
  const missingObjects = objects.recordset.map((row) => row.object_name);
  const missingColumns = columns.recordset.map((row) => ({
    table: row.table_name,
    name: row.column_name,
  }));
  if (missingObjects.length || missingColumns.length) {
    console.error("Schema mismatch:", { missingObjects, missingColumns });
    process.exitCode = 1;
  }
  if (!securityReady) process.exitCode = 1;
  else if (!process.exitCode)
    console.log(
      `Read-only schema check passed: ${expected.objects.length} objects and ${expected.columns.length} columns. No database changes made.`,
    );
} catch (error) {
  console.error(
    "Database check failed:",
    error.code || "",
    error.message,
    "See docs/windows-auth.md for Windows connection troubleshooting.",
  );
  process.exitCode = 1;
} finally {
  if (pool) await pool.close();
}
