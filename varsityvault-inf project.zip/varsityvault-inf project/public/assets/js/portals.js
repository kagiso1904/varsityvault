import {
  createReviewState,
  schoolLearners,
  institutionApplications,
  verifyReviewResults,
  verifyReviewDocument,
  transitionReview,
} from "/shared/review/workflow.js";
const e = (s) =>
  String(s ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
const anchor = (href, label) => /* HTML */ `
  <a class="inline-link" href="${href}">
    ${e(label)}
    <i data-lucide="arrow-right" aria-hidden="true"></i>
  </a>
`;
const status = (s) => /* HTML */ ` <span class="state-badge">${e(s)}</span> `;
const names = {
  learner: "Learner",
  teacher: "Career Guidance Teacher",
  representative: "University Representative",
  admin: "IT Administrator",
};
function loadState(storage) {
  try {
    const s = JSON.parse(storage.getItem("vv-portal-review"));
    if (
      s?.version === 1 &&
      Array.isArray(s.learners) &&
      Array.isArray(s.applications)
    )
      return s;
  } catch {}
  return createReviewState();
}
function stats(items) {
  return /* HTML */ `
    <div class="dashboard-stats">
      ${items
        .map(
          ([label, value, detail, icon, href]) => /* HTML */ `
            <a class="stat-card" href="${href}">
              <span class="stat-icon"
                ><i data-lucide="${icon}" aria-hidden="true"></i
              ></span>
              <div>
                <h2>${e(label)}</h2>
                <strong>${e(value)}</strong>
                <small>${e(detail)}</small>
              </div>
            </a>
          `,
        )
        .join("")}
    </div>
  `;
}
function table(headers, rows) {
  return /* HTML */ `
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            ${headers
              .map((h) => /* HTML */ ` <th scope="col">${e(h)}</th> `)
              .join("")}
          </tr>
        </thead>
        <tbody>
          ${
            rows.length
              ? rows.join("")
              : /* HTML */ `
                  <tr>
                    <td colspan="${headers.length}">
                      No matching sample records.
                    </td>
                  </tr>
                `
          }
        </tbody>
      </table>
    </div>
  `;
}
function heading(name, description) {
  return /* HTML */ `
    <div class="page-heading">
      <span class="eyebrow">YOUR NEXT CHAPTER</span>
      <h1>${e(name)}</h1>
      <p>${e(description)}</p>
    </div>
  `;
}
export function renderPortal({
  main,
  role,
  page,
  policies,
  marks,
  score,
  storage,
  icons,
}) {
  let state = loadState(storage);
  const save = () => {
    try {
      storage.setItem("vv-portal-review", JSON.stringify(state));
    } catch {
      throw new Error(
        "Browser storage is unavailable; the sample change cannot be retained.",
      );
    }
  };
  const learners = () => schoolLearners(state),
    apps = () =>
      state.applications.filter((a) =>
        learners().some((l) => l.id === a.learnerId),
      ),
    instApps = () => institutionApplications(state);
  const myLearner = () => state.learners[0],
    myApps = () =>
      state.applications.filter((a) => a.learnerId === myLearner().id);
  const learnerName = (id) =>
    state.learners.find((l) => l.id === id)?.name || "Sample learner";
  const documents = () =>
    learners().flatMap((l) => l.documents.map((d) => ({ ...d, learner: l })));
  function welcome(description) {
    return /* HTML */ `
      <section class="welcome-panel">
        <div>
          <span>${e(names[role])} portal</span>
          <h1>
            Welcome back,
            ${role === "learner" ? "Learner" : role === "teacher" ? "Career Teacher" : role === "representative" ? "Admissions Team" : "Administrator"}
          </h1>
          <p>${e(description)}</p>
        </div>
        <span class="welcome-cycle">
          2028
          <br />
          <small>ADMISSIONS</small>
        </span>
      </section>
    `;
  }
  function appRows(list, controls = false) {
    return list.map(
      (a) => /* HTML */ `
        <tr>
          <th scope="row">${e(learnerName(a.learnerId))}</th>
          <td>
            ${e(a.qualification)}
            <small class="cell-note"
              >${e(a.university.toUpperCase())} · ${a.intake}</small
            >
          </td>
          <td>${status(a.status)}</td>
          <td>
            ${
              controls && role === "teacher" && a.status === "Submitted"
                ? /* HTML */ `
                    <button class="secondary compact" data-screen="${a.id}">
                      Screen sample
                    </button>
                  `
                : controls &&
                    role === "representative" &&
                    a.status === "Screened by Career Teacher"
                  ? /* HTML */ `
                      <button
                        class="secondary compact"
                        data-decision="${a.id}"
                        data-target="Provisionally Accepted"
                      >
                        Provisional accept
                      </button>
                      <button
                        class="secondary compact"
                        data-decision="${a.id}"
                        data-target="Rejected"
                      >
                        Reject sample
                      </button>
                    `
                  : anchor(
                      "/" + role + "/applications.html#" + a.id,
                      "View history",
                    )
            }
          </td>
        </tr>
      `,
    );
  }
  function performance() {
    return /* HTML */ `
      <section class="panel">
        <div class="panel-header">
          <h2>Academic performance</h2>
          ${anchor("/learner/results.html", "Open results")}
        </div>
        <div
          class="academic-bars"
          role="img"
          aria-label="Sample Grade 11 subject percentages from zero to one hundred"
        >
          ${[
            "isiXhosa HL",
            "English FAL",
            "Mathematics",
            "Life Orientation",
            "Accounting",
            "Business Studies",
            "Economics",
          ]
            .map((name, i) => {
              const value =
                typeof marks[i] === "number" && marks[i] >= 0 && marks[i] <= 100
                  ? marks[i]
                  : null;
              return /* HTML */ `
                <div class="academic-row">
                  <span>${name}</span>
                  <progress
                    max="100"
                    value="${value ?? 0}"
                    aria-label="${name}"
                  ></progress>
                  <strong
                    >${value === null ? "Missing" : e(value) + "%"}</strong
                  >
                </div>
              `;
            })
            .join("")}
        </div>
        <p class="muted">
          Fixed sample curriculum · no programme eligibility claim.
        </p>
      </section>
    `;
  }
  function distribution(list) {
    const groups = [
      "Submitted",
      "Screened by Career Teacher",
      "Provisionally Accepted",
      "Rejected",
    ];
    return /* HTML */ `
      <section class="panel">
        <h2>Application status</h2>
        <div class="status-summary">
          ${groups
            .map(
              (s) => /* HTML */ `
                <div>
                  <span>${s}</span>
                  <strong>${list.filter((a) => a.status === s).length}</strong>
                </div>
              `,
            )
            .join("")}
        </div>
      </section>
    `;
  }
  function teacherDocs() {
    return table(
      ["Learner name", "Document type", "Date uploaded", "Status", "Review"],
      documents().map(
        (d) => /* HTML */ `
          <tr>
            <th scope="row">${e(d.learner.name)}</th>
            <td>${e(d.type)}</td>
            <td>${e(d.date)}</td>
            <td>${status(d.status)}</td>
            <td>
              ${
                d.status === "Pending"
                  ? /* HTML */ `
                      <button
                        class="secondary compact"
                        data-verify-doc="${d.id}"
                        data-learner="${d.learner.id}"
                      >
                        Verify sample
                      </button>
                    `
                  : "Reviewed"
              }
            </td>
          </tr>
        `,
      ),
    );
  }
  function timelines(list) {
    return list
      .map(
        (a) => /* HTML */ `
          <section class="panel" id="${a.id}">
            <div class="panel-header">
              <h2>${e(a.qualification)}</h2>
              ${status(a.status)}
            </div>
            <p class="muted">
              ${e(learnerName(a.learnerId))} · ${e(a.university.toUpperCase())}
              · 2028 · Simulated record
            </p>
            <ol class="timeline">
              ${a.history
                .map(
                  (h) => /* HTML */ `
                    <li>
                      <strong>${e(h.status)}</strong>
                      <span>
                        ${e(new Date(h.at).toLocaleString("en-ZA", { timeZone: "Africa/Johannesburg" }))}
                        · ${e(h.actor)}
                      </span>
                    </li>
                  `,
                )
                .join("")}
            </ol>
          </section>
        `,
      )
      .join("");
  }
  function draw() {
    let html = "";
    if (page === "overview") {
      if (role === "learner")
        html =
          welcome(
            "Track your academic results, check university requirements and prepare your application documents.",
          ) +
          stats([
            [
              "Current " + score.metric,
              score.total === null ? "Not calculated" : score.total,
              "Selected university review · sample results",
              "award",
              "/learner/requirements.html",
            ],
            [
              "Active applications",
              myApps().filter((a) => a.status !== "Rejected").length,
              "Simulated applications",
              "send",
              "/learner/applications.html",
            ],
            [
              "Uploaded documents",
              myLearner().documents.length,
              "Simulated records",
              "folder-open",
              "/learner/documents.html",
            ],
            [
              "Profile status",
              "Action needed",
              "Verify programme rules before applying",
              "circle-alert",
              "/learner/profile.html",
            ],
          ]) +
          performance() +
          /* HTML */ `
            <section class="panel">
              <h2>Quick actions</h2>
              <div class="context-links">
                ${anchor("/learner/requirements.html", "Check requirements")}${anchor("/learner/subjects.html", "My subjects")}${anchor("/learner/universities.html", "Browse all 26 universities")}
              </div>
            </section>
          `;
      if (role === "teacher")
        html =
          welcome(
            "Manage your learners, review uploaded documents and verify academic results from your school workspace.",
          ) +
          stats([
            [
              "My learners",
              learners().length,
              "Registered at the sample school",
              "users",
              "/teacher/learners.html",
            ],
            [
              "Documents to review",
              documents().filter((d) => d.status === "Pending").length,
              "Pending sample uploads",
              "file-check-2",
              "/teacher/documents.html",
            ],
            [
              "Active subjects",
              7,
              "Fixed review curriculum",
              "book-open",
              "/teacher/results.html",
            ],
          ]) +
          /* HTML */ `
            <section class="panel">
              <div class="panel-header">
                <h2>Documents awaiting review</h2>
                ${anchor("/teacher/documents.html", "Open documents")}
              </div>
              ${teacherDocs()}
            </section>
          ` +
          distribution(apps());
      if (role === "representative")
        html =
          welcome(
            "Review screened applications, record admission decisions and monitor your institution’s application queue.",
          ) +
          stats([
            [
              "Applications received",
              instApps().length,
              "WSU simulated institution",
              "inbox",
              "/representative/applications.html",
            ],
            [
              "Ready for review",
              instApps().filter(
                (a) => a.status === "Screened by Career Teacher",
              ).length,
              "Teacher-screened applications",
              "clipboard-check",
              "/representative/decisions.html",
            ],
            [
              "Provisional offers",
              instApps().filter((a) => a.status === "Provisionally Accepted")
                .length,
              "Sample decisions only",
              "badge-check",
              "/representative/applications.html",
            ],
          ]) +
          /* HTML */ `
            <section class="panel">
              <div class="panel-header">
                <h2>Institution applications</h2>
                ${anchor("/representative/decisions.html", "Review decisions")}
              </div>
              ${table(["Learner", "Qualification", "Status", "Action"], appRows(instApps(), false))}
            </section>
          ` +
          distribution(instApps());
      if (role === "admin")
        html =
          welcome(
            "Maintain institution directories, review academic lookup coverage and track policy verification for the 2028 intake.",
          ) +
          stats([
            [
              "Universities",
              policies.length,
              "Review policy directory",
              "building-2",
              "/admin/directories.html",
            ],
            [
              "Province labels",
              new Set(
                policies
                  .flatMap((p) => p.provinces)
                  .filter((p) => p !== "National"),
              ).size,
              "Configuration campus coverage",
              "map-pinned",
              "/admin/directories.html",
            ],
            [
              "Policies awaiting release",
              policies.filter((p) => !p.submissionEnabled).length,
              "Programme verification remains pending",
              "book-open",
              "/admin/policies.html",
            ],
          ]) +
          /* HTML */ `
            <section class="panel">
              <h2>Administration tasks</h2>
              <ul class="checks">
                <li>
                  <div>
                    Institution directories
                    <small>Review coverage across all 26 universities</small>
                  </div>
                  ${anchor("/admin/directories.html", "Open directories")}
                </li>
                <li>
                  <div>
                    Academic lookup tables
                    <small>ERD-aligned academic records</small>
                  </div>
                  ${anchor("/admin/lookups.html", "View lookups")}
                </li>
                <li>
                  <div>
                    Policy verification
                    <small
                      >Confirm programme, intake, score units and closing
                      date</small
                    >
                  </div>
                  ${anchor("/admin/policies.html", "Review policies")}
                </li>
              </ul>
            </section>
          `;
    } else if (page === "profile") {
      const details =
        role === "learner"
          ? [
              ["Name", myLearner().name],
              ["School", "Sample Secondary School"],
              ["Curriculum", "Seven-subject NSC review"],
              ["Intake", "2028"],
            ]
          : role === "teacher"
            ? [
                ["Role", names[role]],
                ["School", "Sample Secondary School"],
                ["Access scope", "Learners at this sample school"],
              ]
            : role === "representative"
              ? [
                  ["Role", names[role]],
                  ["Institution", "Walter Sisulu University · simulated"],
                  ["Access scope", "Sample WSU applications"],
                ]
              : [
                  ["Role", names[role]],
                  ["Access scope", "Directory and lookup administration"],
                ];
      html =
        heading(
          "My profile",
          "Review identity and portal scope. Authentication and profile editing are not yet connected.",
        ) +
        /* HTML */ `
          <section class="panel">
            <dl class="details">
              ${details
                .map(
                  ([k, v]) => /* HTML */ `
                    <dt>${k}</dt>
                    <dd>${e(v)}</dd>
                  `,
                )
                .join("")}
            </dl>
            <div class="notice">
              Sample identity only. The portal selector is not an authentication
              or authorisation mechanism.
            </div>
          </section>
        `;
    } else if (page === "subjects")
      html =
        heading(
          "My subjects",
          "The current fixed review curriculum, including mandatory subject categories.",
        ) +
        /* HTML */ `
          <section class="panel">
            ${table(
              ["Subject", "Category"],
              [
                "isiXhosa Home Language|Home Language",
                "English First Additional Language|First Additional Language",
                "Mathematics|Mathematics",
                "Life Orientation|Life Orientation",
                "Accounting|Elective",
                "Business Studies|Elective",
                "Economics|Elective",
              ].map(
                (s) => /* HTML */ `
                  <tr>
                    ${s
                      .split("|")
                      .map((v) => /* HTML */ ` <td>${v}</td> `)
                      .join("")}
                  </tr>
                `,
              ),
            )}
            <div class="notice">
              Subject selection and extra-subject policy evaluation are the next
              scoring milestone.
            </div>
          </section>
        `;
    else if (role === "teacher" && page === "learners")
      html =
        heading(
          "My learners",
          "Sample records at your school; other schools are excluded.",
        ) +
        /* HTML */ `
          <section class="panel">
            ${table(
              ["Learner", "School", "Results", "Action"],
              learners().map(
                (l) => /* HTML */ `
                  <tr>
                    <th>${e(l.name)}</th>
                    <td>Sample Secondary School</td>
                    <td>
                      ${status(l.resultsVerified ? "Verified" : "Pending")}
                    </td>
                    <td>
                      ${anchor("/teacher/results.html#" + l.id, "Review results")}
                    </td>
                  </tr>
                `,
              ),
            )}
          </section>
        `;
    else if (role === "teacher" && ["results", "verification"].includes(page)) {
      html = heading(
        "Results verification",
        "Compare the digital marks with the sample report before screening.",
      );
      for (const l of learners())
        html += /* HTML */ `
          <section class="panel" id="${l.id}">
            <div class="panel-header">
              <h2>${e(l.name)}</h2>
              ${status(l.resultsVerified ? "Verified" : "Pending")}
            </div>
            ${table(
              ["Subject", "Digital mark", "Report mark", "Comparison"],
              [
                "isiXhosa HL",
                "English FAL",
                "Mathematics",
                "Life Orientation",
                "Accounting",
                "Business Studies",
                "Economics",
              ].map(
                (name, i) => /* HTML */ `
                  <tr>
                    <th>${name}</th>
                    <td>${l.marks[i]}%</td>
                    <td>${l.report[i]}%</td>
                    <td class="${l.marks[i] !== l.report[i] ? "error" : ""}">
                      ${l.marks[i] === l.report[i] ? "Matches" : "Mismatch"}
                    </td>
                  </tr>
                `,
              ),
            )}
            <div class="actions">
              <button
                data-verify-results="${l.id}"
                ${l.resultsVerified ? "disabled" : ""}
              >
                Verify sample results
              </button>
            </div>
          </section>
        `;
    } else if (role === "teacher" && page === "documents")
      html =
        heading(
          "Documents",
          "Review simulated report and ID records. No actual file uploads are included.",
        ) + /* HTML */ ` <section class="panel">${teacherDocs()}</section> `;
    else if (role === "learner" && page === "documents")
      html =
        heading(
          "My documents",
          "Sample report and ID records; review statuses follow the teacher portal.",
        ) +
        /* HTML */ `
          <section class="panel">
            ${table(
              ["Document", "Uploaded", "Verification"],
              myLearner().documents.map(
                (d) => /* HTML */ `
                  <tr>
                    <th>${e(d.type)}</th>
                    <td>${e(d.date)}</td>
                    <td>${status(d.status)}</td>
                  </tr>
                `,
              ),
            )}
            <div class="notice">
              <strong>Final NSC Certificate</strong>
              <p>
                ${myApps().some((a) => a.status === "Provisionally Accepted") ? "Provisional acceptance recorded in the sample. Live uploads are still unavailable." : "Locked until provisional acceptance."}
              </p>
            </div>
            <button disabled>Upload unavailable</button>
          </section>
        `;
    else if (page === "applications") {
      const list =
        role === "teacher"
          ? apps()
          : role === "representative"
            ? instApps()
            : myApps();
      html =
        heading(
          role === "learner" ? "My applications" : "Applications",
          "Simulated workflow only; no university application is sent.",
        ) +
        /* HTML */ `
          <section class="panel">
            ${table(["Learner", "Qualification", "Status", "Action"], appRows(list, role === "teacher"))}
          </section>
        ` +
        timelines(list);
    } else if (role === "representative" && page === "decisions")
      html =
        heading(
          "Admission decisions",
          "Only screened sample applications for WSU can receive a provisional decision.",
        ) +
        /* HTML */ `
          <section class="panel">
            ${table(["Learner", "Qualification", "Status", "Decision"], appRows(instApps(), true))}
            <p class="muted">
              Final NSC verification and final admission remain a later
              milestone.
            </p>
          </section>
        `;
    else if (role === "admin" && ["directories", "policies"].includes(page))
      html =
        heading(
          page === "policies"
            ? "University policies"
            : "Institution directories",
          "All 26 review entries; no operational SQL data is changed.",
        ) +
        /* HTML */ `
          <section class="panel">
            ${table(
              ["University", "Province / coverage", "Policy status", "Action"],
              policies.map(
                (p) => /* HTML */ `
                  <tr>
                    <th>${e(p.name)}</th>
                    <td>${e(p.provinces.join(", "))}</td>
                    <td>
                      ${status("Review only")}
                      <small class="cell-note">${e(p.year)}</small>
                    </td>
                    <td>
                      ${anchor("/learner/requirements.html?university=" + p.id, "Inspect policy")}
                    </td>
                  </tr>
                `,
              ),
            )}
            <p class="muted">
              University policy keys are configuration identifiers, not SQL
              UNIVERSITY_ID values.
            </p>
          </section>
        `;
    else if (role === "admin" && page === "lookups")
      html =
        heading(
          "Academic lookups",
          "Read-only summary of the submitted NSC baseline and application lifecycle.",
        ) +
        /* HTML */ `
          <section class="panel">
            ${table(
              ["Achievement level", "Minimum percentage", "Baseline APS"],
              [7, 6, 5, 4, 3, 2, 1].map(
                (level, i) => /* HTML */ `
                  <tr>
                    <td>${level}</td>
                    <td>${[80, 70, 60, 50, 40, 30, 0][i]}%</td>
                    <td>${level}</td>
                  </tr>
                `,
              ),
            )}
            <p class="muted">
              Institution scoring can differ from this generic baseline;
              Requirements uses the selected review policy.
            </p>
          </section>
        ` +
        distribution(state.applications);
    else return false;
    main.innerHTML =
      html +
      /* HTML */ `
        <p class="review-feedback" id="portal-feedback" role="status"></p>
        <div class="sample-footer">
          <span
            >Simulated records · changes remain in this browser session</span
          >
          <button class="secondary compact" id="reset-review">
            Reset sample workflow
          </button>
        </div>
      `;
    icons();
    main.querySelector("#reset-review").addEventListener("click", () => {
      state = createReviewState();
      try {
        save();
        draw();
      } catch (error) {
        feedback(error.message);
      }
    });
    main
      .querySelectorAll("[data-verify-results]")
      .forEach((b) =>
        b.addEventListener("click", () =>
          perform(
            () => verifyReviewResults(state, b.dataset.verifyResults),
            "Sample results verified.",
          ),
        ),
      );
    main
      .querySelectorAll("[data-verify-doc]")
      .forEach((b) =>
        b.addEventListener("click", () =>
          perform(
            () =>
              verifyReviewDocument(
                state,
                b.dataset.learner,
                b.dataset.verifyDoc,
              ),
            "Sample document verified.",
          ),
        ),
      );
    main.querySelectorAll("[data-screen]").forEach((b) =>
      b.addEventListener("click", () =>
        perform(
          () =>
            transitionReview(
              state,
              b.dataset.screen,
              "Screened by Career Teacher",
              {
                role: "teacher",
                school: "sample-school",
              },
            ),
          "Sample application screened.",
        ),
      ),
    );
    main.querySelectorAll("[data-decision]").forEach((b) =>
      b.addEventListener("click", () =>
        perform(
          () =>
            transitionReview(state, b.dataset.decision, b.dataset.target, {
              role: "representative",
              university: "wsu",
            }),
          "Sample decision recorded.",
        ),
      ),
    );
  }
  function feedback(message) {
    main.querySelector("#portal-feedback").textContent = message;
  }
  function perform(action, message) {
    const snapshot = JSON.stringify(state);
    try {
      action();
      save();
      draw();
      feedback(message);
    } catch (error) {
      state = JSON.parse(snapshot);
      feedback(error.message);
    }
  }
  draw();
  return main.querySelector("#portal-feedback") !== null;
}
