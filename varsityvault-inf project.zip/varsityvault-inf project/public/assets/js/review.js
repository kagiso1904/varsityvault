import { api } from "./api.js";
import { renderPortal } from "./portals.js";
import { scoreReview, subjects, sampleMarks } from "/shared/scoring/review.js";
const main = document.querySelector("#main"),
  page = document.body.dataset.page,
  role = document.body.dataset.role;
const escape = (s) =>
  String(s ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
const nav = {
  learner: [
    ["overview", "Dashboard", "layout-dashboard"],
    ["profile", "My Profile", "user-round"],
    ["results", "Results", "file-chart-column"],
    ["subjects", "Subjects", "book-open"],
    ["universities", "Universities", "building-2"],
    ["requirements", "Requirements", "list-checks"],
    ["applications", "My Applications", "send"],
    ["documents", "Documents", "folder-open"],
  ],
  teacher: [
    ["overview", "Dashboard", "layout-dashboard"],
    ["profile", "My Profile", "user-round"],
    ["learners", "Learners", "users"],
    ["results", "Results", "file-check-2"],
    ["applications", "Applications", "send"],
    ["documents", "Documents", "folder-open"],
  ],
  representative: [
    ["overview", "Dashboard", "layout-dashboard"],
    ["profile", "My Profile", "user-round"],
    ["applications", "Applications", "inbox"],
    ["decisions", "Admission Decisions", "clipboard-check"],
  ],
  admin: [
    ["overview", "Dashboard", "layout-dashboard"],
    ["profile", "My Profile", "user-round"],
    ["directories", "Directories", "map-pinned"],
    ["lookups", "Academic Lookups", "table-properties"],
    ["policies", "University Policies", "book-open"],
  ],
};
const labels = {
  learner: "Learner",
  teacher: "Career Guidance Teacher",
  representative: "University Representative",
  admin: "IT Administrator",
};
const icons = () => window.lucide?.createIcons();
const title = (name, description) => /* HTML */ `
  <div class="page-heading">
    <span class="eyebrow">YOUR NEXT CHAPTER</span>
    <h1>${escape(name)}</h1>
    <p>${escape(description)}</p>
  </div>
`;
const link = (path, label) => /* HTML */ `
  <a class="inline-link" href="${path}">
    ${escape(label)}
    <i data-lucide="arrow-right" aria-hidden="true"></i>
  </a>
`;
function getStored(key, fallback) {
  try {
    return JSON.parse(sessionStorage.getItem(key)) ?? fallback;
  } catch {
    return fallback;
  }
}
function setStored(key, value) {
  try {
    sessionStorage.setItem(key, JSON.stringify(value));
  } catch {}
}
document.querySelector("#navigation").innerHTML = (nav[role] || nav.learner)
  .map(
    ([id, label, icon]) => /* HTML */ `
      <a href="/${role}/${id}.html" ${id === page ? 'aria-current="page"' : ""}>
        <i data-lucide="${icon}" aria-hidden="true"></i>
        ${label}
      </a>
    `,
  )
  .join("");
document.querySelector("#role-label").textContent = labels[role] + " workspace";
document.querySelector("#breadcrumb").textContent =
  labels[role] +
  " / " +
  ((nav[role] || []).find((n) => n[0] === page)?.[1] || "Account access");
document.querySelector(".brand").href = "/" + role + "/overview.html";
const picker = document.querySelector("#role-picker");
if (picker) {
  picker.value = role;
  picker.addEventListener("change", () =>
    location.assign("/" + picker.value + "/overview.html"),
  );
}
const toggle = document.querySelector("#sidebar-toggle");
if (toggle)
  toggle.addEventListener("click", () => {
    const collapsed = document.body.classList.toggle("nav-collapsed");
    toggle.setAttribute("aria-expanded", String(!collapsed));
  });
icons();
let policies = [],
  university = "wsu",
  method = "method1",
  exam = "grade11",
  marks = [...sampleMarks];
function policy() {
  return policies.find((p) => p.id === university) || policies[0];
}
function options() {
  return policies
    .map(
      (p) => /* HTML */ `
        <option value="${p.id}" ${p.id === university ? "selected" : ""}>
          ${escape(p.name)}
        </option>
      `,
    )
    .join("");
}
function readMarks() {
  const stored = getStored("vv-review-" + exam, null);
  marks =
    Array.isArray(stored) && stored.length === 7
      ? stored
      : exam === "grade11"
        ? [...sampleMarks]
        : Array(7).fill(null);
}
function chooseUniversity(value) {
  university = value;
  setStored("vv-review-university", value);
  method = "method1";
  setStored("vv-review-method", method);
}
function sourceLinks(p) {
  return /* HTML */ `
    <a href="${escape(p.url)}" target="_blank" rel="noopener noreferrer"
      >University source</a
    >
    ${
      p.extraSource
        ? /* HTML */ `
            ·
            <a
              href="${escape(p.extraSource)}"
              target="_blank"
              rel="noopener noreferrer"
            >
              Scoring evidence
            </a>
          `
        : ""
    }
  `;
}
function renderRequirements() {
  main.innerHTML =
    title(
      "Requirements",
      "Compare the university’s scoring profile with the sample learner results.",
    ) +
    /* HTML */ `
      <section class="panel">
        <div class="panel-header">
          <div>
            <h2>University requirements</h2>
            <p class="muted">
              Scoring review · Programme eligibility is not assessed
            </p>
          </div>
          <span class="status-label">2028 verification in progress</span>
        </div>
        <div class="fields">
          <label>
            University
            <select id="university">
              ${options()}
            </select>
          </label>
          <label>
            Programme / scoring profile
            <select id="method"></select>
          </label>
          <label>
            Examination milestone
            <select id="exam">
              <option value="grade11">Grade 11 Final</option>
              <option value="trial">Grade 12 June / Trial</option>
              <option value="final">Grade 12 Final (NSC)</option>
            </select>
          </label>
        </div>
      </section>
      <div class="split">
        <section class="panel">
          <div class="panel-header">
            <h2>Score breakdown</h2>
            <span id="metric" class="muted"></span>
          </div>
          <div class="score" id="score" aria-live="polite"></div>
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th scope="col">Subject</th>
                  <th scope="col">Mark</th>
                  <th scope="col">Contribution</th>
                </tr>
              </thead>
              <tbody id="breakdown"></tbody>
            </table>
          </div>
          <div class="actions">
            ${link("/learner/results.html", "Edit sample results")}
          </div>
        </section>
        <section class="panel">
          <h2>Programme assessment</h2>
          <div class="notice">
            <strong>Requirements pending verification</strong>
            <p id="reason"></p>
          </div>
          <dl class="details">
            <dt>Scoring policy</dt>
            <dd id="formula"></dd>
            <dt>Life Orientation</dt>
            <dd id="lo"></dd>
            <dt>Source status</dt>
            <dd id="evidence"></dd>
            <dt>Additional conditions</dt>
            <dd id="notes"></dd>
            <dt>Application window</dt>
            <dd>
              Verify the specific 2028 offering and closing date before
              applying.
            </dd>
            <dt>Sources</dt>
            <dd id="sources"></dd>
          </dl>
          <div class="actions"><button disabled>Apply unavailable</button></div>
        </section>
      </div>
    `;
  document.querySelector("#university").addEventListener("change", (e) => {
    chooseUniversity(e.target.value);
    populateMethods();
    refreshRequirements();
  });
  document.querySelector("#method").addEventListener("change", (e) => {
    method = e.target.value;
    setStored("vv-review-method", method);
    refreshRequirements();
  });
  document.querySelector("#exam").value = exam;
  document.querySelector("#exam").addEventListener("change", (e) => {
    exam = e.target.value;
    setStored("vv-review-exam", exam);
    readMarks();
    refreshRequirements();
  });
  populateMethods();
  refreshRequirements();
}
function populateMethods() {
  document.querySelector("#method").innerHTML =
    university === "cput"
      ? [1, 2, 3]
          .map(
            (i) => /* HTML */ `
              <option value="method${i}">
                CPUT Method ${i} · review profile
              </option>
            `,
          )
          .join("")
      : /* HTML */ `
          <option value="method1">${escape(policy().method)}</option>
        `;
  if (university !== "cput") method = "method1";
  document.querySelector("#method").value = method;
}
function refreshRequirements() {
  const p = policy(),
    s = scoreReview(marks, p, method);
  document.querySelector("#metric").textContent = s.metric;
  document.querySelector("#score").innerHTML =
    s.total === null
      ? "Not calculated"
      : escape(s.total) + /* HTML */ ` <small>${s.units}</small> `;
  document.querySelector("#breakdown").innerHTML = subjects
    .map(
      (subject, i) => /* HTML */ `
        <tr>
          <th scope="row">${escape(subject.name)}</th>
          <td>${marks[i] === null ? "Missing" : escape(marks[i]) + "%"}</td>
          <td>
            ${s.points[i] === null ? "Not assessed" : s.points[i] === 0 && i === 3 ? "Excluded" : escape(Math.round(s.points[i] * 100) / 100)}
          </td>
        </tr>
      `,
    )
    .join("");
  for (const [id, value] of Object.entries({
    reason: s.reason,
    formula: p.method,
    lo: p.lo,
    evidence: p.year,
    notes: p.note,
  }))
    document.getElementById(id).textContent = value;
  document.querySelector("#sources").innerHTML = sourceLinks(p);
}
function renderResults() {
  main.innerHTML =
    title(
      "Academic results",
      "Review marks by examination milestone. Changes are saved in this browser session only.",
    ) +
    /* HTML */ `
      <section class="panel">
        <div class="fields">
          <label>
            Examination milestone
            <select id="exam">
              <option value="grade11">Grade 11 Final</option>
              <option value="trial">Grade 12 June / Trial</option>
              <option value="final">Grade 12 Final (NSC)</option>
            </select>
          </label>
          <label>
            University scoring profile
            <select id="university">
              ${options()}
            </select>
          </label>
          <label>
            Scoring method
            <select id="method"></select>
          </label>
        </div>
        <div class="notice">
          This foundation uses a fixed seven-subject sample curriculum. Subject
          selection and database saving are planned for the next milestone.
        </div>
        <form id="results-form">
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Subject</th>
                  <th>Percentage</th>
                  <th>Contribution</th>
                </tr>
              </thead>
              <tbody>
                ${subjects
                  .map(
                    (s, i) => /* HTML */ `
                      <tr>
                        <th scope="row">
                          <label for="mark-${i}">${escape(s.name)}</label>
                        </th>
                        <td>
                          <input
                            id="mark-${i}"
                            data-mark="${i}"
                            type="number"
                            min="0"
                            max="100"
                            step="0.01"
                            required
                            value="${marks[i] === null ? "" : escape(marks[i])}"
                          />
                        </td>
                        <td data-points="${i}"></td>
                      </tr>
                    `,
                  )
                  .join("")}
              </tbody>
            </table>
          </div>
          <div class="actions">
            <button type="submit">Save sample marks</button>
            ${link("/learner/requirements.html", "Review requirements")}
          </div>
          <p id="feedback" class="feedback" role="status"></p>
        </form>
        <div class="score" id="live-score" aria-live="polite"></div>
        <p id="score-reason" class="muted"></p>
      </section>
    `;
  document.querySelector("#exam").value = exam;
  document.querySelector("#exam").addEventListener("change", (e) => {
    exam = e.target.value;
    setStored("vv-review-exam", exam);
    readMarks();
    renderResults();
    icons();
  });
  document.querySelector("#university").addEventListener("change", (e) => {
    chooseUniversity(e.target.value);
    populateMethods();
    refreshResults();
  });
  document.querySelectorAll("[data-mark]").forEach((input) =>
    input.addEventListener("input", () => {
      marks[Number(input.dataset.mark)] =
        input.value === "" ? null : Number(input.value);
      refreshResults();
      document.querySelector("#feedback").textContent =
        "Unsaved sample changes.";
    }),
  );
  document.querySelector("#results-form").addEventListener("submit", (e) => {
    e.preventDefault();
    setStored("vv-review-" + exam, marks);
    document.querySelector("#feedback").textContent =
      "Sample marks saved for this browser session. No SQL Server records were changed.";
  });
  populateMethods();
  document.querySelector("#method").addEventListener("change", (e) => {
    method = e.target.value;
    setStored("vv-review-method", method);
    refreshResults();
  });
  refreshResults();
}
function refreshResults() {
  const s = scoreReview(marks, policy(), method);
  document.querySelector("#live-score").textContent =
    s.total === null
      ? "Not calculated"
      : policy().short + " " + s.metric + " " + s.total + " " + s.units;
  document.querySelector("#score-reason").textContent = s.reason;
  document.querySelectorAll("[data-points]").forEach((td) => {
    const p = s.points[Number(td.dataset.points)];
    td.textContent = p === null ? "Not assessed" : Math.round(p * 100) / 100;
  });
}
function renderDirectory() {
  main.innerHTML =
    title(
      "Universities & qualifications",
      "All 26 public universities, with scoring scope and source status kept visible.",
    ) +
    /* HTML */ `
      <section class="panel">
        <div class="fields">
          <label>
            Province
            <select id="province">
              <option value="all">All provinces</option>
              ${[...new Set(policies.flatMap((p) => p.provinces))]
                .sort()
                .map((p) => /* HTML */ ` <option>${escape(p)}</option> `)
                .join("")}
            </select>
          </label>
          <label>
            University
            <select id="university">
              <option value="all">All universities</option>
              ${policies
                .map(
                  (p) => /* HTML */ `
                    <option value="${p.id}">${escape(p.name)}</option>
                  `,
                )
                .join("")}
            </select>
          </label>
          <label class="search">
            Search university or scoring profile
            <input
              id="search"
              type="search"
              placeholder="Search by name or scoring method"
            />
          </label>
        </div>
        <p class="directory-count" id="count" role="status"></p>
        <div class="table-wrap">
          <table class="directory-table">
            <thead>
              <tr>
                <th>University</th>
                <th>Scoring profile</th>
                <th>Source status</th>
                <th>Requirements</th>
              </tr>
            </thead>
            <tbody id="directory"></tbody>
          </table>
        </div>
        <p class="muted">
          These entries are policy profiles. Verified live qualification
          offerings and application dates will be mapped separately.
        </p>
      </section>
    `;
  for (const id of ["province", "university", "search"])
    document
      .getElementById(id)
      .addEventListener(id === "search" ? "input" : "change", refreshDirectory);
  refreshDirectory();
}
function refreshDirectory() {
  const province = document.querySelector("#province").value,
    uni = document.querySelector("#university").value,
    term = document.querySelector("#search").value.trim().toLowerCase();
  const visible = policies.filter(
    (p) =>
      (province === "all" || p.provinces.includes(province)) &&
      (uni === "all" || p.id === uni) &&
      (p.name + " " + p.short + " " + p.method).toLowerCase().includes(term),
  );
  document.querySelector("#count").textContent =
    visible.length + " of 26 universities";
  document.querySelector("#directory").innerHTML = visible.length
    ? visible
        .map(
          (p) => /* HTML */ `
            <tr>
              <th scope="row" class="directory-title">
                ${escape(p.name)}
                <p class="muted">${escape(p.short)}</p>
              </th>
              <td>${escape(p.method)}</td>
              <td>${escape(p.year)}</td>
              <td>
                <a href="/learner/requirements.html?university=${p.id}"
                  >View requirements</a
                >
              </td>
            </tr>
          `,
        )
        .join("")
    : /* HTML */ `
        <tr>
          <td colspan="4">No matching universities.</td>
        </tr>
      `;
}
function renderPlaceholder() {
  const names = {
    documents: "Document vault",
    applications: "Applications",
    verification: "Evidence review",
    decisions: "Admission decisions",
    directories: "Directories",
    policies: "University policies",
    overview:
      role === "teacher"
        ? "School queue"
        : role === "representative"
          ? "Institution queue"
          : "Administration",
    login: "Account access",
  };
  const descriptions = {
    documents:
      "Grade 11 Final Report and certified ID copy are required before submission. Final NSC upload unlocks after provisional acceptance.",
    applications:
      "Applications move through teacher screening, representative review and final verification.",
    verification:
      "Teachers review marks and report documents for learners at their own school.",
    decisions:
      "Representatives issue decisions only for applications routed to their university.",
    directories:
      "Operational institution and geographic directories will use the existing SQL tables.",
    policies:
      "All 26 review profiles are included. Programme mappings and evidence verification remain pending.",
    overview:
      "The authenticated queue will load after secure account access is implemented.",
    login:
      "Authentication is part of the next milestone. Review pages are available without an account.",
  };
  main.innerHTML =
    title(
      names[page] || "Workspace",
      descriptions[page] || "Role-specific review workspace.",
    ) +
    /* HTML */ `
      <section class="panel">
        <div class="empty">
          <i data-lucide="lock-keyhole" aria-hidden="true"></i>
          <h2>
            ${page === "login" ? "Account access is not enabled" : "No live records loaded"}
          </h2>
          <p class="muted">
            This foundation does not upload files, change learner records or
            issue admission decisions. Secure access and database workflows will
            be added in later milestones.
          </p>
          <div class="actions">
            ${link("/learner/requirements.html", "Review university requirements")}${link("/learner/universities.html", "Browse all universities")}
          </div>
        </div>
      </section>
    `;
}
async function start() {
  try {
    const [health, data] = await Promise.all([
      api("/api/health"),
      api("/api/universities"),
    ]);
    policies = data.universities;
    const requested =
      new URLSearchParams(location.search).get("university") ||
      getStored("vv-review-university", "wsu");
    university = policies.some((p) => p.id === requested) ? requested : "wsu";
    setStored("vv-review-university", university);
    method = getStored("vv-review-method", "method1");
    if (!["method1", "method2", "method3"].includes(method)) method = "method1";
    exam = getStored("vv-review-exam", "grade11");
    if (!["grade11", "trial", "final"].includes(exam)) exam = "grade11";
    readMarks();
    if (!health.demoMode) {
      main.innerHTML =
        title(
          "Account access required",
          "Live access is unavailable until authentication is implemented.",
        ) + link("/login.html", "Account access");
      icons();
      return;
    }
    if (role === "learner" && page === "requirements") renderRequirements();
    else if (role === "learner" && page === "results") renderResults();
    else if (role === "learner" && page === "universities") renderDirectory();
    else if (
      !renderPortal({
        main,
        role,
        page,
        policies,
        marks,
        score: scoreReview(marks, policy(), method),
        storage: sessionStorage,
        icons,
      })
    )
      renderPlaceholder();
    icons();
  } catch (error) {
    main.innerHTML =
      title("Unable to load workspace", error.message) +
      "<p>Start the project with npm start, then open the localhost address. Opening these HTML files directly does not start the server.</p>";
  }
}
start();
