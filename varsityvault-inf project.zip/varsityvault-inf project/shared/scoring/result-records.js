function normalizedId(value) {
  if (value === null || value === undefined || String(value).trim() === "")
    return null;
  const numeric = Number(value);
  return Number.isFinite(numeric) ? String(numeric) : String(value).trim();
}

export function attachSubjectsToResults(resultRows, subjects) {
  const subjectsById = new Map();
  for (const subject of subjects) {
    const key = normalizedId(subject.SUBJECT_ID);
    if (key !== null) subjectsById.set(key, subject);
  }

  return resultRows.map((row) => {
    const subject = subjectsById.get(normalizedId(row.SUBJECT_ID));
    if (!subject) {
      return {
        ...row,
        SUBJECT_NAME:
          row.SUBJECT_NAME ||
          `Unknown subject (${row.SUBJECT_ID ?? "missing ID"})`,
      };
    }
    return { ...subject, ...row };
  });
}
