const normalizedName = (value) =>
  String(value ?? "")
    .normalize("NFKC")
    .trim()
    .toLocaleLowerCase("en-ZA")
    .replace(/\s+/g, " ");

const normalizedCode = (value) =>
  String(value ?? "")
    .trim()
    .toUpperCase();

const availableToLearner = (subject, schoolId) =>
  subject.SCHOOL_ID == null || Number(subject.SCHOOL_ID) === Number(schoolId);

function bestSubjectMatch(candidates, schoolId) {
  const available = candidates.filter((subject) =>
    availableToLearner(subject, schoolId),
  );
  if (!available.length) return null;
  return (
    available.find(
      (subject) =>
        subject.SCHOOL_ID != null &&
        Number(subject.SCHOOL_ID) === Number(schoolId),
    ) ||
    available.find((subject) => subject.SCHOOL_ID == null) ||
    available[0]
  );
}

export function reconcileResultDraftRows(draftRows, catalogSubjects, schoolId) {
  const subjects = Array.isArray(catalogSubjects) ? catalogSubjects : [];
  const seen = new Set();
  const unresolved = [];
  const rows = (Array.isArray(draftRows) ? draftRows : []).map((draftRow) => {
    const row = { ...draftRow };
    const code = normalizedCode(row.SUBJECT_CODE);
    const name = normalizedName(row.SUBJECT_NAME);
    let subject = null;

    if (code) {
      subject = bestSubjectMatch(
        subjects.filter(
          (candidate) => normalizedCode(candidate.SUBJECT_CODE) === code,
        ),
        schoolId,
      );
    }
    if (!subject && name) {
      subject = bestSubjectMatch(
        subjects.filter(
          (candidate) => normalizedName(candidate.SUBJECT_NAME) === name,
        ),
        schoolId,
      );
    }
    if (!subject && !code && !name && row.SUBJECT_ID != null) {
      subject = subjects.find(
        (candidate) => Number(candidate.SUBJECT_ID) === Number(row.SUBJECT_ID),
      );
      if (subject && !availableToLearner(subject, schoolId)) subject = null;
    }

    const label = String(
      row.SUBJECT_NAME ||
        row.SUBJECT_CODE ||
        `Subject ID ${row.SUBJECT_ID ?? "?"}`,
    );
    if (!subject) {
      unresolved.push(label);
      return {
        ...row,
        PERCENTAGE:
          row.PERCENTAGE === "" || row.PERCENTAGE == null
            ? null
            : Number(row.PERCENTAGE),
        __subjectResolutionError:
          "Not available in the current subject list — remove and re-add",
      };
    }

    const currentId = Number(subject.SUBJECT_ID);
    if (!Number.isInteger(currentId) || currentId < 1 || seen.has(currentId)) {
      unresolved.push(label);
      return {
        ...row,
        PERCENTAGE:
          row.PERCENTAGE === "" || row.PERCENTAGE == null
            ? null
            : Number(row.PERCENTAGE),
        __subjectResolutionError:
          "Duplicate or invalid subject — remove and re-add",
      };
    }
    seen.add(currentId);
    const { __subjectResolutionError, ...cleanRow } = subject;
    return {
      ...cleanRow,
      PERCENTAGE:
        row.PERCENTAGE === "" || row.PERCENTAGE == null
          ? null
          : Number(row.PERCENTAGE),
    };
  });
  return { rows, unresolved };
}
